# Eisler V15 Balanced Real Tape Backtest Fix

A log alapján a V14 már tényleg futott, de túl nehéz lett: kb. 60 candidate/sec, ezért 100k candidate ~25-26 perc. Az orchestrator 900 mp-nél megölte, majd új folyamatot indított, ezért keveredett több optimizer kimenete.

V15 cél:
- továbbra is valós market.tape alapú backtest,
- 6 fold,
- minRealizedTrades=10,
- kb. 3-4 perc célidő 100k candidate mellett,
- maxEvalEvents=2600.

Fontos: a régi futó python folyamatokat telepítés előtt le kell állítani Task Managerben, különben a régi processzek tovább írhatnak a logba.

Következő logban ezt kell látni:

PIPELINE_START_V15_BALANCED_REAL_TAPE_BACKTEST
PIPELINE_OPT_BEGIN searchMode=BALANCED_REAL_TAPE_BACKTEST_LOCKED_RISK_TEMPLATE ... depth=balanced-real validationFolds=6 maxEvalEvents=2600

Ha syntheticProxy=True marad, akkor a market.tape parser nem tud elég árat kinyerni; a V15 már timestamp nélkül is megpróbál minden market rekordból mid price-ot olvasni, ezért normál esetben syntheticProxy=False várható.
