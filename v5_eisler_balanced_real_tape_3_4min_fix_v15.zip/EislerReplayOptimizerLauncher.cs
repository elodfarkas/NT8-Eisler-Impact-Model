#region Using declarations
using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.IO;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    public class EislerReplayOptimizerLauncher : Indicator
    {
        private bool _started;
        private DateTime _lastRunDate = DateTime.MinValue;
        private Process _process;

        [NinjaScriptProperty]
        [Display(Name = "EnableLauncher", Order = 1, GroupName = "Eisler Replay Optimizer")]
        public bool EnableLauncher { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "TriggerTime", Order = 2, GroupName = "Eisler Replay Optimizer")]
        public string TriggerTime { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "OptimizerCommand", Order = 3, GroupName = "Eisler Replay Optimizer")]
        public string OptimizerCommand { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "WorkingDirectory", Order = 4, GroupName = "Eisler Replay Optimizer")]
        public string WorkingDirectory { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ResearchRoot", Order = 5, GroupName = "Eisler Replay Optimizer")]
        public string ResearchRoot { get; set; }

        [NinjaScriptProperty]
        [Range(1000, 250000)]
        [Display(Name = "CandidateCount", Order = 6, GroupName = "Eisler Replay Optimizer")]
        public int CandidateCount { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EislerReplayOptimizerLauncher";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                EnableLauncher = true;
                TriggerTime = "10:00";
                OptimizerCommand = "python";
                WorkingDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "EislerReplayOrchestratedBridge", "scripts");
                ResearchRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "EislerResearch");
                CandidateCount = 100000;
            }
        }

        protected override void OnBarUpdate()
        {
            if (!EnableLauncher || CurrentBar < 1) return;
            TimeSpan trigger;
            if (!TimeSpan.TryParse(TriggerTime, out trigger)) trigger = new TimeSpan(10,0,0);
            if (_started && _lastRunDate.Date == Time[0].Date) return;
            if (Time[0].TimeOfDay >= trigger) StartPipeline(Time[0]);
        }

        private void StartPipeline(DateTime marketTime)
        {
            string instrument = GetInstrumentKey();
            string runId = instrument + "_" + marketTime.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0,8);
            string settingsPath = Path.Combine(ResearchRoot, "live_bridge", "instrument=" + instrument, "date=" + marketTime.ToString("yyyy-MM-dd"), "run=" + runId, "settings.txt");
            string args = "run_optimizer_pipeline.py --export-root " + QuoteArg(Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "EislerFastExport"))
                + " --research-root " + QuoteArg(ResearchRoot)
                + " --instrument " + QuoteArg(instrument)
                + " --date " + QuoteArg(marketTime.ToString("yyyy-MM-dd"))
                + " --run-id " + QuoteArg(runId)
                + " --settings-path " + QuoteArg(settingsPath)
                + " --candidate-count " + Math.Max(1000, CandidateCount).ToString(System.Globalization.CultureInfo.InvariantCulture)
                + " --optimizer-depth balanced-real --validation-folds 6 --max-eval-events 2600 --min-realized-trades 10";
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = OptimizerCommand;
            psi.Arguments = args;
            psi.WorkingDirectory = WorkingDirectory;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            _process = new Process();
            _process.StartInfo = psi;
            _process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (!string.IsNullOrEmpty(e.Data)) Print("[EISLER_OPT_LAUNCHER] OPT OUT " + e.Data); };
            _process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (!string.IsNullOrEmpty(e.Data)) Print("[EISLER_OPT_LAUNCHER] OPT ERR " + e.Data); };
            Print("[EISLER_OPT_LAUNCHER] PROCESS_START runId=" + runId + " settingsPath=" + settingsPath + " args=" + args);
            if (_process.Start())
            {
                _process.BeginOutputReadLine();
                _process.BeginErrorReadLine();
                _started = true;
                _lastRunDate = marketTime.Date;
            }
        }

        private string GetInstrumentKey()
        {
            string name = Instrument != null ? Instrument.FullName : "UNKNOWN";
            return Sanitize(name);
        }

        private string Sanitize(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "UNKNOWN";
            string s = value.Trim().Replace(' ', '_');
            foreach (char c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s.Replace('/', '_').Replace('\\', '_').Replace(':', '_').Replace(';', '_');
        }

        private string QuoteArg(string value)
        {
            return "\"" + (value ?? string.Empty).Replace("\"", "") + "\"";
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EislerReplayOptimizerLauncher[] cacheEislerReplayOptimizerLauncher;
		public EislerReplayOptimizerLauncher EislerReplayOptimizerLauncher(bool enableLauncher, string triggerTime, string optimizerCommand, string workingDirectory, string researchRoot, int candidateCount)
		{
			return EislerReplayOptimizerLauncher(Input, enableLauncher, triggerTime, optimizerCommand, workingDirectory, researchRoot, candidateCount);
		}

		public EislerReplayOptimizerLauncher EislerReplayOptimizerLauncher(ISeries<double> input, bool enableLauncher, string triggerTime, string optimizerCommand, string workingDirectory, string researchRoot, int candidateCount)
		{
			if (cacheEislerReplayOptimizerLauncher != null)
				for (int idx = 0; idx < cacheEislerReplayOptimizerLauncher.Length; idx++)
					if (cacheEislerReplayOptimizerLauncher[idx] != null && cacheEislerReplayOptimizerLauncher[idx].EnableLauncher == enableLauncher && cacheEislerReplayOptimizerLauncher[idx].TriggerTime == triggerTime && cacheEislerReplayOptimizerLauncher[idx].OptimizerCommand == optimizerCommand && cacheEislerReplayOptimizerLauncher[idx].WorkingDirectory == workingDirectory && cacheEislerReplayOptimizerLauncher[idx].ResearchRoot == researchRoot && cacheEislerReplayOptimizerLauncher[idx].CandidateCount == candidateCount && cacheEislerReplayOptimizerLauncher[idx].EqualsInput(input))
						return cacheEislerReplayOptimizerLauncher[idx];
			return CacheIndicator<EislerReplayOptimizerLauncher>(new EislerReplayOptimizerLauncher(){ EnableLauncher = enableLauncher, TriggerTime = triggerTime, OptimizerCommand = optimizerCommand, WorkingDirectory = workingDirectory, ResearchRoot = researchRoot, CandidateCount = candidateCount }, input, ref cacheEislerReplayOptimizerLauncher);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EislerReplayOptimizerLauncher EislerReplayOptimizerLauncher(bool enableLauncher, string triggerTime, string optimizerCommand, string workingDirectory, string researchRoot, int candidateCount)
		{
			return indicator.EislerReplayOptimizerLauncher(Input, enableLauncher, triggerTime, optimizerCommand, workingDirectory, researchRoot, candidateCount);
		}

		public Indicators.EislerReplayOptimizerLauncher EislerReplayOptimizerLauncher(ISeries<double> input , bool enableLauncher, string triggerTime, string optimizerCommand, string workingDirectory, string researchRoot, int candidateCount)
		{
			return indicator.EislerReplayOptimizerLauncher(input, enableLauncher, triggerTime, optimizerCommand, workingDirectory, researchRoot, candidateCount);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EislerReplayOptimizerLauncher EislerReplayOptimizerLauncher(bool enableLauncher, string triggerTime, string optimizerCommand, string workingDirectory, string researchRoot, int candidateCount)
		{
			return indicator.EislerReplayOptimizerLauncher(Input, enableLauncher, triggerTime, optimizerCommand, workingDirectory, researchRoot, candidateCount);
		}

		public Indicators.EislerReplayOptimizerLauncher EislerReplayOptimizerLauncher(ISeries<double> input , bool enableLauncher, string triggerTime, string optimizerCommand, string workingDirectory, string researchRoot, int candidateCount)
		{
			return indicator.EislerReplayOptimizerLauncher(input, enableLauncher, triggerTime, optimizerCommand, workingDirectory, researchRoot, candidateCount);
		}
	}
}

#endregion
