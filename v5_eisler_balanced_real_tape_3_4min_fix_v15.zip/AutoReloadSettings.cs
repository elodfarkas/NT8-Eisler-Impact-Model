#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public sealed class EislerLiveSettings
    {
        public string Version = "CODE_DEFAULT";
        public string Mode = "Adaptive";
        public string SourceMode = "CODE_DEFAULT";
        public string OptimizationInputPolicy = string.Empty;
        public string RunId = string.Empty;
        public string ReplayDate = string.Empty;
        public string Instrument = string.Empty;
        public string ExportInputPath = string.Empty;
        public string SnapshotInputPath = string.Empty;
        public int InputRows = 0;
        public int InputFiles = 0;
        public long InputBytes = 0;
        public int BarsTapeRows = 0;
        public int FlowTapeRows = 0;
        public int LevelsTapeRows = 0;
        public int MarketTapeRows = 0;
        public int DepthTapeRows = 0;
        public int CandidateCount = 0;
        public double BestScore = 0.0;
        public double BestNetPnL = 0.0;
        public double BestWinRate = 0.0;
        public double BestMaxDrawdown = 0.0;
        public string GeneratedAt = string.Empty;

        public int StopTicks = 14;
        public int TargetTicks = 42;
        public int MaxSpreadTicks = 2;
        public double MaxSpreadRatio = 0.03;
        public double MaxSpreadToAtrRatio = 0.03;
        public int LongMinAbsPredTicks = 12;
        public int ShortMinAbsPredTicks = 8;
        public int MinAtrTicksForMicroEntry = 8;
        public double MaxAbsorptionScore = 1.25;
        public double MaxAbsDeltaNormForAbsorption = 0.18;
        public double MaxAbsOfiProxyForAbsorption = 0.20;
        public int HighConvictionPredTicks = 20;
        public bool EnableLongTrades = true;
        public bool EnableShortTrades = true;
        public bool UseMarketSuitabilityWatchdog = true;
        public bool UseMicrostructureOnlyEntries = true;
        public bool AllowHighConvictionWideSpread = false;
        public bool UseLimitEntries = true;
        public int LimitOffsetTicks = 1;
        public int CancelEntryIfAwayTicks = 3;
        public int BaseQuantity = 1;
        public string TradeWindowStart = "09:50";
        public string TradeWindowEnd = "11:30";
        public string NoTradeBefore = "10:30";
        public string EodEntryCutoffTime = "15:45";
        public int MaxTradesPerSession = 30;
        public int MaxTradesPerBar = 1;
        public int CooldownAfterExitBars = 1;
        public int CooldownAfterSLBars = 2;
        public bool UseAtrDynamicRisk = true;
        public int AtrPeriod = 14;
        public double VolatilityMultiplier = 0.45;
        public int MinOneRTicks = 8;
        public int MaxOneRTicks = 20;
        public double FreeTradeActivation_R = 1.25;
        public double TrailingActivation_R = 2.0;
        public bool UseAdaptiveMfeLock = true;
        public double MfeLockActivation_R = 1.25;
        public double MfeLockPercent = 0.35;
        public double MfeEmergencyGivebackPct = 0.75;

        public EislerLiveSettings Clone() { return (EislerLiveSettings)MemberwiseClone(); }
        public static EislerLiveSettings SafeDefaults() { return new EislerLiveSettings(); }
    }

    public sealed class AutoReloadSettings
    {
        private readonly CultureInfo ic = CultureInfo.InvariantCulture;
        private DateTime lastLoadedWriteTimeUtc = DateTime.MinValue;
        private DateTime nextAllowedCheckLocal = DateTime.MinValue;
        private TimeSpan reloadCheckInterval = TimeSpan.FromMinutes(1);
        private TimeSpan activationTime = new TimeSpan(10, 30, 0);
        private TimeSpan hardEndTime = new TimeSpan(15, 45, 0);
        private bool initialized;
        private bool requireRealOptimization = true;
        private bool requireContextMatch = true;
        private DateTime expectedReplayDate = DateTime.MinValue;
        private string expectedInstrument = string.Empty;
        private string expectedRunId = string.Empty;
        private EislerLiveSettings defaults;
        private EislerLiveSettings current;
        private Action<EislerLiveSettings> applySettings;
        private Action<string> logger;

        public string SettingsPath { get; private set; }
        public string LastGoodVersion { get; private set; }
        public string LastError { get; private set; }
        public bool UseDefaultSettings { get; private set; }
        public bool HasValidLiveSettings { get; private set; }
        public DateTime LastSuccessfulLoadLocal { get; private set; }
        public EislerLiveSettings Current { get { return current == null ? null : current.Clone(); } }

        public void SetValidationPolicy(bool requireReal, bool requireContext)
        {
            requireRealOptimization = requireReal;
            requireContextMatch = requireContext;
        }

        public void SetExpectedContext(DateTime replayDate, string instrument)
        {
            expectedReplayDate = replayDate;
            expectedInstrument = instrument ?? string.Empty;
        }

        public void SetExpectedContext(DateTime replayDate, string instrument, string runId)
        {
            expectedReplayDate = replayDate;
            expectedInstrument = instrument ?? string.Empty;
            expectedRunId = runId ?? string.Empty;
        }

        public void UpdateSettingsPath(string newSettingsPath, bool resetLoadState)
        {
            if (string.IsNullOrWhiteSpace(newSettingsPath)) return;
            if (!string.Equals(SettingsPath, newSettingsPath, StringComparison.OrdinalIgnoreCase))
            {
                Print("UPDATE_SETTINGS_PATH old=" + SettingsPath + " new=" + newSettingsPath + " reset=" + resetLoadState);
                SettingsPath = newSettingsPath;
                if (resetLoadState)
                {
                    lastLoadedWriteTimeUtc = DateTime.MinValue;
                    HasValidLiveSettings = false;
                    LastGoodVersion = string.Empty;
                    LastError = string.Empty;
                }
            }
        }

        public void ResetForNewRun(string settingsPath, DateTime replayDate, string instrument, string runId)
        {
            SetExpectedContext(replayDate, instrument, runId);
            UpdateSettingsPath(settingsPath, true);
            UseDefaultSettings = true;
            HasValidLiveSettings = false;
            current = defaults == null ? EislerLiveSettings.SafeDefaults() : defaults.Clone();
            Print("RESET_FOR_NEW_RUN runId=" + expectedRunId + " date=" + replayDate.ToString("yyyy-MM-dd") + " instrument=" + expectedInstrument + " settingsPath=" + SettingsPath);
        }

        public void Initialize(string settingsPath, EislerLiveSettings codeDefaults, Action<EislerLiveSettings> apply, Action<string> log, string activationHHmm, string hardEndHHmm)
        {
            SettingsPath = settingsPath;
            defaults = codeDefaults == null ? EislerLiveSettings.SafeDefaults() : codeDefaults.Clone();
            current = defaults.Clone();
            applySettings = apply;
            logger = log;
            activationTime = ParseTimeOrDefault(activationHHmm, new TimeSpan(10, 30, 0));
            hardEndTime = ParseTimeOrDefault(hardEndHHmm, new TimeSpan(15, 45, 0));
            initialized = true;
            Print("INIT SettingsPath=" + SettingsPath + " Activation=" + activationTime + " HardEnd=" + hardEndTime + " RequireReal=" + requireRealOptimization + " RequireContext=" + requireContextMatch);
        }

        public void SetReloadCheckIntervalSeconds(int seconds) { reloadCheckInterval = TimeSpan.FromSeconds(Math.Max(5, seconds)); }

        public void CheckReload(DateTime marketTime, bool isFirstTickOfBar)
        {
            if (!initialized || string.IsNullOrWhiteSpace(SettingsPath)) return;
            if (expectedReplayDate == DateTime.MinValue) expectedReplayDate = marketTime.Date;
            DateTime now = DateTime.Now;
            if (!isFirstTickOfBar && now < nextAllowedCheckLocal) return;
            if (now < nextAllowedCheckLocal) return;
            nextAllowedCheckLocal = now.Add(reloadCheckInterval);
            try
            {
                if (!File.Exists(SettingsPath)) { Print("CHECK_RELOAD no settings file yet: " + SettingsPath); return; }
                DateTime wt = File.GetLastWriteTimeUtc(SettingsPath);
                if (wt > lastLoadedWriteTimeUtc) LoadSettings();
            }
            catch (Exception ex) { LastError = ex.Message; Print("CheckReload failed: " + ex.Message); }
        }

        public bool LoadSettings()
        {
            if (!initialized) return false;
            try
            {
                if (string.IsNullOrWhiteSpace(SettingsPath) || !File.Exists(SettingsPath)) { RevertToDefaults("settings file not found", false); return false; }
                Dictionary<string, string> kv = ReadKeyValueFile(SettingsPath);
                EislerLiveSettings loaded = defaults.Clone();
                ApplyDictionary(loaded, kv);
                string validationError;
                if (!Validate(loaded, out validationError)) { RevertToDefaults("validation failed: " + validationError, false); return false; }
                ApplyLiveSafetyTightening(loaded);
                current = loaded;
                UseDefaultSettings = false;
                HasValidLiveSettings = true;
                LastError = string.Empty;
                LastGoodVersion = loaded.Version;
                lastLoadedWriteTimeUtc = File.GetLastWriteTimeUtc(SettingsPath);
                LastSuccessfulLoadLocal = DateTime.Now;
                if (applySettings != null) applySettings(current.Clone());
                Print("Loaded settings OK Version=" + loaded.Version + " RunId=" + loaded.RunId + " SourceMode=" + loaded.SourceMode + " ReplayDate=" + loaded.ReplayDate + " Instrument=" + loaded.Instrument + " InputRows=" + loaded.InputRows + " Candidates=" + loaded.CandidateCount + " Score=" + loaded.BestScore.ToString("F4", ic));
                return true;
            }
            catch (Exception ex) { RevertToDefaults("exception: " + ex.Message, false); return false; }
        }

        public bool CanTrade(DateTime marketTime, bool requireValidLiveSettings)
        {
            TimeSpan tod = marketTime.TimeOfDay;
            if (!(tod >= activationTime && tod < hardEndTime)) return false;
            if (requireValidLiveSettings && !HasValidLiveSettings) return false;
            return true;
        }

        public void RevertToDefaults(string reason, bool allowDefaultTrading)
        {
            UseDefaultSettings = true;
            HasValidLiveSettings = allowDefaultTrading;
            LastError = reason ?? string.Empty;
            current = defaults == null ? EislerLiveSettings.SafeDefaults() : defaults.Clone();
            current.Version = "CODE_DEFAULT_FALLBACK";
            if (applySettings != null) applySettings(current.Clone());
            Print("Fallback to code defaults. allowDefaultTrading=" + allowDefaultTrading + " Reason=" + LastError + " settingsPath=" + SettingsPath + " expectedDate=" + (expectedReplayDate == DateTime.MinValue ? "" : expectedReplayDate.ToString("yyyy-MM-dd")) + " expectedInstrument=" + expectedInstrument + " expectedRunId=" + expectedRunId);
        }

        private Dictionary<string, string> ReadKeyValueFile(string path)
        {
            Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string[] lines = File.ReadAllLines(path);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = (lines[i] ?? string.Empty).Trim();
                if (line.Length == 0 || line.StartsWith("#") || line.StartsWith("//")) continue;
                int eq = line.IndexOf('=');
                if (eq <= 0) continue;
                string key = line.Substring(0, eq).Trim();
                string val = line.Substring(eq + 1).Trim();
                if (key.Length > 0) d[key] = val;
            }
            return d;
        }

        private void ApplyDictionary(EislerLiveSettings s, Dictionary<string, string> kv)
        {
            foreach (KeyValuePair<string, string> p in kv)
            {
                string k = p.Key == null ? string.Empty : p.Key.Trim().Replace(" ", string.Empty);
                string v = p.Value;
                if (k == "Version") s.Version = v;
                else if (k == "Mode") s.Mode = v;
                else if (k == "SourceMode") s.SourceMode = v;
                else if (k == "OptimizationInputPolicy") s.OptimizationInputPolicy = v;
                else if (k == "RunId") s.RunId = v;
                else if (k == "ReplayDate") s.ReplayDate = v;
                else if (k == "Instrument") s.Instrument = v;
                else if (k == "ExportInputPath") s.ExportInputPath = v;
                else if (k == "SnapshotInputPath") s.SnapshotInputPath = v;
                else if (k == "InputRows") s.InputRows = ToInt(v, s.InputRows);
                else if (k == "InputFiles") s.InputFiles = ToInt(v, s.InputFiles);
                else if (k == "InputBytes") s.InputBytes = ToLong(v, s.InputBytes);
                else if (k == "BarsTapeRows") s.BarsTapeRows = ToInt(v, s.BarsTapeRows);
                else if (k == "FlowTapeRows") s.FlowTapeRows = ToInt(v, s.FlowTapeRows);
                else if (k == "LevelsTapeRows") s.LevelsTapeRows = ToInt(v, s.LevelsTapeRows);
                else if (k == "MarketTapeRows") s.MarketTapeRows = ToInt(v, s.MarketTapeRows);
                else if (k == "DepthTapeRows") s.DepthTapeRows = ToInt(v, s.DepthTapeRows);
                else if (k == "CandidateCount") s.CandidateCount = ToInt(v, s.CandidateCount);
                else if (k == "BestScore") s.BestScore = ToDouble(v, s.BestScore);
                else if (k == "BestNetPnL") s.BestNetPnL = ToDouble(v, s.BestNetPnL);
                else if (k == "BestWinRate") s.BestWinRate = ToDouble(v, s.BestWinRate);
                else if (k == "BestMaxDrawdown") s.BestMaxDrawdown = ToDouble(v, s.BestMaxDrawdown);
                else if (k == "GeneratedAt") s.GeneratedAt = v;
                else if (k == "StopTicks" || k == "stop_ticks") s.StopTicks = ToInt(v, s.StopTicks);
                else if (k == "TargetTicks" || k == "target_ticks") s.TargetTicks = ToInt(v, s.TargetTicks);
                else if (k == "MaxSpreadTicks") s.MaxSpreadTicks = ToInt(v, s.MaxSpreadTicks);
                else if (k == "MaxSpreadRatio" || k == "MaxSpreadToAtrRatio" || k == "RthMaxSpreadToAtrRatio" || k == "max_spread_to_atr") { s.MaxSpreadRatio = ToDouble(v, s.MaxSpreadRatio); s.MaxSpreadToAtrRatio = s.MaxSpreadRatio; }
                else if (k == "LongMinAbsPredTicks" || k == "long_threshold") s.LongMinAbsPredTicks = ToInt(v, s.LongMinAbsPredTicks);
                else if (k == "ShortMinAbsPredTicks" || k == "short_threshold") s.ShortMinAbsPredTicks = ToInt(v, s.ShortMinAbsPredTicks);
                else if (k == "MinAtrTicksForMicroEntry") s.MinAtrTicksForMicroEntry = ToInt(v, s.MinAtrTicksForMicroEntry);
                else if (k == "MaxAbsorptionScore") s.MaxAbsorptionScore = ToDouble(v, s.MaxAbsorptionScore);
                else if (k == "MaxAbsDeltaNormForAbsorption") s.MaxAbsDeltaNormForAbsorption = ToDouble(v, s.MaxAbsDeltaNormForAbsorption);
                else if (k == "MaxAbsOfiProxyForAbsorption") s.MaxAbsOfiProxyForAbsorption = ToDouble(v, s.MaxAbsOfiProxyForAbsorption);
                else if (k == "HighConvictionPredTicks") s.HighConvictionPredTicks = ToInt(v, s.HighConvictionPredTicks);
                else if (k == "EnableLongTrades") s.EnableLongTrades = ToBool(v, s.EnableLongTrades);
                else if (k == "EnableShortTrades") s.EnableShortTrades = ToBool(v, s.EnableShortTrades);
                else if (k == "UseMarketSuitabilityWatchdog") s.UseMarketSuitabilityWatchdog = ToBool(v, s.UseMarketSuitabilityWatchdog);
                else if (k == "UseMicrostructureOnlyEntries") s.UseMicrostructureOnlyEntries = ToBool(v, s.UseMicrostructureOnlyEntries);
                else if (k == "AllowHighConvictionWideSpread") s.AllowHighConvictionWideSpread = ToBool(v, s.AllowHighConvictionWideSpread);
                else if (k == "UseLimitEntries") s.UseLimitEntries = ToBool(v, s.UseLimitEntries);
                else if (k == "LimitOffsetTicks") s.LimitOffsetTicks = ToInt(v, s.LimitOffsetTicks);
                else if (k == "CancelEntryIfAwayTicks") s.CancelEntryIfAwayTicks = ToInt(v, s.CancelEntryIfAwayTicks);
                else if (k == "BaseQuantity") s.BaseQuantity = ToInt(v, s.BaseQuantity);
                else if (k == "TradeWindowStart") s.TradeWindowStart = v;
                else if (k == "TradeWindowEnd") s.TradeWindowEnd = v;
                else if (k == "NoTradeBefore") s.NoTradeBefore = v;
                else if (k == "EodEntryCutoffTime") s.EodEntryCutoffTime = v;
                else if (k == "MaxTradesPerSession") s.MaxTradesPerSession = ToInt(v, s.MaxTradesPerSession);
                else if (k == "MaxTradesPerBar") s.MaxTradesPerBar = ToInt(v, s.MaxTradesPerBar);
                else if (k == "CooldownAfterExitBars") s.CooldownAfterExitBars = ToInt(v, s.CooldownAfterExitBars);
                else if (k == "CooldownAfterSLBars") s.CooldownAfterSLBars = ToInt(v, s.CooldownAfterSLBars);
                else if (k == "UseAtrDynamicRisk") s.UseAtrDynamicRisk = ToBool(v, s.UseAtrDynamicRisk);
                else if (k == "AtrPeriod") s.AtrPeriod = ToInt(v, s.AtrPeriod);
                else if (k == "VolatilityMultiplier") s.VolatilityMultiplier = ToDouble(v, s.VolatilityMultiplier);
                else if (k == "MinOneRTicks") s.MinOneRTicks = ToInt(v, s.MinOneRTicks);
                else if (k == "MaxOneRTicks") s.MaxOneRTicks = ToInt(v, s.MaxOneRTicks);
                else if (k == "FreeTradeActivation_R") s.FreeTradeActivation_R = ToDouble(v, s.FreeTradeActivation_R);
                else if (k == "TrailingActivation_R") s.TrailingActivation_R = ToDouble(v, s.TrailingActivation_R);
                else if (k == "UseAdaptiveMfeLock") s.UseAdaptiveMfeLock = ToBool(v, s.UseAdaptiveMfeLock);
                else if (k == "MfeLockActivation_R") s.MfeLockActivation_R = ToDouble(v, s.MfeLockActivation_R);
                else if (k == "MfeLockPercent") s.MfeLockPercent = ToDouble(v, s.MfeLockPercent);
                else if (k == "MfeEmergencyGivebackPct") s.MfeEmergencyGivebackPct = ToDouble(v, s.MfeEmergencyGivebackPct);
            }
        }

        private void ApplyLiveSafetyTightening(EislerLiveSettings s)
        {
            if (s.MaxSpreadRatio > 0.30) { s.MaxSpreadRatio = 0.30; s.MaxSpreadToAtrRatio = 0.30; }
            if (s.MaxSpreadTicks > 4) s.MaxSpreadTicks = 4;
            if (s.BaseQuantity < 1) s.BaseQuantity = 1;
        }

        private bool Validate(EislerLiveSettings s, out string error)
        {
            error = string.Empty;
            if (requireRealOptimization && !string.Equals(s.SourceMode, "REAL_OPTIMIZATION", StringComparison.OrdinalIgnoreCase)) { error = "SourceMode is not REAL_OPTIMIZATION: " + s.SourceMode; return false; }
            if (requireRealOptimization && s.InputRows <= 0) { error = "InputRows must be > 0 for real optimization"; return false; }
            if (requireRealOptimization && s.CandidateCount <= 0) { error = "CandidateCount must be > 0 for real optimization"; return false; }
            if (requireContextMatch)
            {
                if (expectedReplayDate != DateTime.MinValue)
                {
                    DateTime rd;
                    if (!DateTime.TryParse(s.ReplayDate, out rd)) { error = "ReplayDate invalid or missing: " + s.ReplayDate; return false; }
                    if (rd.Date != expectedReplayDate.Date) { error = "ReplayDate mismatch settings=" + rd.ToString("yyyy-MM-dd") + " expected=" + expectedReplayDate.ToString("yyyy-MM-dd"); return false; }
                }
                if (!string.IsNullOrWhiteSpace(expectedInstrument) && !string.Equals(s.Instrument, expectedInstrument, StringComparison.OrdinalIgnoreCase)) { error = "Instrument mismatch settings=" + s.Instrument + " expected=" + expectedInstrument; return false; }
                if (!string.IsNullOrWhiteSpace(expectedRunId) && !string.Equals(s.RunId, expectedRunId, StringComparison.OrdinalIgnoreCase)) { error = "RunId mismatch settings=" + s.RunId + " expected=" + expectedRunId; return false; }
            }
            if (s.StopTicks <= 0 || s.StopTicks > 60) { error = "StopTicks out of range"; return false; }
            if (s.TargetTicks <= 0 || s.TargetTicks > 200) { error = "TargetTicks out of range"; return false; }
            if (s.MaxSpreadTicks <= 0 || s.MaxSpreadTicks > 10) { error = "MaxSpreadTicks out of range"; return false; }
            if (s.MaxSpreadRatio <= 0.0 || s.MaxSpreadRatio > 1.0) { error = "MaxSpreadRatio out of range"; return false; }
            return true;
        }

        private int ToInt(string value, int fallback) { int v; return int.TryParse(value, NumberStyles.Any, ic, out v) ? v : fallback; }
        private long ToLong(string value, long fallback) { long v; return long.TryParse(value, NumberStyles.Any, ic, out v) ? v : fallback; }
        private double ToDouble(string value, double fallback) { double v; string s = (value ?? string.Empty).Replace(',', '.'); return double.TryParse(s, NumberStyles.Any, ic, out v) ? v : fallback; }
        private bool ToBool(string value, bool fallback) { if (string.IsNullOrWhiteSpace(value)) return fallback; string v = value.Trim(); if (v == "1") return true; if (v == "0") return false; bool b; return bool.TryParse(v, out b) ? b : fallback; }
        private TimeSpan ParseTimeOrDefault(string text, TimeSpan fallback) { TimeSpan ts; return TimeSpan.TryParse(text, out ts) ? ts : fallback; }
        private void Print(string msg) { if (logger != null) logger("[EISLER_BRIDGE] " + msg); }
    }
}
