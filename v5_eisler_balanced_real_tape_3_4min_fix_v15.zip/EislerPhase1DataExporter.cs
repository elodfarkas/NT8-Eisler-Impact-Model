// EislerPhase1DataExporter_V3.cs
// NinjaTrader 8 Indicator
// Partitioned layered exporter for EislerFastSimulator research/binary pipeline.
// Default folder layout:
//   <NinjaTrader UserDataDir>\EislerFastExport\instrument=NQ_12-25\date=2025-09-11\
// Primary output: binary .tape files. CSV is optional debug output.

#region Using declarations
using System;
using System.IO;
using NinjaTrader.Cbi;
using System.Text;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.BarsTypes;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    public class EislerPhase1DataExporter_V3 : Indicator
    {
        private const int FormatVersion = 3;
        private const string ExporterVersion = "EislerPhase1DataExporter_V3_QUALITY_GUARD_20260622";

        private StreamWriter marketCsvWriter;
        private StreamWriter barCsvWriter;
        private StreamWriter flowCsvWriter;
        private StreamWriter levelsCsvWriter;
        private StreamWriter depthCsvWriter;
        private StreamWriter qualityCsvWriter;

        private BinaryWriter marketBinWriter;
        private BinaryWriter barBinWriter;
        private BinaryWriter flowBinWriter;
        private BinaryWriter levelsBinWriter;
        private BinaryWriter depthBinWriter;

        private ATR atr;
        private long sequence;
        private long depthSequence;
        private string runFolder;
        private string currentPartitionKey;
        private DateTime currentPartitionDate = DateTime.MinValue;
        private bool writersReady;
        private bool metaWritten;

        private long qualityMarketRows;
        private long qualityDepthRows;
        private long qualityBarRows;
        private long qualityFlowRows;
        private long qualityLevelRowsExamined;
        private long qualityLevelRowsWritten;
        private long qualityDuplicateLevelKeysSkipped;
        private long qualityEmptyLevelRows;
        private long qualityInvalidProbabilityValuesClamped;
        private long qualityInvalidTickSizeRows;
        private long qualityOpenBarLevelRows;
        private long qualityLookAheadRiskRows;

        private int lastBarExported = -1;
        private int lastFlowExported = -1;
        private int lastLevelsExported = -1;

        
        private DateTime nextStatusWriteLocal = DateTime.MinValue;
        private string lastExportStatusState = "INIT";
private double lastBid;
        private double lastAsk;
        private double lastBidSize;
        private double lastAskSize;

        private static readonly CultureInfo IC = CultureInfo.InvariantCulture;

        [NinjaScriptProperty]
        [Display(Name = "EnableExport", Order = 1, GroupName = "Eisler Export")]
        public bool EnableExport { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "OutputSubFolder", Order = 2, GroupName = "Eisler Export")]
        public string OutputSubFolder { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "RunId", Order = 3, GroupName = "Eisler Export")]
        public string RunId { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "UseResearchPartitionFolders", Order = 4, GroupName = "Eisler Export")]
        public bool UseResearchPartitionFolders { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "IncludeRunIdFolder", Order = 5, GroupName = "Eisler Export")]
        public bool IncludeRunIdFolder { get; set; }

        [NinjaScriptProperty]
        [Range(2, 200)]
        [Display(Name = "AtrPeriod", Order = 6, GroupName = "Eisler Export")]
        public int AtrPeriod { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportBinary", Order = 10, GroupName = "Eisler Output")]
        public bool ExportBinary { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportCsvDebug", Order = 11, GroupName = "Eisler Output")]
        public bool ExportCsvDebug { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "FlushEveryLine", Order = 12, GroupName = "Eisler Output")]
        public bool FlushEveryLine { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportStatusFiles", Order = 13, GroupName = "Eisler Output")]
        public bool ExportStatusFiles { get; set; }

        [NinjaScriptProperty]
        [Range(1, 60)]
        [Display(Name = "StatusUpdateSeconds", Order = 14, GroupName = "Eisler Output")]
        public int StatusUpdateSeconds { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportBars", Order = 20, GroupName = "Eisler Layers")]
        public bool ExportBars { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportEislerFlow", Order = 21, GroupName = "Eisler Layers")]
        public bool ExportEislerFlow { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportPriceLevels", Order = 22, GroupName = "Eisler Layers")]
        public bool ExportPriceLevels { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportDomDepth", Order = 23, GroupName = "Eisler Layers")]
        public bool ExportDomDepth { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ExportLastOpenBarOnTermination", Order = 24, GroupName = "Eisler Layers")]
        public bool ExportLastOpenBarOnTermination { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EislerPhase1DataExporter_V3";
                Description = "Exports partitioned binary .tape layers and optional CSV debug files for EislerFastSimulator.";
                Calculate = Calculate.OnEachTick;
                IsOverlay = false;
                DisplayInDataBox = false;
                DrawOnPricePanel = false;

                EnableExport = true;
                OutputSubFolder = "EislerFastExport";
                RunId = "";
                UseResearchPartitionFolders = true;
                IncludeRunIdFolder = false;
                AtrPeriod = 14;

                ExportBinary = true;
                ExportCsvDebug = false;
                FlushEveryLine = false;
				StatusUpdateSeconds = 5;
                ExportBars = true;
                ExportEislerFlow = true;
                ExportPriceLevels = true;
                ExportDomDepth = true;
                ExportLastOpenBarOnTermination = true;
            }
            else if (State == State.DataLoaded)
            {
                atr = ATR(Math.Max(2, AtrPeriod));
            }
            else if (State == State.Terminated)
            {
                TryExportLastOpenBar();
                CloseWriters();
            }
        }

        protected override void OnMarketData(MarketDataEventArgs e)
        {
            if (!EnableExport || e == null)
                return;

            DateTime t = GetMarketDataTime(e);
            EnsureWritersForTime(t);
            if (!writersReady)
                return;

            byte eventType;
            string eventTypeText;
            double price = e.Price;
            double volume = e.Volume;

            if (e.MarketDataType == MarketDataType.Bid)
            {
                eventType = 1;
                eventTypeText = "Bid";
                lastBid = price;
                lastBidSize = volume;
            }
            else if (e.MarketDataType == MarketDataType.Ask)
            {
                eventType = 2;
                eventTypeText = "Ask";
                lastAsk = price;
                lastAskSize = volume;
            }
            else if (e.MarketDataType == MarketDataType.Last)
            {
                eventType = 3;
                eventTypeText = "Last";
            }
            else
            {
                return;
            }

            sequence++;
            qualityMarketRows++;
            WriteSyntheticL1DepthFromQuote(t, eventType, price, volume);

            if (ExportBinary && marketBinWriter != null)
            {
                marketBinWriter.Write(sequence);
                marketBinWriter.Write(t.Ticks);
                marketBinWriter.Write(eventType);
                marketBinWriter.Write((byte)0);
                marketBinWriter.Write((short)0);
                marketBinWriter.Write(SafeD(price));
                marketBinWriter.Write(SafeD(volume));
                marketBinWriter.Write(SafeD(lastBid));
                marketBinWriter.Write(SafeD(lastAsk));
                marketBinWriter.Write((float)SafeD(lastBidSize));
                marketBinWriter.Write((float)SafeD(lastAskSize));
            }

            if (ExportCsvDebug && marketCsvWriter != null)
            {
                marketCsvWriter.Write(sequence.ToString(IC)); marketCsvWriter.Write(';');
                marketCsvWriter.Write(t.Ticks.ToString(IC)); marketCsvWriter.Write(';');
                marketCsvWriter.Write(t.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)); marketCsvWriter.Write(';');
                marketCsvWriter.Write(eventTypeText); marketCsvWriter.Write(';');
                WriteD(marketCsvWriter, price); marketCsvWriter.Write(';');
                WriteD(marketCsvWriter, volume); marketCsvWriter.Write(';');
                WriteD(marketCsvWriter, lastBid); marketCsvWriter.Write(';');
                WriteD(marketCsvWriter, lastAsk); marketCsvWriter.Write(';');
                WriteD(marketCsvWriter, lastBidSize); marketCsvWriter.Write(';');
                WriteD(marketCsvWriter, lastAskSize); marketCsvWriter.WriteLine();

                if (FlushEveryLine)
                    marketCsvWriter.Flush();
            }
        }


        private void WriteSyntheticL1DepthFromQuote(DateTime t, byte marketEventType, double price, double volume)
        {
            // MarketDepth/L2 is not produced by the custom BarsType. In Playback it is present only
            // if the replay data contains DOM events and NT calls OnMarketDepth().
            // To avoid an empty depth.tape in L1-only playback, mirror Bid/Ask quote updates as
            // top-of-book synthetic depth rows: side=1 bid, side=2 ask, operation=2 update, position=0.
            if (!ExportDomDepth || !writersReady)
                return;
            if (marketEventType != 1 && marketEventType != 2)
                return;
            try
            {
                depthSequence++;
                qualityDepthRows++;
                MaybeWriteExportStatus(t, "EXPORTING_L1_SYNTH_DEPTH");
                byte side = marketEventType == 1 ? (byte)1 : (byte)2;
                byte operation = 2;
                short position = 0;
                if (ExportBinary && depthBinWriter != null)
                {
                    depthBinWriter.Write(depthSequence);
                    depthBinWriter.Write(t.Ticks);
                    depthBinWriter.Write(side);
                    depthBinWriter.Write(operation);
                    depthBinWriter.Write(position);
                    depthBinWriter.Write(SafeD(price));
                    depthBinWriter.Write((float)SafeD(volume));
                }
                if (ExportCsvDebug && depthCsvWriter != null)
                {
                    depthCsvWriter.Write(depthSequence.ToString(IC)); depthCsvWriter.Write(';');
                    depthCsvWriter.Write(t.Ticks.ToString(IC)); depthCsvWriter.Write(';');
                    depthCsvWriter.Write(t.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)); depthCsvWriter.Write(';');
                    depthCsvWriter.Write(side == 1 ? "Bid" : "Ask"); depthCsvWriter.Write(';');
                    depthCsvWriter.Write("SyntheticL1Update"); depthCsvWriter.Write(';');
                    depthCsvWriter.Write(position.ToString(IC)); depthCsvWriter.Write(';');
                    WriteD(depthCsvWriter, price); depthCsvWriter.Write(';');
                    WriteD(depthCsvWriter, volume); depthCsvWriter.WriteLine();
                    if (FlushEveryLine)
                        depthCsvWriter.Flush();
                }
            }
            catch { }
        }

        protected override void OnMarketDepth(MarketDepthEventArgs e)
        {
            if (!EnableExport || !ExportDomDepth || e == null)
                return;

            DateTime t = CurrentBar >= 0 ? Time[0] : DateTime.Now;
            EnsureWritersForTime(t);
            if (!writersReady)
                return;

            byte side;
            string sideText;
            if (e.MarketDataType == MarketDataType.Bid)
            {
                side = 1;
                sideText = "Bid";
            }
            else if (e.MarketDataType == MarketDataType.Ask)
            {
                side = 2;
                sideText = "Ask";
            }
            else
            {
                return;
            }

            depthSequence++;
            qualityDepthRows++;
            MaybeWriteExportStatus(t, "EXPORTING_DEPTH");
            byte operation = MarketDepthOperationToByte(e.Operation);
            string operationText = e.Operation.ToString();

            if (ExportBinary && depthBinWriter != null)
            {
                depthBinWriter.Write(depthSequence);
                depthBinWriter.Write(t.Ticks);
                depthBinWriter.Write(side);
                depthBinWriter.Write(operation);
                depthBinWriter.Write((short)e.Position);
                depthBinWriter.Write(SafeD(e.Price));
                depthBinWriter.Write((float)SafeD(e.Volume));
            }

            if (ExportCsvDebug && depthCsvWriter != null)
            {
                depthCsvWriter.Write(depthSequence.ToString(IC)); depthCsvWriter.Write(';');
                depthCsvWriter.Write(t.Ticks.ToString(IC)); depthCsvWriter.Write(';');
                depthCsvWriter.Write(t.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)); depthCsvWriter.Write(';');
                depthCsvWriter.Write(sideText); depthCsvWriter.Write(';');
                depthCsvWriter.Write(operationText); depthCsvWriter.Write(';');
                depthCsvWriter.Write(e.Position.ToString(IC)); depthCsvWriter.Write(';');
                WriteD(depthCsvWriter, e.Price); depthCsvWriter.Write(';');
                WriteD(depthCsvWriter, e.Volume); depthCsvWriter.WriteLine();

                if (FlushEveryLine)
                    depthCsvWriter.Flush();
            }
        }

        protected override void OnBarUpdate()
        {
            if (!EnableExport || CurrentBar < 1)
                return;

            if (IsFirstTickOfBar)
            {
                int closedBar = CurrentBar - 1;
                DateTime closedBarPartitionTime = Time[1];

                EnsureWritersForTime(closedBarPartitionTime);
                if (!writersReady)
                    return;

                ExportBarIfNeeded(closedBar, 1);
                ExportFlowIfNeeded(closedBar, 1);
                ExportLevelsIfNeeded(closedBar, 1);
                MaybeWriteExportStatus(Time[0], "EXPORTING_BARS");
            }
        }

        private void ExportBarIfNeeded(int barIndex, int barsAgo)
        {
            if (!ExportBars || barIndex < 0 || barIndex == lastBarExported || CurrentBar < barsAgo)
                return;

            double atrTicks = 0.0;
            try
            {
                if (atr != null && TickSize > 0 && atr[barsAgo] > 0)
                    atrTicks = atr[barsAgo] / TickSize;
            }
            catch { atrTicks = 0.0; }

            DateTime t = Time[barsAgo];
            double o = Open[barsAgo];
            double h = High[barsAgo];
            double l = Low[barsAgo];
            double c = Close[barsAgo];
            double v = Volume[barsAgo];

            if (ExportBinary && barBinWriter != null)
            {
                barBinWriter.Write(barIndex);
                barBinWriter.Write(t.Ticks);
                barBinWriter.Write(SafeD(o));
                barBinWriter.Write(SafeD(h));
                barBinWriter.Write(SafeD(l));
                barBinWriter.Write(SafeD(c));
                barBinWriter.Write(SafeD(v));
                barBinWriter.Write((float)SafeD(atrTicks));
            }

            if (ExportCsvDebug && barCsvWriter != null)
            {
                barCsvWriter.Write(barIndex.ToString(IC)); barCsvWriter.Write(';');
                barCsvWriter.Write(t.Ticks.ToString(IC)); barCsvWriter.Write(';');
                barCsvWriter.Write(t.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)); barCsvWriter.Write(';');
                WriteD(barCsvWriter, o); barCsvWriter.Write(';');
                WriteD(barCsvWriter, h); barCsvWriter.Write(';');
                WriteD(barCsvWriter, l); barCsvWriter.Write(';');
                WriteD(barCsvWriter, c); barCsvWriter.Write(';');
                WriteD(barCsvWriter, v); barCsvWriter.Write(';');
                WriteD(barCsvWriter, atrTicks); barCsvWriter.WriteLine();

                if (FlushEveryLine)
                    barCsvWriter.Flush();
            }

            qualityBarRows++;
            lastBarExported = barIndex;
        }

        private void ExportFlowIfNeeded(int barIndex, int barsAgo)
        {
            if (!ExportEislerFlow || barIndex < 0 || barIndex == lastFlowExported || CurrentBar < barsAgo)
                return;

            try
            {
                EislerBarType eislerBars = Bars != null ? Bars.BarsSeries.BarsType as EislerBarType : null;
                if (eislerBars == null || eislerBars.FlowDataByBar == null)
                    return;

                EislerOrderFlowData flow;
                if (!eislerBars.FlowDataByBar.TryGetValue(barIndex, out flow) || flow == null)
                    return;

                DateTime t = Time[barsAgo];
                long delta = flow.Delta;

                if (ExportBinary && flowBinWriter != null)
                {
                    flowBinWriter.Write(barIndex);
                    flowBinWriter.Write(t.Ticks);
                    flowBinWriter.Write(flow.BuyVolume);
                    flowBinWriter.Write(flow.SellVolume);
                    flowBinWriter.Write(delta);
                    flowBinWriter.Write((float)SafeD(flow.NetLiquidityPressure));
                    flowBinWriter.Write((float)SafeD(flow.GapCompression));
                    flowBinWriter.Write((float)SafeD(flow.GapExpansion));
                    flowBinWriter.Write((float)SafeD(flow.RefillIntensity));
                    flowBinWriter.Write((float)SafeD(flow.SweepIntensity));
                    flowBinWriter.Write((float)SafeD(flow.LiquidityElasticity));
                    flowBinWriter.Write((float)SafeD(flow.AggressionVelocity));
                    flowBinWriter.Write((float)SafeD(flow.ImpactSlope));
                    flowBinWriter.Write((float)SafeD(flow.Toxicity));
                    flowBinWriter.Write((float)SafeD(flow.Resiliency));
                    flowBinWriter.Write((float)SafeD(flow.EventEntropy));
                    flowBinWriter.Write((float)SafeD(flow.RegimeProbability));
                }

                if (ExportCsvDebug && flowCsvWriter != null)
                {
                    flowCsvWriter.Write(barIndex.ToString(IC)); flowCsvWriter.Write(';');
                    flowCsvWriter.Write(t.Ticks.ToString(IC)); flowCsvWriter.Write(';');
                    flowCsvWriter.Write(t.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)); flowCsvWriter.Write(';');
                    flowCsvWriter.Write(flow.BuyVolume.ToString(IC)); flowCsvWriter.Write(';');
                    flowCsvWriter.Write(flow.SellVolume.ToString(IC)); flowCsvWriter.Write(';');
                    flowCsvWriter.Write(delta.ToString(IC)); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.NetLiquidityPressure); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.GapCompression); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.GapExpansion); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.RefillIntensity); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.SweepIntensity); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.LiquidityElasticity); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.AggressionVelocity); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.ImpactSlope); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.Toxicity); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.Resiliency); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.EventEntropy); flowCsvWriter.Write(';');
                    WriteD(flowCsvWriter, flow.RegimeProbability); flowCsvWriter.WriteLine();

                    if (FlushEveryLine)
                        flowCsvWriter.Flush();
                }

                qualityFlowRows++;
                lastFlowExported = barIndex;
            }
            catch { }
        }

        private void ExportLevelsIfNeeded(int barIndex, int barsAgo)
        {
            if (!ExportPriceLevels || barIndex < 0 || barIndex == lastLevelsExported || CurrentBar < barsAgo)
                return;

            try
            {
                EislerBarType eislerBars = Bars != null ? Bars.BarsSeries.BarsType as EislerBarType : null;
                if (eislerBars == null || eislerBars.FlowDataByBar == null)
                    return;

                EislerOrderFlowData flow;
                if (!eislerBars.FlowDataByBar.TryGetValue(barIndex, out flow) || flow == null || flow.Footprint == null)
                    return;

                DateTime t = Time[barsAgo];
                bool isClosedBarFinal = barsAgo > 0;
                HashSet<long> exportedPriceKeys = new HashSet<long>();

                foreach (var kv in flow.Footprint)
                {
                    EislerPriceLevelData level = kv.Value;
                    if (level == null)
                        continue;

                    qualityLevelRowsExamined++;

                    double rawPrice = level.Price > 0 ? level.Price : kv.Key;
                    bool tickSizeValid;
                    double price = NormalizePriceToTick(rawPrice, out tickSizeValid);
                    long priceKey = PriceToTickKey(price);

                    if (!tickSizeValid)
                        qualityInvalidTickSizeRows++;

                    if (!exportedPriceKeys.Add(priceKey))
                    {
                        qualityDuplicateLevelKeysSkipped++;
                        WriteQualityEvent("DUPLICATE_LEVEL_KEY_SKIPPED", barIndex, t, price, "Duplicate BarIndex+TimeTicks+Price after tick-size normalization");
                        continue;
                    }

                    bool probabilityRangeValid = true;
                    double sweepProbability = ClampProbability(level.SweepProbability, ref probabilityRangeValid);
                    double meanReversionProbability = ClampProbability(level.MeanReversionProbability, ref probabilityRangeValid);
                    double continuationProbability = ClampProbability(level.ContinuationProbability, ref probabilityRangeValid);
                    double revisitProbability = ClampProbability(level.RevisitProbability, ref probabilityRangeValid);

                    if (!probabilityRangeValid)
                    {
                        qualityInvalidProbabilityValuesClamped++;
                        WriteQualityEvent("PROBABILITY_CLAMPED", barIndex, t, price, "One or more probability fields were outside [0,1] and were clamped before export");
                    }

                    bool hasVolume = level.BuyVolume != 0 || level.SellVolume != 0 || level.AggressiveBuyVolume != 0 || level.AggressiveSellVolume != 0;
                    bool hasTouch = level.TouchCount > 0;
                    bool hasSweep = level.SweepCount > 0;
                    bool hasAbsorption = level.AbsorptionCount > 0 || SafeD(level.AbsorptionScore) > 0.0;
                    bool isEmptyLevel = !hasVolume && !hasTouch && !hasSweep && level.RefillCount <= 0 && !hasAbsorption && level.TrapCount <= 0;
                    bool lookAheadRiskFlag = !isClosedBarFinal;

                    if (isEmptyLevel)
                        qualityEmptyLevelRows++;
                    if (!isClosedBarFinal)
                        qualityOpenBarLevelRows++;
                    if (lookAheadRiskFlag)
                        qualityLookAheadRiskRows++;

                    if (ExportBinary && levelsBinWriter != null)
                    {
                        levelsBinWriter.Write(barIndex);
                        levelsBinWriter.Write(t.Ticks);
                        levelsBinWriter.Write(SafeD(price));
                        levelsBinWriter.Write(level.BuyVolume);
                        levelsBinWriter.Write(level.SellVolume);
                        levelsBinWriter.Write(level.AggressiveBuyVolume);
                        levelsBinWriter.Write(level.AggressiveSellVolume);
                        levelsBinWriter.Write(level.TouchCount);
                        levelsBinWriter.Write(level.SweepCount);
                        levelsBinWriter.Write(level.RefillCount);
                        levelsBinWriter.Write(level.AbsorptionCount);
                        levelsBinWriter.Write(level.TrapCount);
                        levelsBinWriter.Write((float)SafeD(level.AbsorptionScore));
                        levelsBinWriter.Write((float)SafeD(level.RefillScore));
                        levelsBinWriter.Write((float)SafeD(level.LiquidityPersistence));
                        levelsBinWriter.Write((float)SafeD(level.Elasticity));
                        levelsBinWriter.Write((float)SafeD(level.TrappedTraderScore));
                        levelsBinWriter.Write((float)SafeD(sweepProbability));
                        levelsBinWriter.Write((float)SafeD(meanReversionProbability));
                        levelsBinWriter.Write((float)SafeD(continuationProbability));
                        levelsBinWriter.Write((float)SafeD(revisitProbability));
                        levelsBinWriter.Write((float)SafeD(level.QueueResiliency));
                        levelsBinWriter.Write((float)SafeD(level.ImpactMemory));
                        levelsBinWriter.Write((float)SafeD(level.LocalVolatility));
                        levelsBinWriter.Write((float)SafeD(level.LocalImbalanceTensor));
                        levelsBinWriter.Write((float)SafeD(level.InducedResponseState));
                    }

                    if (ExportCsvDebug && levelsCsvWriter != null)
                    {
                        levelsCsvWriter.Write(barIndex.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(t.Ticks.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(t.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, price); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.BuyVolume.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.SellVolume.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.AggressiveBuyVolume.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.AggressiveSellVolume.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.TouchCount.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.SweepCount.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.RefillCount.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.AbsorptionCount.ToString(IC)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(level.TrapCount.ToString(IC)); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.AbsorptionScore); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.RefillScore); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.LiquidityPersistence); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.Elasticity); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.TrappedTraderScore); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, sweepProbability); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, meanReversionProbability); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, continuationProbability); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, revisitProbability); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.QueueResiliency); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.ImpactMemory); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.LocalVolatility); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.LocalImbalanceTensor); levelsCsvWriter.Write(';');
                        WriteD(levelsCsvWriter, level.InducedResponseState); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(hasVolume)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(hasTouch)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(hasSweep)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(hasAbsorption)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(isEmptyLevel)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(isClosedBarFinal)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(lookAheadRiskFlag)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(probabilityRangeValid)); levelsCsvWriter.Write(';');
                        levelsCsvWriter.Write(BoolInt(tickSizeValid)); levelsCsvWriter.WriteLine();
                    }

                    qualityLevelRowsWritten++;
                }

                if (ExportCsvDebug && FlushEveryLine && levelsCsvWriter != null)
                    levelsCsvWriter.Flush();

                lastLevelsExported = barIndex;
            }
            catch (Exception ex)
            {
                WriteQualityEvent("EXPORT_LEVELS_EXCEPTION", barIndex, CurrentBar >= barsAgo ? Time[barsAgo] : DateTime.MinValue, 0, ex.Message);
            }
        }


        private void TryExportLastOpenBar()
        {
            if (!EnableExport || !ExportLastOpenBarOnTermination)
                return;

            try
            {
                if (CurrentBar < 0)
                    return;

                DateTime partitionTime = Time[0];
                EnsureWritersForTime(partitionTime);
                if (!writersReady)
                    return;

                int barIndex = CurrentBar;
                ExportBarIfNeeded(barIndex, 0);
                ExportFlowIfNeeded(barIndex, 0);
                ExportLevelsIfNeeded(barIndex, 0);
            }
            catch { }
        }

        private void EnsureWritersForTime(DateTime partitionTime)
        {
            DateTime d = partitionTime == DateTime.MinValue ? DateTime.Now.Date : partitionTime.Date;
            string instrumentName = Instrument != null && !string.IsNullOrWhiteSpace(Instrument.FullName) ? Instrument.FullName : "UNKNOWN";
            string instrumentKey = SanitizePartitionValue(instrumentName);
            string dateKey = d.ToString("yyyy-MM-dd", IC);
            string key = instrumentKey + "|" + dateKey;

            if (writersReady && UseResearchPartitionFolders && !string.Equals(currentPartitionKey, key, StringComparison.Ordinal))
            {
                CloseWriters();
                lastBarExported = -1;
                lastFlowExported = -1;
                lastLevelsExported = -1;
            }

            if (!writersReady)
                OpenWriters(partitionTime);
        }

        private void OpenWriters(DateTime partitionTime)
        {
            if (!EnableExport || writersReady)
                return;

            try
            {
                string sub = string.IsNullOrWhiteSpace(OutputSubFolder) ? "EislerFastExport" : OutputSubFolder;
                string instrumentName = Instrument != null && !string.IsNullOrWhiteSpace(Instrument.FullName) ? Instrument.FullName : "UNKNOWN";
                string instrumentKey = SanitizePartitionValue(instrumentName);
                DateTime d = partitionTime == DateTime.MinValue ? DateTime.Now.Date : partitionTime.Date;
                string dateKey = d.ToString("yyyy-MM-dd", IC);
                string rid = string.IsNullOrWhiteSpace(RunId) ? DateTime.Now.ToString("yyyyMMdd_HHmmss", IC) : SanitizeFileName(RunId);

                if (UseResearchPartitionFolders)
                {
                    runFolder = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, sub, "instrument=" + instrumentKey, "date=" + dateKey);
                    if (IncludeRunIdFolder)
                        runFolder = Path.Combine(runFolder, "run=" + rid);
                }
                else
                {
                    runFolder = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, sub, rid);
                }

                currentPartitionDate = d;
                currentPartitionKey = instrumentKey + "|" + dateKey;
                metaWritten = false;
                ResetQualityCounters();

                Directory.CreateDirectory(runFolder);

                if (ExportCsvDebug)
                    OpenCsvWriters();

                if (ExportBinary)
                    OpenBinaryWriters();

                writersReady = true;
                WriteMetaJson();
                WriteExportStatusFiles("EXPORTING", partitionTime, true);
                Print("[EISLER_EXPORT_V3] Output folder: " + runFolder);
            }
            catch (Exception ex)
            {
                writersReady = false;
                Print("[EISLER_EXPORT_V3_ERROR] Cannot open writers: " + ex.Message);
            }
        }

        private void OpenCsvWriters()
        {
            marketCsvWriter = new StreamWriter(Path.Combine(runFolder, "marketdata.csv"), false, Encoding.UTF8);
            marketCsvWriter.WriteLine("Sequence;TimeTicks;Time;Type;Price;Volume;Bid;Ask;BidSize;AskSize");

            barCsvWriter = new StreamWriter(Path.Combine(runFolder, "bars.csv"), false, Encoding.UTF8);
            barCsvWriter.WriteLine("BarIndex;TimeTicks;Time;Open;High;Low;Close;Volume;AtrTicks");

            flowCsvWriter = new StreamWriter(Path.Combine(runFolder, "eislerflow.csv"), false, Encoding.UTF8);
            flowCsvWriter.WriteLine("BarIndex;TimeTicks;Time;BuyVolume;SellVolume;Delta;NetLiquidityPressure;GapCompression;GapExpansion;RefillIntensity;SweepIntensity;LiquidityElasticity;AggressionVelocity;ImpactSlope;Toxicity;Resiliency;EventEntropy;RegimeProbability");

            levelsCsvWriter = new StreamWriter(Path.Combine(runFolder, "levels_bar_price.csv"), false, Encoding.UTF8);
            levelsCsvWriter.WriteLine("BarIndex;TimeTicks;Time;Price;BuyVolume;SellVolume;AggressiveBuyVolume;AggressiveSellVolume;TouchCount;SweepCount;RefillCount;AbsorptionCount;TrapCount;AbsorptionScore;RefillScore;LiquidityPersistence;Elasticity;TrappedTraderScore;SweepProbability;MeanReversionProbability;ContinuationProbability;RevisitProbability;QueueResiliency;ImpactMemory;LocalVolatility;LocalImbalanceTensor;InducedResponseState;HasVolume;HasTouch;HasSweep;HasAbsorption;IsEmptyLevel;IsClosedBarFinal;LookAheadRiskFlag;ProbabilityRangeValid;TickSizeValid");

            qualityCsvWriter = new StreamWriter(Path.Combine(runFolder, "quality_events.csv"), false, Encoding.UTF8);
            qualityCsvWriter.WriteLine("TimeTicks;Time;EventType;BarIndex;Price;Message");

            depthCsvWriter = new StreamWriter(Path.Combine(runFolder, "dom_depth_events.csv"), false, Encoding.UTF8);
            depthCsvWriter.WriteLine("DepthSequence;TimeTicks;Time;Side;Operation;Position;Price;Volume");
        }

        private void OpenBinaryWriters()
        {
            marketBinWriter = new BinaryWriter(File.Open(Path.Combine(runFolder, "market.tape"), FileMode.Create, FileAccess.Write, FileShare.Read), Encoding.UTF8);
            WriteTapeHeader(marketBinWriter, "EIS_MKT", 44);

            barBinWriter = new BinaryWriter(File.Open(Path.Combine(runFolder, "bars.tape"), FileMode.Create, FileAccess.Write, FileShare.Read), Encoding.UTF8);
            WriteTapeHeader(barBinWriter, "EIS_BAR", 60);

            flowBinWriter = new BinaryWriter(File.Open(Path.Combine(runFolder, "flow.tape"), FileMode.Create, FileAccess.Write, FileShare.Read), Encoding.UTF8);
            WriteTapeHeader(flowBinWriter, "EIS_FLW", 92);

            levelsBinWriter = new BinaryWriter(File.Open(Path.Combine(runFolder, "levels.tape"), FileMode.Create, FileAccess.Write, FileShare.Read), Encoding.UTF8);
            WriteTapeHeader(levelsBinWriter, "EIS_LVL", 128);

            depthBinWriter = new BinaryWriter(File.Open(Path.Combine(runFolder, "depth.tape"), FileMode.Create, FileAccess.Write, FileShare.Read), Encoding.UTF8);
            WriteTapeHeader(depthBinWriter, "EIS_DEP", 28);
        }

        private void WriteTapeHeader(BinaryWriter w, string magic, int recordSize)
        {
            byte[] magicBytes = new byte[8];
            byte[] src = Encoding.ASCII.GetBytes(magic ?? string.Empty);
            int n = Math.Min(src.Length, magicBytes.Length);
            for (int i = 0; i < n; i++)
                magicBytes[i] = src[i];

            w.Write(magicBytes);
            w.Write(FormatVersion);
            w.Write(recordSize);
            w.Write(DateTime.UtcNow.Ticks);
            w.Write(SafeD(TickSize));
            w.Write((long)0);
        }

        private void WriteMetaJson()
        {
            if (metaWritten)
                return;

            try
            {
                string metaPath = Path.Combine(runFolder, "meta.json");
                using (StreamWriter w = new StreamWriter(metaPath, false, Encoding.UTF8))
                {
                    w.WriteLine("{");
                    JsonLine(w, "formatVersion", FormatVersion.ToString(IC), true, false);
                    JsonLine(w, "exporterVersion", ExporterVersion, true, true);
                    JsonLine(w, "createdUtc", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffffffZ", IC), true, true);
                    JsonLine(w, "instrument", Instrument != null ? Instrument.FullName : string.Empty, true, true);
                    JsonLine(w, "partitionInstrument", Instrument != null ? SanitizePartitionValue(Instrument.FullName) : "UNKNOWN", true, true);
                    JsonLine(w, "partitionDate", currentPartitionDate == DateTime.MinValue ? string.Empty : currentPartitionDate.ToString("yyyy-MM-dd", IC), true, true);
                    JsonLine(w, "tickSize", SafeD(TickSize).ToString("F10", IC), true, false);
                    JsonLine(w, "atrPeriod", Math.Max(2, AtrPeriod).ToString(IC), true, false);
                    JsonLine(w, "barType", Bars != null && Bars.BarsSeries != null && Bars.BarsSeries.BarsType != null ? Bars.BarsSeries.BarsType.ToString() : string.Empty, true, true);
                    JsonLine(w, "source", "NinjaTrader Playback/Chart Export", true, true);
                    JsonLine(w, "folderLayout", UseResearchPartitionFolders ? "instrument/date" : "run", true, true);
                    JsonLine(w, "exportBinary", ExportBinary ? "true" : "false", true, false);
                    JsonLine(w, "exportCsvDebug", ExportCsvDebug ? "true" : "false", true, false);
                    JsonLine(w, "qualityGuard", "true", true, false);
                    JsonLine(w, "levelPrimaryKey", "BarIndex+TimeTicks+Price", true, true);
                    JsonLine(w, "probabilityPolicy", "ClampToRange_0_1_AndFlag", true, true);
                    JsonLine(w, "lookAheadPolicy", "ClosedBarsAreSafe_OpenBarOnTerminationIsFlagged", true, true);
                    JsonLine(w, "hasMarket", "true", true, false);
                    JsonLine(w, "hasBars", ExportBars ? "true" : "false", true, false);
                    JsonLine(w, "hasFlow", ExportEislerFlow ? "true" : "false", true, false);
                    JsonLine(w, "hasLevels", ExportPriceLevels ? "true" : "false", true, false);
                    JsonLine(w, "hasDepth", ExportDomDepth ? "true" : "false", true, false);
                    JsonLine(w, "depthPolicy", "L2_OnMarketDepth_Or_SyntheticL1BidAskTopOfBook", false, true);
                    w.WriteLine("}");
                }
                metaWritten = true;
            }
            catch { }
        }

        private void CloseWriters()
        {
            WriteExportStatusFiles("CLOSING", DateTime.Now, true);
            WriteQualitySummaryJson();

            try { if (marketCsvWriter != null) { marketCsvWriter.Flush(); marketCsvWriter.Close(); marketCsvWriter.Dispose(); marketCsvWriter = null; } } catch { }
            try { if (barCsvWriter != null) { barCsvWriter.Flush(); barCsvWriter.Close(); barCsvWriter.Dispose(); barCsvWriter = null; } } catch { }
            try { if (flowCsvWriter != null) { flowCsvWriter.Flush(); flowCsvWriter.Close(); flowCsvWriter.Dispose(); flowCsvWriter = null; } } catch { }
            try { if (levelsCsvWriter != null) { levelsCsvWriter.Flush(); levelsCsvWriter.Close(); levelsCsvWriter.Dispose(); levelsCsvWriter = null; } } catch { }
            try { if (depthCsvWriter != null) { depthCsvWriter.Flush(); depthCsvWriter.Close(); depthCsvWriter.Dispose(); depthCsvWriter = null; } } catch { }
            try { if (qualityCsvWriter != null) { qualityCsvWriter.Flush(); qualityCsvWriter.Close(); qualityCsvWriter.Dispose(); qualityCsvWriter = null; } } catch { }

            try { if (marketBinWriter != null) { marketBinWriter.Flush(); marketBinWriter.Close(); marketBinWriter.Dispose(); marketBinWriter = null; } } catch { }
            try { if (barBinWriter != null) { barBinWriter.Flush(); barBinWriter.Close(); barBinWriter.Dispose(); barBinWriter = null; } } catch { }
            try { if (flowBinWriter != null) { flowBinWriter.Flush(); flowBinWriter.Close(); flowBinWriter.Dispose(); flowBinWriter = null; } } catch { }
            try { if (levelsBinWriter != null) { levelsBinWriter.Flush(); levelsBinWriter.Close(); levelsBinWriter.Dispose(); levelsBinWriter = null; } } catch { }
            try { if (depthBinWriter != null) { depthBinWriter.Flush(); depthBinWriter.Close(); depthBinWriter.Dispose(); depthBinWriter = null; } } catch { }

            writersReady = false;
            WriteExportStatusFiles("STOPPED", DateTime.Now, true);
        }


        private void MaybeWriteExportStatus(DateTime marketTime, string state)
        {
            if (!ExportStatusFiles || string.IsNullOrWhiteSpace(runFolder))
                return;
            DateTime now = DateTime.Now;
            if (now < nextStatusWriteLocal && string.Equals(lastExportStatusState, state, StringComparison.OrdinalIgnoreCase))
                return;
            nextStatusWriteLocal = now.AddSeconds(Math.Max(1, StatusUpdateSeconds));
            WriteExportStatusFiles(state, marketTime, false);
        }

        private void WriteExportStatusFiles(string state, DateTime marketTime, bool force)
        {
            if (!ExportStatusFiles || string.IsNullOrWhiteSpace(runFolder))
                return;
            try
            {
                Directory.CreateDirectory(runFolder);
                lastExportStatusState = string.IsNullOrWhiteSpace(state) ? "UNKNOWN" : state;
                string txtPath = Path.Combine(runFolder, "export_status.txt");
                string jsonPath = Path.Combine(runFolder, "export_status.json");
                string missing = BuildMissingExportList();
                string layers = BuildLayerList();
                long marketBytes = FileSizeSafe("market.tape");
                long barsBytes = FileSizeSafe("bars.tape");
                long flowBytes = FileSizeSafe("flow.tape");
                long levelsBytes = FileSizeSafe("levels.tape");
                long depthBytes = FileSizeSafe("depth.tape");

                StringBuilder sb = new StringBuilder();
                sb.AppendLine("State=" + lastExportStatusState);
                sb.AppendLine("IsExporting=" + (EnableExport && writersReady ? "True" : "False"));
                sb.AppendLine("MarketTime=" + (marketTime == DateTime.MinValue ? string.Empty : marketTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)));
                sb.AppendLine("UpdatedLocal=" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC));
                sb.AppendLine("UpdatedUtc=" + DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffffffZ", IC));
                sb.AppendLine("RunFolder=" + runFolder);
                sb.AppendLine("PartitionDate=" + (currentPartitionDate == DateTime.MinValue ? string.Empty : currentPartitionDate.ToString("yyyy-MM-dd", IC)));
                sb.AppendLine("Instrument=" + (Instrument != null ? Instrument.FullName : string.Empty));
                sb.AppendLine("Layers=" + layers);
                sb.AppendLine("Missing=" + missing);
                sb.AppendLine("MarketRows=" + qualityMarketRows.ToString(IC));
                sb.AppendLine("DepthRows=" + qualityDepthRows.ToString(IC));
                sb.AppendLine("BarRows=" + qualityBarRows.ToString(IC));
                sb.AppendLine("FlowRows=" + qualityFlowRows.ToString(IC));
                sb.AppendLine("LevelRowsWritten=" + qualityLevelRowsWritten.ToString(IC));
                sb.AppendLine("LevelRowsExamined=" + qualityLevelRowsExamined.ToString(IC));
                sb.AppendLine("DuplicateLevelKeysSkipped=" + qualityDuplicateLevelKeysSkipped.ToString(IC));
                sb.AppendLine("EmptyLevelRows=" + qualityEmptyLevelRows.ToString(IC));
                sb.AppendLine("InvalidProbabilitiesClamped=" + qualityInvalidProbabilityValuesClamped.ToString(IC));
                sb.AppendLine("LookAheadRiskRows=" + qualityLookAheadRiskRows.ToString(IC));
                sb.AppendLine("MarketTapeBytes=" + marketBytes.ToString(IC));
                sb.AppendLine("BarsTapeBytes=" + barsBytes.ToString(IC));
                sb.AppendLine("FlowTapeBytes=" + flowBytes.ToString(IC));
                sb.AppendLine("LevelsTapeBytes=" + levelsBytes.ToString(IC));
                sb.AppendLine("DepthTapeBytes=" + depthBytes.ToString(IC));
                AtomicWriteText(txtPath, sb.ToString());

                using (StreamWriter w = new StreamWriter(jsonPath + ".tmp", false, Encoding.UTF8))
                {
                    w.WriteLine("{");
                    JsonLine(w, "state", lastExportStatusState, true, true);
                    JsonLine(w, "isExporting", EnableExport && writersReady ? "true" : "false", true, false);
                    JsonLine(w, "marketTime", marketTime == DateTime.MinValue ? string.Empty : marketTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC), true, true);
                    JsonLine(w, "updatedLocal", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC), true, true);
                    JsonLine(w, "runFolder", runFolder, true, true);
                    JsonLine(w, "layers", layers, true, true);
                    JsonLine(w, "missing", missing, true, true);
                    JsonLine(w, "marketRows", qualityMarketRows.ToString(IC), true, false);
                    JsonLine(w, "depthRows", qualityDepthRows.ToString(IC), true, false);
                    JsonLine(w, "barRows", qualityBarRows.ToString(IC), true, false);
                    JsonLine(w, "flowRows", qualityFlowRows.ToString(IC), true, false);
                    JsonLine(w, "levelRowsWritten", qualityLevelRowsWritten.ToString(IC), true, false);
                    JsonLine(w, "marketTapeBytes", marketBytes.ToString(IC), true, false);
                    JsonLine(w, "barsTapeBytes", barsBytes.ToString(IC), true, false);
                    JsonLine(w, "flowTapeBytes", flowBytes.ToString(IC), true, false);
                    JsonLine(w, "levelsTapeBytes", levelsBytes.ToString(IC), true, false);
                    JsonLine(w, "depthTapeBytes", depthBytes.ToString(IC), false, false);
                    w.WriteLine("}");
                }
                if (File.Exists(jsonPath)) File.Delete(jsonPath);
                File.Move(jsonPath + ".tmp", jsonPath);
            }
            catch { }
        }

        private string BuildLayerList()
        {
            List<string> layers = new List<string>();
            if (ExportBinary) layers.Add("binary");
            if (ExportCsvDebug) layers.Add("csv");
            layers.Add("market");
            if (ExportBars) layers.Add("bars");
            if (ExportEislerFlow) layers.Add("flow");
            if (ExportPriceLevels) layers.Add("levels");
            if (ExportDomDepth) layers.Add("depth");
            return string.Join(",", layers.ToArray());
        }

        private string BuildMissingExportList()
        {
            List<string> missing = new List<string>();
            if (ExportBinary)
            {
                CheckTapeMissing(missing, "market.tape", true);
                CheckTapeMissing(missing, "bars.tape", ExportBars);
                CheckTapeMissing(missing, "flow.tape", ExportEislerFlow);
                CheckTapeMissing(missing, "levels.tape", ExportPriceLevels);
                CheckTapeMissing(missing, "depth.tape", ExportDomDepth);
            }
            if (ExportCsvDebug)
            {
                CheckFileMissing(missing, "marketdata.csv", true);
                CheckFileMissing(missing, "bars.csv", ExportBars);
                CheckFileMissing(missing, "eislerflow.csv", ExportEislerFlow);
                CheckFileMissing(missing, "levels_bar_price.csv", ExportPriceLevels);
                CheckFileMissing(missing, "dom_depth_events.csv", ExportDomDepth);
            }
            CheckFileMissing(missing, "meta.json", true);
            return missing.Count == 0 ? "none" : string.Join(",", missing.ToArray());
        }

        private void CheckTapeMissing(List<string> missing, string fileName, bool expected)
        {
            if (!expected) return;
            long bytes = FileSizeSafe(fileName);
            if (bytes <= 40) missing.Add(fileName);
        }

        private void CheckFileMissing(List<string> missing, string fileName, bool expected)
        {
            if (!expected) return;
            long bytes = FileSizeSafe(fileName);
            if (bytes <= 0) missing.Add(fileName);
        }

        private long FileSizeSafe(string fileName)
        {
            try
            {
                string path = Path.Combine(runFolder, fileName);
                if (!File.Exists(path)) return 0;
                return new FileInfo(path).Length;
            }
            catch { return 0; }
        }

        private void AtomicWriteText(string path, string text)
        {
            try
            {
                string tmp = path + ".tmp";
                File.WriteAllText(tmp, text ?? string.Empty, Encoding.UTF8);
                if (File.Exists(path)) File.Delete(path);
                File.Move(tmp, path);
            }
            catch { }
        }

        private DateTime GetMarketDataTime(MarketDataEventArgs e)
        {
            try
            {
                if (e.Time != DateTime.MinValue)
                    return e.Time;
            }
            catch { }

            try
            {
                if (CurrentBar >= 0)
                    return Time[0];
            }
            catch { }

            return DateTime.Now;
        }

        private void ResetQualityCounters()
        {
            qualityMarketRows = 0;
            qualityDepthRows = 0;
            qualityBarRows = 0;
            qualityFlowRows = 0;
            qualityLevelRowsExamined = 0;
            qualityLevelRowsWritten = 0;
            qualityDuplicateLevelKeysSkipped = 0;
            qualityEmptyLevelRows = 0;
            qualityInvalidProbabilityValuesClamped = 0;
            qualityInvalidTickSizeRows = 0;
            qualityOpenBarLevelRows = 0;
            qualityLookAheadRiskRows = 0;
        }

        private void WriteQualityEvent(string eventType, int barIndex, DateTime t, double price, string message)
        {
            try
            {
                if (!ExportCsvDebug || qualityCsvWriter == null)
                    return;

                qualityCsvWriter.Write(t == DateTime.MinValue ? "0" : t.Ticks.ToString(IC)); qualityCsvWriter.Write(';');
                qualityCsvWriter.Write(t == DateTime.MinValue ? string.Empty : t.ToString("yyyy-MM-dd HH:mm:ss.fffffff", IC)); qualityCsvWriter.Write(';');
                qualityCsvWriter.Write(eventType ?? string.Empty); qualityCsvWriter.Write(';');
                qualityCsvWriter.Write(barIndex.ToString(IC)); qualityCsvWriter.Write(';');
                WriteD(qualityCsvWriter, price); qualityCsvWriter.Write(';');
                qualityCsvWriter.Write((message ?? string.Empty).Replace(";", ","));
                qualityCsvWriter.WriteLine();

                if (FlushEveryLine)
                    qualityCsvWriter.Flush();
            }
            catch { }
        }

        private void WriteQualitySummaryJson()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(runFolder) || !Directory.Exists(runFolder))
                    return;

                string path = Path.Combine(runFolder, "quality_summary.json");
                using (StreamWriter w = new StreamWriter(path, false, Encoding.UTF8))
                {
                    w.WriteLine("{");
                    JsonLine(w, "exporterVersion", ExporterVersion, true, true);
                    JsonLine(w, "createdUtc", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffffffZ", IC), true, true);
                    JsonLine(w, "marketRows", qualityMarketRows.ToString(IC), true, false);
                    JsonLine(w, "depthRows", qualityDepthRows.ToString(IC), true, false);
                    JsonLine(w, "barRows", qualityBarRows.ToString(IC), true, false);
                    JsonLine(w, "flowRows", qualityFlowRows.ToString(IC), true, false);
                    JsonLine(w, "levelRowsExamined", qualityLevelRowsExamined.ToString(IC), true, false);
                    JsonLine(w, "levelRowsWritten", qualityLevelRowsWritten.ToString(IC), true, false);
                    JsonLine(w, "duplicateLevelKeysSkipped", qualityDuplicateLevelKeysSkipped.ToString(IC), true, false);
                    JsonLine(w, "emptyLevelRows", qualityEmptyLevelRows.ToString(IC), true, false);
                    JsonLine(w, "invalidProbabilityValuesClamped", qualityInvalidProbabilityValuesClamped.ToString(IC), true, false);
                    JsonLine(w, "invalidTickSizeRows", qualityInvalidTickSizeRows.ToString(IC), true, false);
                    JsonLine(w, "openBarLevelRows", qualityOpenBarLevelRows.ToString(IC), true, false);
                    JsonLine(w, "lookAheadRiskRows", qualityLookAheadRiskRows.ToString(IC), true, false);
                    JsonLine(w, "levelPrimaryKey", "BarIndex+TimeTicks+Price", true, true);
                    JsonLine(w, "duplicatePolicy", "SkipDuplicateAfterTickNormalization", true, true);
                    JsonLine(w, "probabilityPolicy", "ClampToRange_0_1_AndFlag", true, true);
                    JsonLine(w, "lookAheadPolicy", "ClosedBarsAreSafe_OpenBarOnTerminationIsFlagged", false, true);
                    w.WriteLine("}");
                }
            }
            catch { }
        }

        private double NormalizePriceToTick(double price, out bool tickSizeValid)
        {
            tickSizeValid = true;
            price = SafeD(price);

            if (TickSize <= 0)
                return price;

            double tickIndex = Math.Round(price / TickSize, 0, MidpointRounding.AwayFromZero);
            double normalized = tickIndex * TickSize;
            double tolerance = Math.Max(1e-10, TickSize * 1e-6);

            if (Math.Abs(normalized - price) > tolerance)
                tickSizeValid = false;

            return normalized;
        }

        private long PriceToTickKey(double price)
        {
            if (TickSize <= 0)
                return (long)Math.Round(price * 100000000.0, 0, MidpointRounding.AwayFromZero);

            return (long)Math.Round(price / TickSize, 0, MidpointRounding.AwayFromZero);
        }

        private static double ClampProbability(double v, ref bool valid)
        {
            v = SafeD(v);
            if (v < 0.0)
            {
                valid = false;
                return 0.0;
            }
            if (v > 1.0)
            {
                valid = false;
                return 1.0;
            }
            return v;
        }

        private static string BoolInt(bool value)
        {
            return value ? "1" : "0";
        }

        private static byte MarketDepthOperationToByte(object operation)
{
    string op = operation.ToString();

    if (op == "Insert" || op == "Add")
        return 1;

    if (op == "Update" || op == "Change")
        return 2;

    if (op == "Remove" || op == "Delete")
        return 3;

    return 0;
}

        private static double SafeD(double v)
        {
            if (double.IsNaN(v) || double.IsInfinity(v))
                return 0.0;
            return v;
        }

        private static void WriteD(StreamWriter w, double v)
        {
            if (double.IsNaN(v) || double.IsInfinity(v))
                w.Write("0");
            else
                w.Write(v.ToString("F8", IC));
        }

        private void JsonLine(StreamWriter w, string name, string value, bool comma, bool quoteValue)
        {
            w.Write("  \"");
            w.Write(JsonEscape(name));
            w.Write("\": ");
            if (quoteValue)
            {
                w.Write("\"");
                w.Write(JsonEscape(value));
                w.Write("\"");
            }
            else
            {
                w.Write(value);
            }
            if (comma)
                w.Write(',');
            w.WriteLine();
        }

        private static string SanitizeFileName(string s)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                s = s.Replace(c, '_');
            return s;
        }

        private static string SanitizePartitionValue(string s)
        {
            if (string.IsNullOrWhiteSpace(s))
                return "UNKNOWN";

            s = s.Trim().Replace(' ', '_');
            foreach (char c in Path.GetInvalidFileNameChars())
                s = s.Replace(c, '_');
            s = s.Replace('/', '_').Replace('\\', '_').Replace(':', '_').Replace(';', '_');
            return s;
        }

        private static string JsonEscape(string s)
        {
            if (s == null)
                return string.Empty;
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", " ");
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EislerPhase1DataExporter_V3[] cacheEislerPhase1DataExporter_V3;
		public EislerPhase1DataExporter_V3 EislerPhase1DataExporter_V3(bool enableExport, string outputSubFolder, string runId, bool useResearchPartitionFolders, bool includeRunIdFolder, int atrPeriod, bool exportBinary, bool exportCsvDebug, bool flushEveryLine, bool exportStatusFiles, int statusUpdateSeconds, bool exportBars, bool exportEislerFlow, bool exportPriceLevels, bool exportDomDepth, bool exportLastOpenBarOnTermination)
		{
			return EislerPhase1DataExporter_V3(Input, enableExport, outputSubFolder, runId, useResearchPartitionFolders, includeRunIdFolder, atrPeriod, exportBinary, exportCsvDebug, flushEveryLine, exportStatusFiles, statusUpdateSeconds, exportBars, exportEislerFlow, exportPriceLevels, exportDomDepth, exportLastOpenBarOnTermination);
		}

		public EislerPhase1DataExporter_V3 EislerPhase1DataExporter_V3(ISeries<double> input, bool enableExport, string outputSubFolder, string runId, bool useResearchPartitionFolders, bool includeRunIdFolder, int atrPeriod, bool exportBinary, bool exportCsvDebug, bool flushEveryLine, bool exportStatusFiles, int statusUpdateSeconds, bool exportBars, bool exportEislerFlow, bool exportPriceLevels, bool exportDomDepth, bool exportLastOpenBarOnTermination)
		{
			if (cacheEislerPhase1DataExporter_V3 != null)
				for (int idx = 0; idx < cacheEislerPhase1DataExporter_V3.Length; idx++)
					if (cacheEislerPhase1DataExporter_V3[idx] != null && cacheEislerPhase1DataExporter_V3[idx].EnableExport == enableExport && cacheEislerPhase1DataExporter_V3[idx].OutputSubFolder == outputSubFolder && cacheEislerPhase1DataExporter_V3[idx].RunId == runId && cacheEislerPhase1DataExporter_V3[idx].UseResearchPartitionFolders == useResearchPartitionFolders && cacheEislerPhase1DataExporter_V3[idx].IncludeRunIdFolder == includeRunIdFolder && cacheEislerPhase1DataExporter_V3[idx].AtrPeriod == atrPeriod && cacheEislerPhase1DataExporter_V3[idx].ExportBinary == exportBinary && cacheEislerPhase1DataExporter_V3[idx].ExportCsvDebug == exportCsvDebug && cacheEislerPhase1DataExporter_V3[idx].FlushEveryLine == flushEveryLine && cacheEislerPhase1DataExporter_V3[idx].ExportStatusFiles == exportStatusFiles && cacheEislerPhase1DataExporter_V3[idx].StatusUpdateSeconds == statusUpdateSeconds && cacheEislerPhase1DataExporter_V3[idx].ExportBars == exportBars && cacheEislerPhase1DataExporter_V3[idx].ExportEislerFlow == exportEislerFlow && cacheEislerPhase1DataExporter_V3[idx].ExportPriceLevels == exportPriceLevels && cacheEislerPhase1DataExporter_V3[idx].ExportDomDepth == exportDomDepth && cacheEislerPhase1DataExporter_V3[idx].ExportLastOpenBarOnTermination == exportLastOpenBarOnTermination && cacheEislerPhase1DataExporter_V3[idx].EqualsInput(input))
						return cacheEislerPhase1DataExporter_V3[idx];
			return CacheIndicator<EislerPhase1DataExporter_V3>(new EislerPhase1DataExporter_V3(){ EnableExport = enableExport, OutputSubFolder = outputSubFolder, RunId = runId, UseResearchPartitionFolders = useResearchPartitionFolders, IncludeRunIdFolder = includeRunIdFolder, AtrPeriod = atrPeriod, ExportBinary = exportBinary, ExportCsvDebug = exportCsvDebug, FlushEveryLine = flushEveryLine, ExportStatusFiles = exportStatusFiles, StatusUpdateSeconds = statusUpdateSeconds, ExportBars = exportBars, ExportEislerFlow = exportEislerFlow, ExportPriceLevels = exportPriceLevels, ExportDomDepth = exportDomDepth, ExportLastOpenBarOnTermination = exportLastOpenBarOnTermination }, input, ref cacheEislerPhase1DataExporter_V3);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EislerPhase1DataExporter_V3 EislerPhase1DataExporter_V3(bool enableExport, string outputSubFolder, string runId, bool useResearchPartitionFolders, bool includeRunIdFolder, int atrPeriod, bool exportBinary, bool exportCsvDebug, bool flushEveryLine, bool exportStatusFiles, int statusUpdateSeconds, bool exportBars, bool exportEislerFlow, bool exportPriceLevels, bool exportDomDepth, bool exportLastOpenBarOnTermination)
		{
			return indicator.EislerPhase1DataExporter_V3(Input, enableExport, outputSubFolder, runId, useResearchPartitionFolders, includeRunIdFolder, atrPeriod, exportBinary, exportCsvDebug, flushEveryLine, exportStatusFiles, statusUpdateSeconds, exportBars, exportEislerFlow, exportPriceLevels, exportDomDepth, exportLastOpenBarOnTermination);
		}

		public Indicators.EislerPhase1DataExporter_V3 EislerPhase1DataExporter_V3(ISeries<double> input , bool enableExport, string outputSubFolder, string runId, bool useResearchPartitionFolders, bool includeRunIdFolder, int atrPeriod, bool exportBinary, bool exportCsvDebug, bool flushEveryLine, bool exportStatusFiles, int statusUpdateSeconds, bool exportBars, bool exportEislerFlow, bool exportPriceLevels, bool exportDomDepth, bool exportLastOpenBarOnTermination)
		{
			return indicator.EislerPhase1DataExporter_V3(input, enableExport, outputSubFolder, runId, useResearchPartitionFolders, includeRunIdFolder, atrPeriod, exportBinary, exportCsvDebug, flushEveryLine, exportStatusFiles, statusUpdateSeconds, exportBars, exportEislerFlow, exportPriceLevels, exportDomDepth, exportLastOpenBarOnTermination);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EislerPhase1DataExporter_V3 EislerPhase1DataExporter_V3(bool enableExport, string outputSubFolder, string runId, bool useResearchPartitionFolders, bool includeRunIdFolder, int atrPeriod, bool exportBinary, bool exportCsvDebug, bool flushEveryLine, bool exportStatusFiles, int statusUpdateSeconds, bool exportBars, bool exportEislerFlow, bool exportPriceLevels, bool exportDomDepth, bool exportLastOpenBarOnTermination)
		{
			return indicator.EislerPhase1DataExporter_V3(Input, enableExport, outputSubFolder, runId, useResearchPartitionFolders, includeRunIdFolder, atrPeriod, exportBinary, exportCsvDebug, flushEveryLine, exportStatusFiles, statusUpdateSeconds, exportBars, exportEislerFlow, exportPriceLevels, exportDomDepth, exportLastOpenBarOnTermination);
		}

		public Indicators.EislerPhase1DataExporter_V3 EislerPhase1DataExporter_V3(ISeries<double> input , bool enableExport, string outputSubFolder, string runId, bool useResearchPartitionFolders, bool includeRunIdFolder, int atrPeriod, bool exportBinary, bool exportCsvDebug, bool flushEveryLine, bool exportStatusFiles, int statusUpdateSeconds, bool exportBars, bool exportEislerFlow, bool exportPriceLevels, bool exportDomDepth, bool exportLastOpenBarOnTermination)
		{
			return indicator.EislerPhase1DataExporter_V3(input, enableExport, outputSubFolder, runId, useResearchPartitionFolders, includeRunIdFolder, atrPeriod, exportBinary, exportCsvDebug, flushEveryLine, exportStatusFiles, statusUpdateSeconds, exportBars, exportEislerFlow, exportPriceLevels, exportDomDepth, exportLastOpenBarOnTermination);
		}
	}
}

#endregion
