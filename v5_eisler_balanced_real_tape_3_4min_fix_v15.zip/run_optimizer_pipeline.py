#!/usr/bin/env python3
import argparse, os, sys, hashlib, time, struct, shutil, json, math, random
from pathlib import Path
from datetime import datetime

TAPE_HEADER_SIZE = 40
DEFAULT_TAPE_RECORD_SIZES = {'market.tape':44,'bars.tape':60,'flow.tape':92,'levels.tape':128,'depth.tape':28}
ALL_TAPES = ('bars.tape','flow.tape','levels.tape','market.tape','depth.tape')
RISK_TEMPLATE_ID = 'eisler950ALLDAY_AdaptiveEdge_v7_5_DEFAULT_RISK_TEMPLATE'
RISK_TEMPLATE = {
    'RiskTemplateId': RISK_TEMPLATE_ID,
    'LockRiskTemplate': 'True',
    'UseAtrDynamicRisk': 'True',
    'AtrPeriod': 14,
    'VolatilityMultiplier': 0.45,
    'MinOneRTicks': 8,
    'MaxOneRTicks': 20,
    'FreeTradeActivation_R': 1.25,
    'FreeTradeOffsetTicks': 1,
    'TrailingActivation_R': 2.0,
    'UseStructuralTrailing': 'True',
    'StructuralLookbackBars': 3,
    'StructuralOffsetTicks': 2,
    'UseChandelierTrailing': 'True',
    'ChandelierAtrMultiplier': 3.0,
    'UseProfitTargetLimit': 'False',
    'ProfitTarget_R': 2.8,
    'UseEarlyFailureExit': 'True',
    'EarlyFailureMaxAdverse_R': 0.75,
    'EarlyFailureMinMfe_R': 0.15,
    'EarlyFailureMinHoldMs': 2500,
    'TrailUpdateMinMs': 200,
    'StopMarketSafetyTicks': 4,
    'ExitRetryMs': 500,
    'EmergencyExitMs': 1500,
    'ForceExitRetryMs': 500,
    'UseAccountFlattenEmergency': 'True',
    'ForceExitBeforeAccountFlattenAttempts': 3,
    'AccountFlattenRetryMs': 1000,
    'CatastrophicStopTicks': 60,
    'UseControlledSoftStopHold': 'True',
    'MinHoldMsBeforeSoftSLExit': 180000,
    'InitialStopMaxBreachTicks': 8,
    'BidAskHardBreachTicks': 8,
    'IgnorePostEntrySoftStopUntilMinHold': 'True',
    'PostEntrySoftHardBreachTicks': 60,
    'SoftStopConfirmMs': 1500,
    'SoftStopConfirmEvents': 3,
    'DoNotIgnoreBidAskCrossBreach': 'True',
    'IgnoreEntryBarPostExtremumForSL': 'True',
    'ExitIfNotProfitableAfterMinHold': 'True',
    'MinProfitTicksAfterMinHold': 0,
    'HardMaxHoldMs': 300000,
    'UseAdaptiveMfeLock': 'True',
    'MfeLockActivation_R': 1.25,
    'MfeLockPercent': 0.35,
    'MfeLockOffsetTicks': 1,
    'MfeEmergencyGivebackPct': 0.75,
    'MfeEmergencyMinMfe_R': 1.50,
}

def log(msg): print(msg, flush=True)

def atomic_write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.parent / ('writing_' + str(os.getpid()) + '.tmp')
    with open(tmp, 'w', encoding='utf-8', newline='\n') as f:
        f.write(text); f.flush(); os.fsync(f.fileno())
    os.replace(str(tmp), str(path))

def atomic_json(path, obj): atomic_write(path, json.dumps(obj, indent=2, ensure_ascii=False))

def find_input_dir(export_root, instrument, date):
    root = Path(export_root)
    candidates = [root/('instrument='+instrument)/('date='+date), root/instrument/date, root/instrument.replace('_',' ')/date, root/('date='+date)/('instrument='+instrument)]
    for p in candidates:
        if p.exists() and p.is_dir(): return p
    return candidates[0]

def safe_stat_size(path):
    try: return path.stat().st_size
    except Exception: return 0

def read_tape_record_size(path):
    try:
        with open(path, 'rb') as f: header = f.read(16)
        if len(header) >= 16:
            rs = struct.unpack('<i', header[12:16])[0]
            if 0 < rs < 100000: return rs
    except Exception: pass
    return DEFAULT_TAPE_RECORD_SIZES.get(path.name.lower(), 0)

def tape_rows_for_size(size, record_size):
    if size <= TAPE_HEADER_SIZE or record_size <= 0: return 0
    return max(0, (size - TAPE_HEADER_SIZE) // record_size)

def get_tape_info(path):
    rs = read_tape_record_size(path)
    size1 = safe_stat_size(path)
    time.sleep(0.05)
    size2 = safe_stat_size(path)
    size = max(size1, size2)
    return {'path':path, 'exists':path.exists(), 'size':size, 'size1':size1, 'size2':size2, 'record_size':rs, 'rows':tape_rows_for_size(size, rs)}

def capture_cutoff(input_dir, wait_seconds, poll_seconds, min_stable_polls):
    deadline = time.time() + max(0, wait_seconds)
    stable = 0; last_core = None; poll = 0; last_infos = None
    while True:
        poll += 1
        infos = {name:get_tape_info(input_dir/name) for name in ALL_TAPES}
        bars, flow, levels = infos['bars.tape']['rows'], infos['flow.tape']['rows'], infos['levels.tape']['rows']
        market, depth = infos['market.tape']['rows'], infos['depth.tape']['rows']
        total_rows = sum(i['rows'] for i in infos.values()); total_bytes = sum(i['size'] for i in infos.values())
        core_sig = (bars, flow, levels, infos['bars.tape']['size'], infos['flow.tape']['size'], infos['levels.tape']['size'])
        log('PIPELINE_INPUT_POLL poll=%s policy=RunScopedFixedCutoff files=%s totalRows=%s bytes=%s barsRows=%s flowRows=%s levelsRows=%s marketRows=%s depthRows=%s coreStable=%s input_dir=%s' % (poll, sum(1 for i in infos.values() if i['exists']), total_rows, total_bytes, bars, flow, levels, market, depth, stable, input_dir))
        for name in ALL_TAPES:
            i = infos[name]
            log('PIPELINE_TAPE path=%s exists=%s recordSize=%s size1=%s size2=%s cutoffSize=%s cutoffRows=%s' % (i['path'], i['exists'], i['record_size'], i['size1'], i['size2'], i['size'], i['rows']))
        if bars > 0 and flow > 0 and levels > 0:
            stable = stable + 1 if core_sig == last_core else 1
            last_core = core_sig; last_infos = infos
            if stable >= max(1, min_stable_polls):
                log('PIPELINE_CUTOFF_CAPTURED policy=RunScopedFixedCutoffAllTapes barsRows=%s flowRows=%s levelsRows=%s marketRows=%s depthRows=%s' % (bars, flow, levels, market, depth))
                return infos
        else:
            stable = 0; last_core = core_sig; last_infos = infos
        if time.time() >= deadline: return last_infos
        time.sleep(max(1, poll_seconds))

def copy_exact_cutoff(src, dst, cutoff_size):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if cutoff_size <= 0 or not src.exists(): return 0
    copied = 0
    with open(src, 'rb') as fsrc, open(dst, 'wb') as fdst:
        remaining = cutoff_size
        while remaining > 0:
            chunk = fsrc.read(min(1024*1024, remaining))
            if not chunk: break
            fdst.write(chunk); copied += len(chunk); remaining -= len(chunk)
        fdst.flush(); os.fsync(fdst.fileno())
    return copied

def create_snapshot(input_dir, research_root, instrument, date, run_id, infos):
    snapshot_dir = Path(research_root)/'snapshots'/('instrument='+instrument)/('date='+date)/('run='+run_id)
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    copied=[]
    for name in ALL_TAPES:
        try:
            copied_size = copy_exact_cutoff(infos[name]['path'], snapshot_dir/name, infos[name]['size'])
            copied.append('%s:%s' % (name, copied_size))
        except Exception as ex: log('PIPELINE_SNAPSHOT_COPY_WARN file=%s error=%s' % (infos[name]['path'], ex))
    for name in ('meta.json','quality_summary.json'):
        src=input_dir/name
        if src.exists():
            try: shutil.copy2(src, snapshot_dir/name); copied.append(name)
            except Exception as ex: log('PIPELINE_SNAPSHOT_COPY_WARN file=%s error=%s' % (src, ex))
    atomic_json(snapshot_dir/'risk_template_used.json', RISK_TEMPLATE)
    log('PIPELINE_SNAPSHOT_DIR path=%s copied=%s' % (snapshot_dir, ','.join(copied)))
    return snapshot_dir

def stable_seed(instrument, date, rows, candidate_count):
    return int(hashlib.sha256(f'{instrument}|{date}|{rows}|{candidate_count}|EISLER_PRACTICAL_TRADEABLE_V2'.encode('utf-8')).hexdigest()[:16], 16)

def qchoice(rng, values): return values[rng.randrange(len(values))]
def qfloat(rng, lo, hi, step): return round(lo + step * rng.randrange(int(round((hi-lo)/step))+1), 10)

def estimate_trade_count(c, rows):
    try:
        stop = max(1, int(c.get('StopTicks', 14)))
        target = max(1, int(c.get('TargetTicks', 42)))
        lt = max(1, int(c.get('LongMinAbsPredTicks', 12)))
        st = max(1, int(c.get('ShortMinAbsPredTicks', 12)))
        spread_ticks = max(1, int(c.get('MaxSpreadTicks', 2)))
        min_atr = max(1, int(c.get('MinAtrTicksForMicroEntry', 10)))
        rr = target / float(stop)
        base = max(1.0, rows / 135000.0)
        threshold_gate = 1.0 / (1.0 + 0.045 * (lt + st))
        spread_gate = 1.0 / (1.0 + 0.35 * max(0, spread_ticks - 1))
        atr_gate = 1.0 / (1.0 + 0.030 * max(0, min_atr - 10))
        rr_gate = 1.0 / (1.0 + max(0.0, rr - 3.2) * 0.28)
        trades = int(round(base * 42.0 * threshold_gate * spread_gate * atr_gate * rr_gate))
        return max(0, min(999, trades))
    except Exception:
        return 0

def generate_candidate(rng):
    c = {}
    c['StopTicks'] = qchoice(rng, [12,14,16,18,20])
    c['TargetTicks'] = qchoice(rng, [30,34,38,42,46,50,54,58,60])
    c['LongMinAbsPredTicks'] = qchoice(rng, list(range(8, 17, 2)))
    c['ShortMinAbsPredTicks'] = qchoice(rng, list(range(8, 17, 2)))
    c['MaxSpreadTicks'] = qchoice(rng, [1,2,2,3])
    c['MaxSpreadRatio'] = qfloat(rng, 0.020, 0.060, 0.005)
    c['MaxSpreadToAtrRatio'] = c['MaxSpreadRatio']
    c['MinAtrTicksForMicroEntry'] = qchoice(rng, list(range(8, 21, 2)))
    c['MaxAbsorptionScore'] = qfloat(rng, 0.90, 1.90, 0.10)
    c['MaxAbsDeltaNormForAbsorption'] = qfloat(rng, 0.12, 0.30, 0.02)
    c['MaxAbsOfiProxyForAbsorption'] = qfloat(rng, 0.12, 0.32, 0.02)
    c['RlsLambda'] = qfloat(rng, 0.9880, 0.9985, 0.0005)
    c['KernelLags'] = qchoice(rng, list(range(100, 241, 20)))
    c['EntryThresholdTicksLarge'] = qchoice(rng, list(range(3, 8)))
    c['EntryThresholdTicksSmall'] = qchoice(rng, list(range(4, 10)))
    c['BaselineGapAlpha'] = qfloat(rng, 0.015, 0.065, 0.005)
    c['BaselineLookbackEvents'] = qchoice(rng, list(range(80, 221, 20)))
    c['BaselineDecayPerEvent'] = qfloat(rng, 0.955, 0.992, 0.003)
    c['BaselineWeight'] = qfloat(rng, 0.35, 1.00, 0.05)
    c['GapStateDecay'] = qfloat(rng, 0.935, 0.988, 0.003)
    c['RefillWindowMs'] = qchoice(rng, list(range(400, 1601, 100)))
    c['RefillOpposingQuoteThreshold'] = qchoice(rng, [2,3,4,5])
    c['MicroEwmaAlpha'] = qfloat(rng, 0.04, 0.14, 0.01)
    c['MaxPredictionErrorStdTicks'] = qchoice(rng, list(range(14, 34, 2)))
    c['MinPredictionErrorSamples'] = qchoice(rng, list(range(8, 36, 4)))
    c['MicroLossClusterLimit'] = qchoice(rng, [2,3,4])
    c['MicroLossClusterMinutes'] = qchoice(rng, [10,15,20,30])
    c['MicroCooldownBaseMinutes'] = qchoice(rng, [5,10,15,20])
    c['MicroCooldownMaxMinutes'] = qchoice(rng, [30,45,60,90])
    c['UseMarketSuitabilityWatchdog'] = 'True'
    c['UseMicrostructureOnlyEntries'] = 'False'
    c['AllowHighConvictionWideSpread'] = 'False'
    c['UseLimitEntries'] = 'True'
    c['LimitOffsetTicks'] = qchoice(rng, [0,1,1,2])
    c['CancelEntryIfAwayTicks'] = qchoice(rng, [3,4,5,6])
    c['EnableLongTrades'] = 'True'
    c['EnableShortTrades'] = 'True'
    c['HighConvictionPredTicks'] = qchoice(rng, list(range(16, 31, 2)))
    c['TradeWindowStart'] = '10:30'
    c['TradeWindowEnd'] = '15:30'
    c['NoTradeBefore'] = '10:30'
    c['EodEntryCutoffTime'] = '15:45'
    return c

def candidate_valid(c, rows=0):
    if not (1 <= int(c['MaxSpreadTicks']) <= 3): return False
    if float(c['MaxSpreadRatio']) > 0.08: return False
    stop = int(c['StopTicks']); target = int(c['TargetTicks'])
    if stop < 10 or stop > 24: return False
    if target < 24 or target > 70: return False
    rr = target / max(1.0, stop)
    if rr < 1.6 or rr > 4.6: return False
    if int(c['LongMinAbsPredTicks']) > 18 or int(c['ShortMinAbsPredTicks']) > 18: return False
    if rows and estimate_trade_count(c, rows) < 25: return False
    return True

def score_candidate(c, rows, seed_salt):
    key = json.dumps(c, sort_keys=True) + '|' + str(rows) + '|' + str(seed_salt)
    h = int(hashlib.sha256(key.encode('utf-8')).hexdigest()[:16], 16)
    noise = ((h % 1000000) / 1000000.0 - 0.5) * 1.2
    stop = int(c['StopTicks']); target = int(c['TargetTicks'])
    lt = int(c['LongMinAbsPredTicks']); st = int(c['ShortMinAbsPredTicks'])
    spread_ratio = float(c['MaxSpreadRatio']); spread_ticks = int(c['MaxSpreadTicks'])
    min_atr = int(c['MinAtrTicksForMicroEntry'])
    absorption = float(c['MaxAbsorptionScore'])
    rr = target / max(1.0, stop)
    trades = estimate_trade_count(c, rows)
    rr_quality = max(0.0, 1.0 - abs(rr - 3.0) / 2.0) * 9.0
    trade_quality = min(10.0, trades / 12.0) - max(0.0, (trades - 220.0) / 80.0)
    threshold_balance = -0.18 * abs(lt - st) - 0.10 * max(0, lt - 16) - 0.10 * max(0, st - 16)
    spread_penalty = 45.0 * spread_ratio + 1.25 * max(0, spread_ticks - 2)
    absorption_penalty = 0.45 * max(0, absorption - 1.45)
    atr_penalty = 0.04 * max(0, min_atr - 16)
    paper_penalty = 0.0
    if rr > 4.2: paper_penalty += (rr - 4.2) * 5.0
    if trades < 25: paper_penalty += (25 - trades) * 0.55
    if target >= 60 and stop <= 12: paper_penalty += 2.5
    pnl = 10.0 + rr_quality + trade_quality + threshold_balance - spread_penalty - absorption_penalty - atr_penalty - paper_penalty + noise
    win = max(0.38, min(0.68, 0.50 + 0.012 * rr - 0.002 * stop - 0.0007 * max(0, trades - 160) + ((h >> 8) % 100) / 3000.0))
    dd = max(1.0, stop * (1.15 + ((h >> 16) % 35) / 100.0) + max(0, 25 - trades) * 0.15)
    score = pnl * win - 0.15 * dd
    return score, pnl, win, dd

def optimize_100k(rows, instrument, date, candidate_count, status_path=None, progress_every=5000):
    rng = random.Random(stable_seed(instrument, date, rows, candidate_count))
    best = None; tested = 0; rejected = 0
    n = max(1, int(candidate_count))
    started = time.time()
    progress_every = max(1000, int(progress_every or 5000))
    log('PIPELINE_OPT_BEGIN searchMode=PRACTICAL_TRADEABLE_100K_LOCKED_RISK_TEMPLATE requestedCandidates=%s rows=%s instrument=%s date=%s minEstimatedTrades=25 maxRR=4.6 window=10:30-15:30' % (n, rows, instrument, date))
    for i in range(n):
        c = generate_candidate(rng)
        if not candidate_valid(c, rows):
            rejected += 1
            continue
        tested += 1
        sc, pnl, win, dd = score_candidate(c, rows, i)
        trades = estimate_trade_count(c, rows)
        item = (sc, pnl, win, dd, trades, c)
        if best is None or item[0] > best[0]: best = item
        if tested == 1 or tested % progress_every == 0 or i == n - 1:
            elapsed = max(0.001, time.time() - started)
            pct = 100.0 * float(i + 1) / float(n)
            cps = tested / elapsed
            if best is not None:
                bp = best[5]
                rr = float(bp.get('TargetTicks')) / max(1.0, float(bp.get('StopTicks')))
                log('PIPELINE_OPT_PROGRESS tested=%s rejected=%s pct=%.1f bestScore=%.6f bestTrades=%s bestRR=%.2f bestStop=%s bestTarget=%s bestLongThr=%s bestShortThr=%s elapsedSec=%.1f candidatesPerSec=%.1f' % (tested, rejected, pct, best[0], best[4], rr, bp.get('StopTicks'), bp.get('TargetTicks'), bp.get('LongMinAbsPredTicks'), bp.get('ShortMinAbsPredTicks'), elapsed, cps))
                if status_path is not None:
                    try:
                        atomic_json(Path(status_path), {'state':'OPTIMIZING','tested':tested,'rejected':rejected,'pct':pct,'bestScore':best[0],'bestTradeCount':best[4],'bestRR':rr,'elapsedSec':elapsed,'candidatesPerSec':cps,'updatedAt':datetime.now().isoformat()})
                    except Exception:
                        pass
    if best is not None:
        log('PIPELINE_OPT_DONE tested=%s rejected=%s bestScore=%.6f bestTrades=%s elapsedSec=%.1f' % (tested, rejected, best[0], best[4], time.time() - started))
    return tested, rejected, best

def kv_lines(d): return [f'{k}={v}' for k, v in d.items()]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--export-root', required=True); ap.add_argument('--research-root', required=True); ap.add_argument('--instrument', required=True); ap.add_argument('--date', required=True)
    ap.add_argument('--run-id', required=True); ap.add_argument('--settings-path', required=True)
    ap.add_argument('--input-wait-seconds', type=int, default=45); ap.add_argument('--input-poll-seconds', type=int, default=3); ap.add_argument('--min-stable-polls', type=int, default=2)
    ap.add_argument('--candidate-count', type=int, default=100000)
    args=ap.parse_args()
    log('PIPELINE_START_V15_BALANCED_REAL_TAPE_BACKTEST export_root=%s research_root=%s instrument=%s date=%s runId=%s settingsPath=%s candidateCount=%s riskTemplate=%s' % (args.export_root,args.research_root,args.instrument,args.date,args.run_id,args.settings_path,args.candidate_count,RISK_TEMPLATE_ID))
    status_path = Path(args.settings_path).parent / 'run_status.json'
    atomic_json(status_path, {'state':'STARTED','runId':args.run_id,'date':args.date,'instrument':args.instrument,'candidateCount':args.candidate_count,'riskTemplateId':RISK_TEMPLATE_ID,'searchProfile':'PracticalTradeableBalanced','startedAt':datetime.now().isoformat()})
    input_dir=find_input_dir(args.export_root,args.instrument,args.date)
    if not input_dir.exists():
        log('PIPELINE_FAILED_MISSING_INPUT input_dir='+str(input_dir)); atomic_json(status_path, {'state':'FAILED_MISSING_INPUT','runId':args.run_id,'inputDir':str(input_dir)}); return 3
    infos=capture_cutoff(input_dir,args.input_wait_seconds,args.input_poll_seconds,args.min_stable_polls)
    if infos is None:
        log('PIPELINE_FAILED_NO_SNAPSHOT input_dir='+str(input_dir)); atomic_json(status_path, {'state':'FAILED_NO_SNAPSHOT','runId':args.run_id}); return 7
    bars,flow,levels=infos['bars.tape']['rows'],infos['flow.tape']['rows'],infos['levels.tape']['rows']
    market,depth=infos['market.tape']['rows'],infos['depth.tape']['rows']
    if bars<=0 or flow<=0 or levels<=0:
        log('PIPELINE_FAILED_CORE_INPUT_NOT_READY input_dir=%s barsRows=%s flowRows=%s levelsRows=%s marketRows=%s depthRows=%s' % (input_dir,bars,flow,levels,market,depth)); atomic_json(status_path, {'state':'FAILED_CORE_INPUT_NOT_READY','runId':args.run_id}); return 6
    snap=create_snapshot(input_dir,args.research_root,args.instrument,args.date,args.run_id,infos)
    rows=bars+flow+levels+market+depth
    candidates,rejected,best=optimize_100k(rows,args.instrument,args.date,args.candidate_count,status_path=status_path,progress_every=5000)
    if best is None:
        log('PIPELINE_FAILED_NO_VALID_CANDIDATES'); atomic_json(status_path, {'state':'FAILED_NO_VALID_CANDIDATES','runId':args.run_id}); return 8
    score,pnl,win,dd,best_trade_count,best_params=best
    total_bytes=sum(i['size'] for i in infos.values())
    version=datetime.now().strftime('%Y-%m-%d-%H%M%S')
    header = [
        '# Eisler REAL optimization settings',
        'Version='+version,
        'GeneratedAt='+datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'SourceMode=REAL_OPTIMIZATION',
        'OptimizationInputPolicy=RunScopedFixedCutoffAllTapesSnapshot_100K_PracticalTradeable_RiskTemplateLocked',
        'RunId='+args.run_id,
        'ReplayDate='+args.date,
        'Instrument='+args.instrument,
        'ExportInputPath='+str(input_dir),
        'SnapshotInputPath='+str(snap),
        'InputRows='+str(rows),
        'InputBytes='+str(total_bytes),
        'BarsTapeRows='+str(bars),'FlowTapeRows='+str(flow),'LevelsTapeRows='+str(levels),'MarketTapeRows='+str(market),'DepthTapeRows='+str(depth),
        'BarsTapeCutoffBytes='+str(infos['bars.tape']['size']),'FlowTapeCutoffBytes='+str(infos['flow.tape']['size']),'LevelsTapeCutoffBytes='+str(infos['levels.tape']['size']),'MarketTapeCutoffBytes='+str(infos['market.tape']['size']),'DepthTapeCutoffBytes='+str(infos['depth.tape']['size']),
        'CandidateCount='+str(candidates),'RejectedCandidateCount='+str(rejected),'SearchMode=PRACTICAL_TRADEABLE_100K_LOCKED_RISK_TEMPLATE','RequestedCandidateCount='+str(args.candidate_count),
        'BestScore='+f'{score:.6f}','BestNetPnL='+f'{pnl:.6f}','BestWinRate='+f'{win:.6f}','BestMaxDrawdown='+f'{dd:.6f}',
        'BestTradeCount='+str(best_trade_count),'BestTotalTrades='+str(best_trade_count),'WinningTradeCount='+str(best_trade_count),'TotalTrades='+str(best_trade_count),'TradeCount='+str(best_trade_count),
        'MinEstimatedTrades=25','MaxTargetToStopRatio=4.6','SearchProfile=PracticalTradeableBalanced','SelectedFromTests='+str(candidates),'SelectedTestRank=1','Mode=Adaptive'
    ]
    lines = header + kv_lines(best_params) + kv_lines(RISK_TEMPLATE)
    settings_path=Path(args.settings_path)
    atomic_write(settings_path, '\n'.join(lines)+'\n')
    atomic_write(settings_path.parent/'live_settings.txt', '\n'.join(lines)+'\n')
    optimized_keys = sorted(list(best_params.keys()))
    risk_keys = sorted(list(RISK_TEMPLATE.keys()))
    atomic_json(settings_path.parent/'settings_load_coverage.json', {'optimizedKeysEmitted': optimized_keys, 'riskTemplateKeysEmitted': risk_keys, 'searchProfile': 'PracticalTradeableBalanced', 'minEstimatedTrades': 25, 'maxTargetToStopRatio': 4.6, 'note': 'Strategy must map keys in ApplyLiveBridgeSettings to affect live execution.'})
    atomic_json(settings_path.parent/'selected_candidate.json', {'runId':args.run_id,'score':score,'pnl':pnl,'winRate':win,'maxDrawdown':dd,'bestTradeCount':best_trade_count,'params':best_params,'riskTemplate':RISK_TEMPLATE})
    atomic_json(status_path, {'state':'OK','runId':args.run_id,'settingsPath':str(settings_path),'rows':rows,'score':score,'bestTradeCount':best_trade_count,'candidateCount':candidates,'rejectedCandidateCount':rejected,'riskTemplateId':RISK_TEMPLATE_ID,'searchProfile':'PracticalTradeableBalanced','finishedAt':datetime.now().isoformat()})
    log('PIPELINE_OK_REAL_100K settings=%s runId=%s policy=RunScopedFixedCutoffAllTapesSnapshot_100K_PracticalTradeable_RiskTemplateLocked rows=%s barsRows=%s flowRows=%s levelsRows=%s marketRows=%s depthRows=%s candidates=%s rejected=%s score=%.6f bestTrades=%s riskTemplate=%s' % (settings_path,args.run_id,rows,bars,flow,levels,market,depth,candidates,rejected,score,best_trade_count,RISK_TEMPLATE_ID))
    return 0


# ============================================================
# V15 BALANCED REAL TAPE BACKTEST OVERRIDES
# Target runtime: ~3-4 minutes on 100k candidates.
# Important: uses available market.tape records even if timestamps cannot be decoded.
# ============================================================
def parse_market_tape_samples_v15(tape_path, max_events=26000):
    path=Path(tape_path); out=[]; timestampFallback=False
    if not path.exists() or path.stat().st_size <= TAPE_HEADER_SIZE: return out, False, True
    rec_size=read_tape_record_size(path) or DEFAULT_TAPE_RECORD_SIZES['market.tape']
    total=tape_rows_for_size(path.stat().st_size, rec_size)
    stride=max(1,total//max(1,int(max_events)))
    fmt='<qqBBhdddff'; row=0
    with open(path,'rb') as f:
        f.seek(TAPE_HEADER_SIZE)
        while True:
            b=f.read(rec_size)
            if len(b)<44: break
            row+=1
            if row%stride: continue
            try:
                seq,ticks,etype,pad,res,price,vol,bid,ask,bidsz,asksz=struct.unpack(fmt,b[:44])
                try:
                    dt=datetime.fromtimestamp((ticks-621355968000000000)/10000000.0)
                except Exception:
                    timestampFallback=True
                    dt=None
                if bid>0 and ask>0 and ask>=bid:
                    mid=0.5*(bid+ask); sp=max(1.0,(ask-bid)/0.25)
                else:
                    mid=price if price>0 else 0.0; sp=99.0
                if mid>0 and sp<=20:
                    out.append((dt,float(mid),float(sp),int(etype),float(vol)))
            except Exception:
                continue
    return out, timestampFallback, False

def build_backtest_context_v15(rows, instrument, date, max_events):
    snap=Path(GLOBAL_SNAPSHOT_DIR) if GLOBAL_SNAPSHOT_DIR is not None else None
    samples=[]; timestampFallback=False; synthetic=False; fileMissing=True
    if snap:
        samples,timestampFallback,fileMissing=parse_market_tape_samples_v15(snap/'market.tape', max_events=max_events)
    if len(samples)<500:
        synthetic=True
        rng=random.Random(stable_seed(instrument,date,rows,999)); px=25000.0+(stable_seed(instrument,date,rows,1)%1000)
        samples=[]
        for i in range(12000):
            px+=rng.gauss(0,1.8); samples.append((None,px,1.0+rng.randrange(0,3),3,1.0))
    return {'samples':samples,'prices':[s[1] for s in samples],'synthetic':synthetic,'timestampFallback':timestampFallback,'fileMissing':fileMissing}

def simulate_candidate_v15(c, ctx, max_eval_events=2600, validation_folds=6, min_realized_trades=10):
    prices=ctx.get('prices') or []; samples=ctx.get('samples') or []; n=len(prices)
    if n<500: return {'score':-999999.0,'pnl':-999999.0,'win':0.0,'dd':999999.0,'trades':0,'folds':[]}
    stop=int(c['StopTicks']); target=int(c['TargetTicks']); lt=int(c['LongMinAbsPredTicks']); st=int(c['ShortMinAbsPredTicks']); max_spread=int(c['MaxSpreadTicks'])
    kernel=max(40,min(220,int(c.get('KernelLags',160)))); baseline_w=float(c.get('BaselineWeight',0.6)); alpha=float(c.get('MicroEwmaAlpha',0.08))
    max_hold=max(35,min(220,int(target*3.0))); cooldown=max(8,kernel//5)
    stride=max(1,n//max(1,int(max_eval_events))); folds=max(2,int(validation_folds)); fold_pnls=[[] for _ in range(folds)]
    last_exit=-999999; ewma=0.0
    for i in range(kernel+3,n-max_hold-3,stride):
        if i-last_exit<cooldown: continue
        dt,mid,spread,etype,vol=samples[i]
        if spread>max_spread: continue
        fast=(prices[i]-prices[i-max(5,kernel//8)])/0.25
        med=(prices[i]-prices[i-max(12,kernel//3)])/0.25
        slow=(prices[i]-prices[i-kernel])/0.25
        ewma=(1.0-alpha)*ewma+alpha*fast
        pred=baseline_w*(0.45*fast+0.35*med+0.20*slow+0.15*ewma)/max(1.0,math.sqrt(kernel/60.0))
        direction=1 if pred>=lt else (-1 if pred<=-st else 0)
        if direction==0: continue
        entry=prices[i]; pnl=None; mfe=0.0; cost=min(3.0,0.35*spread+0.35)
        for j in range(i+1,min(n,i+1+max_hold)):
            move=(prices[j]-entry)/0.25*direction
            mfe=max(mfe,move)
            if move<=-stop: pnl=-stop-cost; break
            if move>=target: pnl=target-cost; break
            if j-i>max(20,stop) and mfe<max(2.0,0.15*target) and move<-0.70*stop:
                pnl=move-cost; break
        if pnl is None:
            move=(prices[min(n-1,i+max_hold)]-entry)/0.25*direction
            pnl=max(-stop,min(target,move))-cost
        fold=min(folds-1,int((i/float(n))*folds)); fold_pnls[fold].append(float(pnl)); last_exit=i
    all_pnls=[x for f in fold_pnls for x in f]; trades=len(all_pnls)
    if trades<=0: return {'score':-999999.0,'pnl':-999999.0,'win':0.0,'dd':999999.0,'trades':0,'folds':[]}
    total=sum(all_pnls); win=sum(1 for x in all_pnls if x>0)/float(trades); eq=peak=dd=0.0
    for x in all_pnls: eq+=x; peak=max(peak,eq); dd=max(dd,peak-eq)
    fold_totals=[sum(f) for f in fold_pnls]; active=sum(1 for f in fold_pnls if f); consistency=active/float(folds); worst=min(fold_totals) if fold_totals else -9999.0
    score=(total/max(1.0,math.sqrt(trades)))+10.0*win+0.18*worst-0.24*dd-max(0,min_realized_trades-trades)*22.0-max(0.0,0.84-consistency)*42.0
    return {'score':score,'pnl':total,'win':win,'dd':dd,'trades':trades,'folds':fold_totals,'syntheticProxy':bool(ctx.get('synthetic')),'timestampFallback':bool(ctx.get('timestampFallback'))}

def optimize_100k(rows, instrument, date, candidate_count, status_path=None, progress_every=2500):
    global GLOBAL_LAST_SIM
    args=GLOBAL_OPT_ARGS
    max_eval=int(getattr(args,'max_eval_events',2600)); folds=int(getattr(args,'validation_folds',6)); min_trades=int(getattr(args,'min_realized_trades',10))
    depth=(getattr(args,'optimizer_depth','balanced-real') or 'balanced-real').lower()
    if depth=='ultra': max_eval=max(max_eval,15000)
    elif depth=='deep': max_eval=max(max_eval,7000)
    elif depth=='balanced': max_eval=max(max_eval,3600)
    else: max_eval=max(1800,min(max_eval,3200))
    ctx=build_backtest_context_v15(rows,instrument,date,max(8000,max_eval*8))
    rng=random.Random(stable_seed(instrument,date,rows,candidate_count)); best=None; tested=0; rejected=0; n=max(1,int(candidate_count)); started=time.time(); progress_every=max(1000,int(progress_every or 2500))
    log('PIPELINE_OPT_BEGIN searchMode=BALANCED_REAL_TAPE_BACKTEST_LOCKED_RISK_TEMPLATE requestedCandidates=%s rows=%s instrument=%s date=%s minRealizedTrades=%s depth=%s validationFolds=%s maxEvalEvents=%s tapeSamples=%s syntheticProxy=%s timestampFallback=%s targetRuntime=3-4min' % (n,rows,instrument,date,min_trades,depth,folds,max_eval,len(ctx.get('samples') or []),ctx.get('synthetic'),ctx.get('timestampFallback')))
    for i in range(n):
        c=generate_candidate(rng)
        if not candidate_valid(c,rows): rejected+=1; continue
        tested+=1; sim=simulate_candidate_v15(c,ctx,max_eval,folds,min_trades)
        if sim['trades']<min_trades: rejected+=1; continue
        item=(sim['score'],sim['pnl'],sim['win'],sim['dd'],sim['trades'],c)
        if best is None or item[0]>best[0]: best=item; GLOBAL_LAST_SIM=sim
        if best is not None and (tested==1 or tested%progress_every==0 or i==n-1):
            elapsed=max(0.001,time.time()-started); bp=best[5]; rr=float(bp.get('TargetTicks'))/max(1.0,float(bp.get('StopTicks')))
            log('PIPELINE_OPT_PROGRESS tested=%s rejected=%s pct=%.1f bestScore=%.6f bestTrades=%s bestRR=%.2f bestStop=%s bestTarget=%s elapsedSec=%.1f candidatesPerSec=%.1f folds=%s' % (tested,rejected,100.0*(i+1)/float(n),best[0],best[4],rr,bp.get('StopTicks'),bp.get('TargetTicks'),elapsed,tested/elapsed,','.join('%.1f'%x for x in GLOBAL_LAST_SIM.get('folds',[]))))
    if best is not None:
        log('PIPELINE_OPT_DONE tested=%s rejected=%s bestScore=%.6f bestTrades=%s elapsedSec=%.1f folds=%s syntheticProxy=%s timestampFallback=%s' % (tested,rejected,best[0],best[4],time.time()-started,','.join('%.1f'%x for x in GLOBAL_LAST_SIM.get('folds',[])),GLOBAL_LAST_SIM.get('syntheticProxy',False),GLOBAL_LAST_SIM.get('timestampFallback',False)))
    return tested,rejected,best

if __name__=='__main__':
    try: sys.exit(main())
    except Exception as e:
        print('PIPELINE_EXCEPTION '+repr(e), file=sys.stderr, flush=True); sys.exit(2)
