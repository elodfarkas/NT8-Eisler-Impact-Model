#region Using declarations
using System;
using System.Diagnostics;
using System.IO;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public enum ReplayBridgeState { Idle, WaitingForTriggerTime, OptimizerStarted, SettingsWaiting, SettingsLoaded, TradingEnabled, Failed }

    public sealed class ReplayOptimizerOrchestrator
    {
        private Action<string> logger;
        private AutoReloadSettings settingsBridge;
        private DateTime lastRunDate = DateTime.MinValue;
        private DateTime startedLocalTime = DateTime.MinValue;
        private DateTime nextPollLocalTime = DateTime.MinValue;
        private DateTime lastStatusPrintLocal = DateTime.MinValue;
        private Process process;
        private TimeSpan triggerTime = new TimeSpan(10, 0, 0);
        private TimeSpan activationTime = new TimeSpan(10, 30, 0);
        private int pollSeconds = 5;
        private int timeoutSeconds = 900;
        private bool initialized;
        private string activeRunId = string.Empty;
        private string activeScopedSettingsPath = string.Empty;
        private string activeInstrument = string.Empty;

        public ReplayBridgeState State { get; private set; }
        public string LastError { get; private set; }
        public string OptimizerCommand { get; private set; }
        public string OptimizerArguments { get; private set; }
        public string WorkingDirectory { get; private set; }
        public string SettingsPath { get; private set; }
        public bool RequireSettingsBeforeTrade { get; private set; }
        public bool StartOnlyOncePerDate { get; private set; }
        public string ActiveRunId { get { return activeRunId; } }
        public string ActiveScopedSettingsPath { get { return activeScopedSettingsPath; } }

        public void Initialize(AutoReloadSettings bridge, string optimizerCommand, string optimizerArguments, string workingDirectory, string settingsPath, string optimizerTriggerHHmm, string activationHHmm, bool requireSettingsBeforeTrade, bool startOnlyOncePerDate, Action<string> log)
        {
            settingsBridge = bridge;
            OptimizerCommand = optimizerCommand;
            OptimizerArguments = optimizerArguments;
            WorkingDirectory = workingDirectory;
            SettingsPath = settingsPath;
            triggerTime = ParseTimeOrDefault(optimizerTriggerHHmm, new TimeSpan(10, 0, 0));
            activationTime = ParseTimeOrDefault(activationHHmm, new TimeSpan(10, 30, 0));
            RequireSettingsBeforeTrade = requireSettingsBeforeTrade;
            StartOnlyOncePerDate = startOnlyOncePerDate;
            logger = log;
            initialized = true;
            State = ReplayBridgeState.WaitingForTriggerTime;
            Print("INIT Trigger=" + triggerTime + " Activation=" + activationTime + " Cmd=" + OptimizerCommand + " WorkDir=" + WorkingDirectory + " BaseSettingsPath=" + SettingsPath + " Args=" + OptimizerArguments);
        }

        public void SetPollingSeconds(int seconds) { pollSeconds = Math.Max(1, seconds); }
        public void SetTimeoutSeconds(int seconds) { timeoutSeconds = Math.Max(30, seconds); }

        public void OnBarUpdate(DateTime marketTime, bool isFirstTickOfBar)
        {
            if (!initialized) return;

            if (DateTime.Now.Subtract(lastStatusPrintLocal).TotalSeconds >= 15)
            {
                lastStatusPrintLocal = DateTime.Now;
                Print("STATUS marketTime=" + marketTime.ToString("yyyy-MM-dd HH:mm:ss") + " state=" + State + " trigger=" + triggerTime + " activation=" + activationTime + " runId=" + activeRunId + " scopedSettingsExists=" + (File.Exists(activeScopedSettingsPath) ? "1" : "0") + " scopedSettingsPath=" + activeScopedSettingsPath);
            }

            // Clean bridge pre-trigger date reset MUST run before CheckReload().
            // Otherwise the bridge can keep validating yesterday's scoped settings path against today's replay date.
            if (marketTime.Date != lastRunDate.Date && marketTime.TimeOfDay < triggerTime)
            {
                if (State != ReplayBridgeState.WaitingForTriggerTime || !string.IsNullOrWhiteSpace(activeScopedSettingsPath))
                    Print("RESET_STATE_FOR_NEW_DATE marketDate=" + marketTime.ToString("yyyy-MM-dd") + " oldLastRunDate=" + lastRunDate.ToString("yyyy-MM-dd") + " oldRunId=" + activeRunId);
                State = ReplayBridgeState.WaitingForTriggerTime;
                LastError = string.Empty;
                activeRunId = string.Empty;
                activeScopedSettingsPath = string.Empty;
                activeInstrument = string.Empty;
                process = null;
                if (settingsBridge != null)
                    settingsBridge.PrepareForNewReplayDate(marketTime.Date, string.Empty);
            }

            if (settingsBridge != null)
            {
                if (!string.IsNullOrWhiteSpace(activeScopedSettingsPath))
                    settingsBridge.SetExpectedContext(marketTime.Date, activeInstrument, activeRunId);
                settingsBridge.CheckReload(marketTime, isFirstTickOfBar);
            }

            if (!isFirstTickOfBar && DateTime.Now < nextPollLocalTime) return;

            if (State == ReplayBridgeState.WaitingForTriggerTime || State == ReplayBridgeState.Idle || State == ReplayBridgeState.Failed)
            {
                if (marketTime.TimeOfDay >= triggerTime)
                {
                    Print("TRIGGER_REACHED marketTime=" + marketTime.ToString("yyyy-MM-dd HH:mm:ss") + " lastRunDate=" + lastRunDate.ToString("yyyy-MM-dd") + " state=" + State);
                    if (StartOnlyOncePerDate && lastRunDate.Date == marketTime.Date && State != ReplayBridgeState.Failed)
                    {
                        Print("SKIP already started for this date");
                        return;
                    }
                    StartOptimizer(marketTime);
                }
                return;
            }

            if (State == ReplayBridgeState.OptimizerStarted || State == ReplayBridgeState.SettingsWaiting)
            {
                PollProcessAndSettings(marketTime);
                return;
            }

            if (State == ReplayBridgeState.SettingsLoaded && marketTime.TimeOfDay >= activationTime)
            {
                State = ReplayBridgeState.TradingEnabled;
                Print("TRADING_ENABLED marketTime=" + marketTime.ToString("yyyy-MM-dd HH:mm:ss") + " runId=" + activeRunId);
            }
        }

        public bool CanTrade(DateTime marketTime)
        {
            if (!initialized) return true;
            if (marketTime.TimeOfDay < activationTime) return false;
            if (RequireSettingsBeforeTrade && (settingsBridge == null || !settingsBridge.HasValidLiveSettings)) return false;
            return State == ReplayBridgeState.TradingEnabled || (!RequireSettingsBeforeTrade && marketTime.TimeOfDay >= activationTime);
        }

        public bool ShouldBlockEntries(DateTime marketTime) { return !CanTrade(marketTime); }

        private void StartOptimizer(DateTime marketTime)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(OptimizerCommand)) { Fail("OptimizerCommand is empty"); return; }
                if (string.IsNullOrWhiteSpace(WorkingDirectory) || !Directory.Exists(WorkingDirectory)) { Fail("WorkingDirectory not found: " + WorkingDirectory); return; }

                activeInstrument = ExtractOptionValue(OptimizerArguments, "--instrument");
                if (string.IsNullOrWhiteSpace(activeInstrument)) activeInstrument = "UNKNOWN";
                activeRunId = MakeRunId(activeInstrument, marketTime);
                activeScopedSettingsPath = BuildScopedSettingsPath(SettingsPath, activeInstrument, marketTime, activeRunId);

                if (settingsBridge != null)
                    settingsBridge.ResetForNewRun(activeScopedSettingsPath, marketTime.Date, activeInstrument, activeRunId);

                string argsExpanded = ExpandMacros(OptimizerArguments, marketTime, activeRunId, activeScopedSettingsPath);
                if (argsExpanded.IndexOf("--run-id", StringComparison.OrdinalIgnoreCase) < 0)
                    argsExpanded += " --run-id " + QuoteArg(activeRunId);
                if (argsExpanded.IndexOf("--settings-path", StringComparison.OrdinalIgnoreCase) < 0)
                    argsExpanded += " --settings-path " + QuoteArg(activeScopedSettingsPath);

                string firstArg = ExtractFirstArg(argsExpanded);
                if (!string.IsNullOrWhiteSpace(firstArg))
                {
                    string scriptPath = Path.Combine(WorkingDirectory, firstArg);
                    if (!File.Exists(scriptPath)) { Fail("Script not found: " + scriptPath); return; }
                }

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = OptimizerCommand;
                psi.Arguments = argsExpanded;
                psi.WorkingDirectory = WorkingDirectory;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;

                process = new Process();
                process.StartInfo = psi;
                process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (!string.IsNullOrEmpty(e.Data)) Print("OPT OUT " + e.Data); };
                process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (!string.IsNullOrEmpty(e.Data)) Print("OPT ERR " + e.Data); };

                Print("PROCESS_START RunId=" + activeRunId + " ScopedSettingsPath=" + activeScopedSettingsPath + " FileName=" + psi.FileName + " WorkDir=" + psi.WorkingDirectory + " Args=" + psi.Arguments);
                bool ok = process.Start();
                if (!ok) { Fail("Process.Start returned false"); return; }
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();
                startedLocalTime = DateTime.Now;
                nextPollLocalTime = DateTime.Now.AddSeconds(pollSeconds);
                lastRunDate = marketTime.Date;
                State = ReplayBridgeState.OptimizerStarted;
                Print("PROCESS_STARTED PID=" + process.Id + " RunId=" + activeRunId);
            }
            catch (Exception ex) { Fail("StartOptimizer exception: " + ex.Message); }
        }

        private void PollProcessAndSettings(DateTime marketTime)
        {
            DateTime now = DateTime.Now;
            if (now < nextPollLocalTime) return;
            nextPollLocalTime = now.AddSeconds(pollSeconds);

            try
            {
                if (settingsBridge != null && File.Exists(activeScopedSettingsPath))
                {
                    settingsBridge.SetExpectedContext(marketTime.Date, activeInstrument, activeRunId);
                    if (settingsBridge.LoadSettings())
                    {
                        State = marketTime.TimeOfDay >= activationTime ? ReplayBridgeState.TradingEnabled : ReplayBridgeState.SettingsLoaded;
                        Print("SETTINGS_LOADED State=" + State + " RunId=" + activeRunId + " Path=" + activeScopedSettingsPath);
                        return;
                    }
                }

                if (process != null && process.HasExited)
                {
                    if (process.ExitCode != 0) { Fail("Optimizer process exited with code " + process.ExitCode + " RunId=" + activeRunId); return; }
                    State = ReplayBridgeState.SettingsWaiting;
                    Print("PROCESS_EXITED_OK waiting for valid scoped settings file. RunId=" + activeRunId + " Path=" + activeScopedSettingsPath);
                }

                if (startedLocalTime != DateTime.MinValue && (now - startedLocalTime).TotalSeconds > timeoutSeconds)
                {
                    TryKillProcess();
                    Fail("Optimizer/settings timeout after seconds=" + timeoutSeconds + " RunId=" + activeRunId);
                    return;
                }
            }
            catch (Exception ex) { Fail("Poll exception: " + ex.Message); }
        }

        private void TryKillProcess()
        {
            try
            {
                if (process != null && !process.HasExited)
                {
                    Print("KILL_STUCK_PROCESS PID=" + process.Id + " RunId=" + activeRunId);
                    process.Kill();
                }
            }
            catch (Exception ex) { Print("KILL_PROCESS_WARN " + ex.Message); }
        }

        private string BuildScopedSettingsPath(string baseSettingsPath, string instrument, DateTime marketTime, string runId)
        {
            string liveBridgeDir = string.Empty;
            try { liveBridgeDir = Path.GetDirectoryName(baseSettingsPath); } catch { }
            if (string.IsNullOrWhiteSpace(liveBridgeDir))
                liveBridgeDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "EislerResearch", "live_bridge");
            string safeInstrument = SanitizePathPart(instrument);
            string date = marketTime.ToString("yyyy-MM-dd");
            return Path.Combine(liveBridgeDir, "instrument=" + safeInstrument, "date=" + date, "run=" + runId, "settings.txt");
        }

        private string MakeRunId(string instrument, DateTime marketTime)
        {
            string safeInstrument = SanitizePathPart(instrument);
            string shortGuid = Guid.NewGuid().ToString("N").Substring(0, 8);
            return safeInstrument + "_" + marketTime.ToString("yyyyMMdd_HHmmss") + "_" + shortGuid;
        }

        private string ExpandMacros(string args, DateTime marketTime, string runId, string settingsPath)
        {
            string s = args ?? string.Empty;
            s = s.Replace("{date}", marketTime.ToString("yyyy-MM-dd"));
            s = s.Replace("{yyyymmdd}", marketTime.ToString("yyyyMMdd"));
            s = s.Replace("{runid}", runId ?? string.Empty);
            s = s.Replace("{settingspath}", settingsPath ?? string.Empty);
            return s;
        }

        private string ExtractFirstArg(string args)
        {
            if (string.IsNullOrWhiteSpace(args)) return string.Empty;
            string s = args.Trim();
            int sp = s.IndexOf(' ');
            return sp > 0 ? s.Substring(0, sp).Trim().Trim('"') : s.Trim().Trim('"');
        }

        private string ExtractOptionValue(string args, string option)
        {
            if (string.IsNullOrWhiteSpace(args) || string.IsNullOrWhiteSpace(option)) return string.Empty;
            int idx = args.IndexOf(option, StringComparison.OrdinalIgnoreCase);
            if (idx < 0) return string.Empty;
            int pos = idx + option.Length;
            while (pos < args.Length && char.IsWhiteSpace(args[pos])) pos++;
            if (pos >= args.Length) return string.Empty;
            if (args[pos] == '"')
            {
                int end = args.IndexOf('"', pos + 1);
                if (end > pos) return args.Substring(pos + 1, end - pos - 1);
            }
            int sp = args.IndexOf(' ', pos);
            return sp > pos ? args.Substring(pos, sp - pos) : args.Substring(pos);
        }

        private string QuoteArg(string value)
        {
            return "\"" + (value ?? string.Empty).Replace("\"", "") + "\"";
        }

        private string SanitizePathPart(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "UNKNOWN";
            string s = value.Trim().Replace(' ', '_');
            foreach (char c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s.Replace('/', '_').Replace('\\', '_').Replace(':', '_').Replace(';', '_');
        }

        private TimeSpan ParseTimeOrDefault(string text, TimeSpan fallback)
        {
            TimeSpan ts;
            return TimeSpan.TryParse(text, out ts) ? ts : fallback;
        }

        private void Fail(string msg)
        {
            LastError = msg;
            State = ReplayBridgeState.Failed;
            Print("FAILED " + msg);
        }

        private void Print(string msg)
        {
            if (logger != null) logger("[EISLER_REPLAY_ORCH] " + msg);
        }
    }
}
