#region Using declarations
using System;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Windows.Media;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    public class EislerDiagnostics : Indicator
    {
        private object barsTypeObject;
        private Type barsTypeRuntimeType;
        private FieldInfo flowDataByBarField;
        private FieldInfo priceLevelMemoryField;
        private string lastBarsTypeInfo = "n/a";
        private int lastFlowKey = -1;
        private bool lastFlowExactMatch;

        [NinjaScriptProperty]
        [Display(Name = "ShowTextPanel", Order = 1, GroupName = "Display")]
        public bool ShowTextPanel { get; set; }

        [NinjaScriptProperty]
        [Range(1, 1000)]
        [Display(Name = "MemoryLevelsToScan", Order = 2, GroupName = "Display")]
        public int MemoryLevelsToScan { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "ShowTypeDebug", Order = 3, GroupName = "Display")]
        public bool ShowTypeDebug { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EislerDiagnostics";
                Description = "Full diagnostics panel for EislerBarType FlowDataByBar, PriceLevelMemory, Absorption and Trap state.";
                Calculate = Calculate.OnEachTick;
                IsOverlay = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = false;
                ShowTextPanel = true;
                ShowTypeDebug = false;
                MemoryLevelsToScan = 250;

                AddPlot(Brushes.DodgerBlue, "NetLiquidityPressure");
                AddPlot(Brushes.LimeGreen, "RefillIntensity");
                AddPlot(Brushes.OrangeRed, "SweepIntensity");
                AddPlot(Brushes.Goldenrod, "AbsorptionMax");
                AddPlot(Brushes.MediumVioletRed, "TrapMax");
                AddPlot(Brushes.Orange, "Toxicity");
                AddPlot(Brushes.Gray, "Resiliency");
            }
            else if (State == State.DataLoaded)
            {
                RefreshBarsTypeReference();
            }
        }

        private object GetChartBarsType()
        {
            object bt = null;
            try
            {
                if (BarsArray != null && BarsArray.Length > 0 && BarsArray[0] != null && BarsArray[0].BarsSeries != null)
                    bt = BarsArray[0].BarsSeries.BarsType;
            }
            catch { }

            if (bt == null)
            {
                try
                {
                    if (Bars != null && Bars.BarsSeries != null)
                        bt = Bars.BarsSeries.BarsType;
                }
                catch { }
            }

            return bt;
        }

        private void RefreshBarsTypeReference()
        {
            barsTypeObject = null;
            barsTypeRuntimeType = null;
            flowDataByBarField = null;
            priceLevelMemoryField = null;
            lastBarsTypeInfo = "n/a";

            object bt = GetChartBarsType();
            if (bt == null)
                return;

            Type t = bt.GetType();
            string typeName = t != null ? t.Name : string.Empty;
            string fullName = t != null ? t.FullName : string.Empty;
            string toStringName = string.Empty;
            try { toStringName = bt.ToString(); } catch { }

            lastBarsTypeInfo = fullName + " | TypeName=" + typeName + " | ToString=" + toStringName;

            bool looksLikeEisler =
                string.Equals(typeName, "EislerBarType", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(toStringName, "EislerBarType", StringComparison.OrdinalIgnoreCase) ||
                (!string.IsNullOrEmpty(fullName) && fullName.IndexOf("EislerBarType", StringComparison.OrdinalIgnoreCase) >= 0);

            if (!looksLikeEisler)
                return;

            FieldInfo fd = t.GetField("FlowDataByBar", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            FieldInfo pm = t.GetField("PriceLevelMemory", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            if (fd == null || pm == null)
                return;

            barsTypeObject = bt;
            barsTypeRuntimeType = t;
            flowDataByBarField = fd;
            priceLevelMemoryField = pm;
        }

        private object ReadMember(object obj, string name)
        {
            if (obj == null || string.IsNullOrEmpty(name))
                return null;

            try
            {
                Type t = obj.GetType();
                FieldInfo f = t.GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (f != null)
                    return f.GetValue(obj);

                PropertyInfo p = t.GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (p != null && p.CanRead)
                    return p.GetValue(obj, null);
            }
            catch { }

            return null;
        }

        private double ReadDouble(object obj, string name)
        {
            try
            {
                object v = ReadMember(obj, name);
                if (v == null)
                    return 0.0;
                return Convert.ToDouble(v);
            }
            catch { return 0.0; }
        }

        private long ReadLong(object obj, string name)
        {
            try
            {
                object v = ReadMember(obj, name);
                if (v == null)
                    return 0;
                return Convert.ToInt64(v);
            }
            catch { return 0; }
        }

        private int ReadInt(object obj, string name)
        {
            try
            {
                object v = ReadMember(obj, name);
                if (v == null)
                    return 0;
                return Convert.ToInt32(v);
            }
            catch { return 0; }
        }

        private IDictionary ReadDictionaryField(object obj, string name)
        {
            try
            {
                object v = ReadMember(obj, name);
                return v as IDictionary;
            }
            catch { return null; }
        }

        private object GetCurrentFlow(IDictionary flowMap)
        {
            lastFlowKey = -1;
            lastFlowExactMatch = false;

            if (flowMap == null)
                return null;

            try
            {
                if (flowMap.Contains(CurrentBar))
                {
                    lastFlowKey = CurrentBar;
                    lastFlowExactMatch = true;
                    return flowMap[CurrentBar];
                }
            }
            catch { }

            try
            {
                int best = -1;
                foreach (object key in flowMap.Keys)
                {
                    int k;
                    try { k = Convert.ToInt32(key); }
                    catch { continue; }

                    if (k <= CurrentBar && k > best)
                        best = k;
                }

                if (best >= 0 && flowMap.Contains(best))
                {
                    lastFlowKey = best;
                    lastFlowExactMatch = false;
                    return flowMap[best];
                }
            }
            catch { }

            return null;
        }

        private void SetAllPlotsZero()
        {
            Values[0][0] = 0;
            Values[1][0] = 0;
            Values[2][0] = 0;
            Values[3][0] = 0;
            Values[4][0] = 0;
            Values[5][0] = 0;
            Values[6][0] = 0;
        }

        protected override void OnBarUpdate()
        {
            SetAllPlotsZero();

            if (barsTypeObject == null || flowDataByBarField == null || priceLevelMemoryField == null)
                RefreshBarsTypeReference();

            object currentBt = GetChartBarsType();
            string actualType = lastBarsTypeInfo;
            try
            {
                if (currentBt != null)
                    actualType = currentBt.GetType().FullName + " | TypeName=" + currentBt.GetType().Name + " | ToString=" + currentBt.ToString();
            }
            catch { }

            if (barsTypeObject == null || flowDataByBarField == null || priceLevelMemoryField == null)
            {
                if (ShowTextPanel)
                {
                    Draw.TextFixed(
                        this,
                        "EislerDiagnosticsPanel",
                        "EislerDiagnostics FULL\nBarsType felismerés: NEM OK\nAktuális BarsType: " + actualType + "\nHiányzó mező: FlowDataByBar vagy PriceLevelMemory",
                        TextPosition.TopLeft);
                }
                return;
            }

            IDictionary flowMap = null;
            IDictionary memoryMap = null;
            try { flowMap = flowDataByBarField.GetValue(barsTypeObject) as IDictionary; } catch { }
            try { memoryMap = priceLevelMemoryField.GetValue(barsTypeObject) as IDictionary; } catch { }

            object flow = GetCurrentFlow(flowMap);
            bool hasFlow = flow != null;

            int flowMapCount = flowMap != null ? flowMap.Count : 0;
            int memoryCount = memoryMap != null ? memoryMap.Count : 0;
            IDictionary footprint = hasFlow ? ReadDictionaryField(flow, "Footprint") : null;
            int footprintCount = footprint != null ? footprint.Count : 0;

            long buy = hasFlow ? ReadLong(flow, "BuyVolume") : 0;
            long sell = hasFlow ? ReadLong(flow, "SellVolume") : 0;
            long delta = hasFlow ? ReadLong(flow, "Delta") : 0;

            double nlp = hasFlow ? ReadDouble(flow, "NetLiquidityPressure") : 0;
            double refill = hasFlow ? ReadDouble(flow, "RefillIntensity") : 0;
            double sweep = hasFlow ? ReadDouble(flow, "SweepIntensity") : 0;
            double toxicity = hasFlow ? ReadDouble(flow, "Toxicity") : 0;
            double resiliency = hasFlow ? ReadDouble(flow, "Resiliency") : 0;
            double regime = hasFlow ? ReadDouble(flow, "RegimeProbability") : 0;
            double gapCompression = hasFlow ? ReadDouble(flow, "GapCompression") : 0;
            double gapExpansion = hasFlow ? ReadDouble(flow, "GapExpansion") : 0;
            double aggressionVelocity = hasFlow ? ReadDouble(flow, "AggressionVelocity") : 0;
            double impactSlope = hasFlow ? ReadDouble(flow, "ImpactSlope") : 0;

            double absorptionSum = 0;
            double trapSum = 0;
            double absorptionMax = 0;
            double trapMax = 0;
            double continuationSum = 0;
            double meanRevSum = 0;
            double sweepProbSum = 0;
            double refillScoreSum = 0;
            double resiliencySum = 0;
            double topAbsPrice = 0;
            double topTrapPrice = 0;
            int absorptionNonZero = 0;
            int trapNonZero = 0;
            int absorptionEventCount = 0;
            int trapEventCount = 0;
            int sweepEventCount = 0;
            int refillEventCount = 0;
            int scanned = 0;

            if (memoryMap != null)
            {
                foreach (DictionaryEntry kv in memoryMap)
                {
                    if (scanned >= MemoryLevelsToScan)
                        break;

                    object lvl = kv.Value;
                    if (lvl == null)
                        continue;

                    double price = ReadDouble(lvl, "Price");
                    double absorption = ReadDouble(lvl, "AbsorptionScore");
                    double trap = ReadDouble(lvl, "TrappedTraderScore");
                    double continuation = ReadDouble(lvl, "ContinuationProbability");
                    double meanRev = ReadDouble(lvl, "MeanReversionProbability");
                    double sweepProb = ReadDouble(lvl, "SweepProbability");
                    double refillScore = ReadDouble(lvl, "RefillScore");
                    double levelResiliency = ReadDouble(lvl, "QueueResiliency");

                    absorptionSum += absorption;
                    trapSum += trap;
                    continuationSum += continuation;
                    meanRevSum += meanRev;
                    sweepProbSum += sweepProb;
                    refillScoreSum += refillScore;
                    resiliencySum += levelResiliency;

                    if (absorption > absorptionMax)
                    {
                        absorptionMax = absorption;
                        topAbsPrice = price;
                    }
                    if (trap > trapMax)
                    {
                        trapMax = trap;
                        topTrapPrice = price;
                    }
                    if (absorption > 0.0001)
                        absorptionNonZero++;
                    if (trap > 0.0001)
                        trapNonZero++;

                    absorptionEventCount += ReadInt(lvl, "AbsorptionCount");
                    trapEventCount += ReadInt(lvl, "TrapCount");
                    sweepEventCount += ReadInt(lvl, "SweepCount");
                    refillEventCount += ReadInt(lvl, "RefillCount");

                    scanned++;
                }
            }

            double absorptionAvg = scanned > 0 ? absorptionSum / scanned : 0;
            double trapAvg = scanned > 0 ? trapSum / scanned : 0;
            double continuationAvg = scanned > 0 ? continuationSum / scanned : 0;
            double meanRevAvg = scanned > 0 ? meanRevSum / scanned : 0;
            double sweepProbAvg = scanned > 0 ? sweepProbSum / scanned : 0;
            double refillScoreAvg = scanned > 0 ? refillScoreSum / scanned : 0;
            double memoryResiliencyAvg = scanned > 0 ? resiliencySum / scanned : 0;

            Values[0][0] = nlp;
            Values[1][0] = refill;
            Values[2][0] = sweep;
            Values[3][0] = absorptionMax;
            Values[4][0] = trapMax;
            Values[5][0] = toxicity;
            Values[6][0] = resiliency;

            if (ShowTextPanel)
            {
                string status = hasFlow && footprintCount > 0 && memoryCount > 0 ? "OK" : "VÁR ADATRA";
                string exact = lastFlowExactMatch ? "exact" : "fallback";
                string typeLine = ShowTypeDebug ? "\nType: " + actualType : string.Empty;

                string txt = string.Format(
                    "EislerDiagnostics FULL\n" +
                    "Status: {0} | CurrentBar: {1} | FlowKey: {2} ({3}){4}\n" +
                    "FlowMap: {5} | Footprint: {6} | Memory: {7} | Scanned: {8}\n" +
                    "Buy/Sell/Delta: {9}/{10}/{11}\n" +
                    "NLP: {12:F3} | RefillInt: {13:F3} | SweepInt: {14:F3}\n" +
                    "GapComp/Exp: {15:F3}/{16:F3} | AggVel: {17:F3} | Impact: {18:F3}\n" +
                    "Toxicity: {19:F3} | FlowResil: {20:F3} | Regime: {21:F3}\n" +
                    "Abs Avg/Max/Cnt/Event: {22:F4}/{23:F4}/{24}/{25} @ {26:F2}\n" +
                    "Trap Avg/Max/Cnt/Event: {27:F4}/{28:F4}/{29}/{30} @ {31:F2}\n" +
                    "SweepEvents: {32} | RefillEvents: {33} | SweepAvg: {34:F3} | RefillAvg: {35:F3}\n" +
                    "ContAvg: {36:F3} | MRAvg: {37:F3} | MemResilAvg: {38:F3}",
                    status,
                    CurrentBar,
                    lastFlowKey,
                    exact,
                    typeLine,
                    flowMapCount,
                    footprintCount,
                    memoryCount,
                    scanned,
                    buy,
                    sell,
                    delta,
                    nlp,
                    refill,
                    sweep,
                    gapCompression,
                    gapExpansion,
                    aggressionVelocity,
                    impactSlope,
                    toxicity,
                    resiliency,
                    regime,
                    absorptionAvg,
                    absorptionMax,
                    absorptionNonZero,
                    absorptionEventCount,
                    topAbsPrice,
                    trapAvg,
                    trapMax,
                    trapNonZero,
                    trapEventCount,
                    topTrapPrice,
                    sweepEventCount,
                    refillEventCount,
                    sweepProbAvg,
                    refillScoreAvg,
                    continuationAvg,
                    meanRevAvg,
                    memoryResiliencyAvg);

                Draw.TextFixed(this, "EislerDiagnosticsPanel", txt, TextPosition.TopLeft);
            }
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EislerDiagnostics[] cacheEislerDiagnostics;
		public EislerDiagnostics EislerDiagnostics(bool showTextPanel, int memoryLevelsToScan, bool showTypeDebug)
		{
			return EislerDiagnostics(Input, showTextPanel, memoryLevelsToScan, showTypeDebug);
		}

		public EislerDiagnostics EislerDiagnostics(ISeries<double> input, bool showTextPanel, int memoryLevelsToScan, bool showTypeDebug)
		{
			if (cacheEislerDiagnostics != null)
				for (int idx = 0; idx < cacheEislerDiagnostics.Length; idx++)
					if (cacheEislerDiagnostics[idx] != null && cacheEislerDiagnostics[idx].ShowTextPanel == showTextPanel && cacheEislerDiagnostics[idx].MemoryLevelsToScan == memoryLevelsToScan && cacheEislerDiagnostics[idx].ShowTypeDebug == showTypeDebug && cacheEislerDiagnostics[idx].EqualsInput(input))
						return cacheEislerDiagnostics[idx];
			return CacheIndicator<EislerDiagnostics>(new EislerDiagnostics(){ ShowTextPanel = showTextPanel, MemoryLevelsToScan = memoryLevelsToScan, ShowTypeDebug = showTypeDebug }, input, ref cacheEislerDiagnostics);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EislerDiagnostics EislerDiagnostics(bool showTextPanel, int memoryLevelsToScan, bool showTypeDebug)
		{
			return indicator.EislerDiagnostics(Input, showTextPanel, memoryLevelsToScan, showTypeDebug);
		}

		public Indicators.EislerDiagnostics EislerDiagnostics(ISeries<double> input , bool showTextPanel, int memoryLevelsToScan, bool showTypeDebug)
		{
			return indicator.EislerDiagnostics(input, showTextPanel, memoryLevelsToScan, showTypeDebug);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EislerDiagnostics EislerDiagnostics(bool showTextPanel, int memoryLevelsToScan, bool showTypeDebug)
		{
			return indicator.EislerDiagnostics(Input, showTextPanel, memoryLevelsToScan, showTypeDebug);
		}

		public Indicators.EislerDiagnostics EislerDiagnostics(ISeries<double> input , bool showTextPanel, int memoryLevelsToScan, bool showTypeDebug)
		{
			return indicator.EislerDiagnostics(input, showTextPanel, memoryLevelsToScan, showTypeDebug);
		}
	}
}

#endregion
