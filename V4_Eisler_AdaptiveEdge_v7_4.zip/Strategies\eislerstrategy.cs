// eisler950ALLDAY_AdaptiveEdge_v7_4.cs
// NinjaTrader 8 Strategy
// Enhanced Eisler-style event-impact model WITHOUT Level II (MarketDepth) dependency.
//
// 2026-06 v7_4 Soft-stop compile-fixed:
//  - Adds missing controlled-hold NinjaScript properties and soft-stop state fields.
//  - POST_ENTRY_HIGH/LOW cannot close before MinHoldMsBeforeSoftSLExit unless PostEntrySoftHardBreachTicks is hit.
//  - BID/ASK cross remains strict via BidAskHardBreachTicks.
//  - EarlyFailureExit is suppressed during the controlled soft-hold window.
// Target: NQ 1-minute Volumetric bars (Order Flow+), DeltaType=BidAsk, TicksPerLevel=1.
//
// Enhancements implemented (priority list):
//  1) Large-tick vs Small-tick regime switch (spread-one probability)
//  2) ΔRπ baseline (EWMA realized gap per price-changing event type)
//  3) Small-tick gap-flex correction via 3 decaying states included in RLS feature set
//  4) Induced-pattern filters (refill-trap gate for entries)
//  5) Concave impact-based dynamic sizing (activity proxy)
//
// Notes:
//  - No OnMarketDepth() used. Uses L1 Bid/Ask/Last + Volumetric bar aggregates.
//  - For historical/Market Replay, Tick Replay ON recommended.
//
// 2026-06 v7_2 AdaptiveEdge:
//  - Hard blocks spread > 2 ticks; high-conviction wide-spread exception disabled by default.
//  - Uses market-data timestamp for opening filter.
//  - Uses Core.Globals.Now based holding clock for EarlyFailure.
//  - Balanced ATR 1R capped at 20 ticks and long side re-enabled for controlled testing.
//  - CSV header/row schema aligned for all lifecycle rows.

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.IO;
using System.Globalization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Strategies;
using NinjaTrader.NinjaScript.BarsTypes;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
	public class eisler950ALLDAY_AdaptiveEdge_v7_4 : Strategy
	{
		private enum EventType
		{
			MO0 = 0,   // market order, no mid move within window
			MO1 = 1,   // market order, mid moved within window
			LO0 = 2,   // unused (reserved)
			LO1 = 3,   // quote-driven: best quote moved (proxy for LO'/refill/inside-spread)
			CA0 = 4,   // unused (reserved)
			CA1 = 5    // quote-driven: best quote moved adverse (proxy for CA'/pull)
		}

		private struct BookEvent
		{
			public DateTime Time;
			public EventType Type;
			public int Eps;
			public double Mid;
			public double MidChangeTicks;
			public double SpreadTicks;
			public double DeltaNorm;
			public double ImbNear;
			public double OfiProxy;
			public bool PriceChanged;
		}

		// -------------------- User parameters --------------------
		[NinjaScriptProperty]
		[Range(30, 600)]
		[Display(Name = "KernelLags", Order = 1, GroupName = "Eisler Model")]
		public int KernelLags { get; set; }

		[NinjaScriptProperty]
		[Range(0.90, 0.9999)]
		[Display(Name = "RlsLambda (forgetting)", Order = 2, GroupName = "Eisler Model")]
		public double RlsLambda { get; set; }

		[NinjaScriptProperty]
		[Range(1, 15)]
		[Display(Name = "EntryThresholdTicks (LargeTick)", Order = 3, GroupName = "Trading")]
		public int EntryThresholdTicksLarge { get; set; }

		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "EntryThresholdTicks (SmallTick)", Order = 4, GroupName = "Trading")]
		public int EntryThresholdTicksSmall { get; set; }

		[NinjaScriptProperty]
		[Range(1, 60)]
		[Display(Name = "StopTicks", Order = 5, GroupName = "Trading")]
		public int StopTicks { get; set; }



		[NinjaScriptProperty]
		[Range(0, 2000)]
		[Display(Name = "TrailUpdateMinMs", Order = 53, GroupName = "Risk Engine")]
		public int TrailUpdateMinMs { get; set; }

		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "StopMarketSafetyTicks", Order = 54, GroupName = "Risk Engine")]
		public int StopMarketSafetyTicks { get; set; }

		public enum OneRMode { Conservative, Balanced, Aggressive }

		[NinjaScriptProperty]
		[Display(Name = "UseAtrDynamicRisk", Order = 67, GroupName = "Risk Engine: Adaptive R")]
		public bool UseAtrDynamicRisk { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "OneRCalibrationMode", Order = 68, GroupName = "Risk Engine: Adaptive R")]
		public OneRMode OneRCalibrationMode { get; set; }

		[NinjaScriptProperty]
		[Range(2, 100)]
		[Display(Name = "AtrPeriod", Order = 69, GroupName = "Risk Engine: Adaptive R")]
		public int AtrPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(0.25, 5.0)]
		[Display(Name = "VolatilityMultiplier", Order = 70, GroupName = "Risk Engine: Adaptive R")]
		public double VolatilityMultiplier { get; set; }

		[NinjaScriptProperty]
		[Range(1, 200)]
		[Display(Name = "MinOneRTicks", Order = 71, GroupName = "Risk Engine: Adaptive R")]
		public int MinOneRTicks { get; set; }

		[NinjaScriptProperty]
		[Range(1, 300)]
		[Display(Name = "MaxOneRTicks", Order = 72, GroupName = "Risk Engine: Adaptive R")]
		public int MaxOneRTicks { get; set; }

		[NinjaScriptProperty]
		[Range(1.0, 5.0)]
		[Display(Name = "FreeTradeActivation_R", Order = 73, GroupName = "Risk Engine: Adaptive R")]
		public double FreeTradeActivation_R { get; set; }

		[NinjaScriptProperty]
		[Range(0, 20)]
		[Display(Name = "FreeTradeOffsetTicks", Order = 74, GroupName = "Risk Engine: Adaptive R")]
		public int FreeTradeOffsetTicks { get; set; }

		[NinjaScriptProperty]
		[Range(1.5, 10.0)]
		[Display(Name = "TrailingActivation_R", Order = 75, GroupName = "Risk Engine: Adaptive R")]
		public double TrailingActivation_R { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseStructuralTrailing", Order = 76, GroupName = "Risk Engine: Adaptive R")]
		public bool UseStructuralTrailing { get; set; }

		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "StructuralLookbackBars", Order = 77, GroupName = "Risk Engine: Adaptive R")]
		public int StructuralLookbackBars { get; set; }

		[NinjaScriptProperty]
		[Range(0, 20)]
		[Display(Name = "StructuralOffsetTicks", Order = 78, GroupName = "Risk Engine: Adaptive R")]
		public int StructuralOffsetTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseChandelierTrailing", Order = 79, GroupName = "Risk Engine: Adaptive R")]
		public bool UseChandelierTrailing { get; set; }

		[NinjaScriptProperty]
		[Range(0.5, 10.0)]
		[Display(Name = "ChandelierAtrMultiplier", Order = 80, GroupName = "Risk Engine: Adaptive R")]
		public double ChandelierAtrMultiplier { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseProfitTargetLimit", Order = 81, GroupName = "Risk Engine: Adaptive R")]
		public bool UseProfitTargetLimit { get; set; }

		[NinjaScriptProperty]
		[Range(1.0, 10.0)]
		[Display(Name = "ProfitTarget_R", Order = 82, GroupName = "Risk Engine: Adaptive R")]
		public double ProfitTarget_R { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseEarlyFailureExit", Order = 83, GroupName = "Risk Engine: Adaptive R")]
		public bool UseEarlyFailureExit { get; set; }

		[NinjaScriptProperty]
		[Range(0.1, 2.0)]
		[Display(Name = "EarlyFailureMaxAdverse_R", Order = 84, GroupName = "Risk Engine: Adaptive R")]
		public double EarlyFailureMaxAdverse_R { get; set; }

		[NinjaScriptProperty]
		[Range(0.0, 1.0)]
		[Display(Name = "EarlyFailureMinMfe_R", Order = 85, GroupName = "Risk Engine: Adaptive R")]
		public double EarlyFailureMinMfe_R { get; set; }

		[NinjaScriptProperty]
		[Range(0, 60000)]
		[Display(Name = "EarlyFailureMinHoldMs", Order = 86, GroupName = "Risk Engine: Adaptive R")]
		public int EarlyFailureMinHoldMs { get; set; }

		[NinjaScriptProperty]
		[Range(100, 5000)]
		[Display(Name = "ExitRetryMs", Order = 55, GroupName = "Risk Engine")]
		public int ExitRetryMs { get; set; }

		[NinjaScriptProperty]
		[Range(500, 10000)]
		[Display(Name = "EmergencyExitMs", Order = 56, GroupName = "Risk Engine")]
		public int EmergencyExitMs { get; set; }

		[NinjaScriptProperty]
		[Range(0, 200)]
		[Display(Name = "CatastrophicStopTicks", Order = 57, GroupName = "Risk Engine")]
		public int CatastrophicStopTicks { get; set; }

		// -------------------- v7_4 Controlled Soft-Stop Hold --------------------
		[NinjaScriptProperty]
		[Display(Name = "UseControlledSoftStopHold", Order = 570, GroupName = "Risk Engine: Controlled Hold")]
		public bool UseControlledSoftStopHold { get; set; }

		[NinjaScriptProperty]
		[Range(0, 300000)]
		[Display(Name = "MinHoldMsBeforeSoftSLExit", Order = 571, GroupName = "Risk Engine: Controlled Hold")]
		public int MinHoldMsBeforeSoftSLExit { get; set; }

		[NinjaScriptProperty]
		[Range(0, 40)]
		[Display(Name = "InitialStopMaxBreachTicks", Order = 572, GroupName = "Risk Engine: Controlled Hold")]
		public int InitialStopMaxBreachTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, 40)]
		[Display(Name = "BidAskHardBreachTicks", Order = 573, GroupName = "Risk Engine: Controlled Hold")]
		public int BidAskHardBreachTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "IgnorePostEntrySoftStopUntilMinHold", Order = 574, GroupName = "Risk Engine: Controlled Hold")]
		public bool IgnorePostEntrySoftStopUntilMinHold { get; set; }

		[NinjaScriptProperty]
		[Range(0, 200)]
		[Display(Name = "PostEntrySoftHardBreachTicks", Order = 575, GroupName = "Risk Engine: Controlled Hold")]
		public int PostEntrySoftHardBreachTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, 10000)]
		[Display(Name = "SoftStopConfirmMs", Order = 576, GroupName = "Risk Engine: Controlled Hold")]
		public int SoftStopConfirmMs { get; set; }

		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "SoftStopConfirmEvents", Order = 577, GroupName = "Risk Engine: Controlled Hold")]
		public int SoftStopConfirmEvents { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "DoNotIgnoreBidAskCrossBreach", Order = 578, GroupName = "Risk Engine: Controlled Hold")]
		public bool DoNotIgnoreBidAskCrossBreach { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "IgnoreEntryBarPostExtremumForSL", Order = 579, GroupName = "Risk Engine: Controlled Hold")]
		public bool IgnoreEntryBarPostExtremumForSL { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ExitIfNotProfitableAfterMinHold", Order = 580, GroupName = "Risk Engine: Controlled Hold")]
		public bool ExitIfNotProfitableAfterMinHold { get; set; }

		[NinjaScriptProperty]
		[Range(-20, 100)]
		[Display(Name = "MinProfitTicksAfterMinHold", Order = 581, GroupName = "Risk Engine: Controlled Hold")]
		public int MinProfitTicksAfterMinHold { get; set; }

		[NinjaScriptProperty]
		[Range(0, 600000)]
		[Display(Name = "HardMaxHoldMs", Order = 582, GroupName = "Risk Engine: Controlled Hold")]
		public int HardMaxHoldMs { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowRiskDebugPanel", Order = 58, GroupName = "Risk Engine")]
		public bool ShowRiskDebugPanel { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "DrawSimulatedSLLine", Order = 59, GroupName = "Risk Engine")]
		public bool DrawSimulatedSLLine { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RiskOutputTrace", Order = 60, GroupName = "Risk Engine")]
		public bool RiskOutputTrace { get; set; }

		[NinjaScriptProperty]
		[Range(0, 5000)]
		[Display(Name = "RiskOutputMinMs", Order = 61, GroupName = "Risk Engine")]
		public int RiskOutputMinMs { get; set; }

		[NinjaScriptProperty]
		[Range(100, 5000)]
		[Display(Name = "ForceExitRetryMs", Order = 62, GroupName = "Risk Engine")]
		public int ForceExitRetryMs { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseAccountFlattenEmergency", Order = 64, GroupName = "Risk Engine")]
		public bool UseAccountFlattenEmergency { get; set; }

		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "ForceExitBeforeAccountFlattenAttempts", Order = 65, GroupName = "Risk Engine")]
		public int ForceExitBeforeAccountFlattenAttempts { get; set; }

		[NinjaScriptProperty]
		[Range(250, 10000)]
		[Display(Name = "AccountFlattenRetryMs", Order = 66, GroupName = "Risk Engine")]
		public int AccountFlattenRetryMs { get; set; }

		// -------------------- CSV Trade Export --------------------
		[NinjaScriptProperty]
		[Display(Name = "EnableTradeCsvExport", Order = 70, GroupName = "CSV Export")]
		public bool EnableTradeCsvExport { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "TradeCsvFileName", Order = 71, GroupName = "CSV Export")]
		public string TradeCsvFileName { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "CsvFlushEveryLine", Order = 72, GroupName = "CSV Export")]
		public bool CsvFlushEveryLine { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "CsvExportOnlyCompletedTrades", Order = 73, GroupName = "CSV Export")]
		public bool CsvExportOnlyCompletedTrades { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "CsvStartNewFileEachRun", Order = 74, GroupName = "CSV Export")]
		public bool CsvStartNewFileEachRun { get; set; }
		[NinjaScriptProperty]
		[Range(0, 2000)]
		[Display(Name = "MinEntryQuoteStabilityMs", Order = 83, GroupName = "Execution Guard")]
		public int MinEntryQuoteStabilityMs { get; set; }
		[NinjaScriptProperty]
		[Range(0, 20)]
		[Display(Name = "MaxSpreadWorsenTicks", Order = 84, GroupName = "Execution Guard")]
		public int MaxSpreadWorsenTicks { get; set; }
		[NinjaScriptProperty]
		[Display(Name = "CancelEntryOnSignalFlip", Order = 85, GroupName = "Execution Guard")]
		public bool CancelEntryOnSignalFlip { get; set; }
		[NinjaScriptProperty]
		[Display(Name = "CancelEntryOnNewBar", Order = 86, GroupName = "Execution Guard")]
		public bool CancelEntryOnNewBar { get; set; }
		[NinjaScriptProperty]
		[Range(1, 30)]
		[Display(Name = "MaxEntryMidDeviationTicks", Order = 87, GroupName = "Execution Guard")]
		public int MaxEntryMidDeviationTicks { get; set; }
		[NinjaScriptProperty]
		[Range(1, 10)]
		[Display(Name = "MaxTradesPerBar", Order = 88, GroupName = "Overtrading Guard")]
		public int MaxTradesPerBar { get; set; }
		[NinjaScriptProperty]
		[Range(0, 20)]
		[Display(Name = "CooldownAfterExitBars", Order = 89, GroupName = "Overtrading Guard")]
		public int CooldownAfterExitBars { get; set; }
		[NinjaScriptProperty]
		[Range(0, 20)]
		[Display(Name = "CooldownAfterSLBars", Order = 90, GroupName = "Overtrading Guard")]
		public int CooldownAfterSLBars { get; set; }
		[NinjaScriptProperty]
		[Range(1, 500)]
		[Display(Name = "MaxTradesPerSession", Order = 91, GroupName = "Overtrading Guard")]
		public int MaxTradesPerSession { get; set; }
		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "ConsecutiveLossLimit", Order = 92, GroupName = "Overtrading Guard")]
		public int ConsecutiveLossLimit { get; set; }
		[NinjaScriptProperty]
		[Range(1, 120)]
		[Display(Name = "LossWindowMinutes", Order = 93, GroupName = "Overtrading Guard")]
		public int LossWindowMinutes { get; set; }
		[NinjaScriptProperty]
		[Range(1, 120)]
		[Display(Name = "LossPauseMinutes", Order = 94, GroupName = "Overtrading Guard")]
		public int LossPauseMinutes { get; set; }

		[NinjaScriptProperty]
		[Range(1, 80)]
		[Display(Name = "TargetTicks", Order = 6, GroupName = "Trading")]
		public int TargetTicks { get; set; }

		[NinjaScriptProperty]
		[Range(1, 10)]
		[Display(Name = "MaxSpreadTicks", Order = 7, GroupName = "Trading")]
		public int MaxSpreadTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "TradeWindowStart (HH:mm)", Order = 8, GroupName = "Trading")]
		public string TradeWindowStart { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "TradeWindowEnd (HH:mm)", Order = 9, GroupName = "Trading")]
		public string TradeWindowEnd { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseLimitEntries", Order = 10, GroupName = "Trading")]
		public bool UseLimitEntries { get; set; }

		[NinjaScriptProperty]
		[Range(0, 6)]
		[Display(Name = "LimitOffsetTicks", Order = 11, GroupName = "Trading")]
		public int LimitOffsetTicks { get; set; }

		[NinjaScriptProperty]
		[Range(1, 30)]
		[Display(Name = "CancelEntryIfAwayTicks", Order = 12, GroupName = "Trading")]
		public int CancelEntryIfAwayTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "EnableLongTrades", Order = 120, GroupName = "Execution Guard")]
		public bool EnableLongTrades { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "EnableShortTrades", Order = 121, GroupName = "Execution Guard")]
		public bool EnableShortTrades { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "DisableLongsWhenShortEdgeDominates", Order = 122, GroupName = "Execution Guard")]
		public bool DisableLongsWhenShortEdgeDominates { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "LongMinAbsPredTicks", Order = 123, GroupName = "Execution Guard")]
		public int LongMinAbsPredTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "ShortMinAbsPredTicks", Order = 124, GroupName = "Execution Guard")]
		public int ShortMinAbsPredTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "AllowHighConvictionWideSpread", Order = 125, GroupName = "Execution Guard")]
		public bool AllowHighConvictionWideSpread { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "HighConvictionPredTicks", Order = 126, GroupName = "Execution Guard")]
		public int HighConvictionPredTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseOpeningNoiseFilter", Order = 127, GroupName = "Execution Guard")]
		public bool UseOpeningNoiseFilter { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "NoTradeBefore", Order = 128, GroupName = "Execution Guard")]
		public string NoTradeBefore { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseAtrStabilizationFilter", Order = 129, GroupName = "Execution Guard")]
		public bool UseAtrStabilizationFilter { get; set; }

		[NinjaScriptProperty]
		[Range(0.5, 10.0)]
		[Display(Name = "MaxAtrExpansionRatio", Order = 130, GroupName = "Execution Guard")]
		public double MaxAtrExpansionRatio { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseMarketEntriesForDiagnostics", Order = 131, GroupName = "Execution Guard")]
		public bool UseMarketEntriesForDiagnostics { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "CsvLogSubmitPrediction", Order = 132, GroupName = "Execution Guard")]
		public bool CsvLogSubmitPrediction { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "UseQuoteEvents (LO'/CA' proxies)", Order = 13, GroupName = "Eisler Model")]
		public bool UseQuoteEvents { get; set; }

		[NinjaScriptProperty]
		[Range(0, 50)]
		[Display(Name = "QuoteEventMinMs", Order = 14, GroupName = "Eisler Model")]
		public int QuoteEventMinMs { get; set; }

		[NinjaScriptProperty]
		[Range(1, 12)]
		[Display(Name = "ImbLookbackTicks", Order = 15, GroupName = "Order Flow+")]
		public int ImbLookbackTicks { get; set; }

		[NinjaScriptProperty]
		[Range(1, 200)]
		[Display(Name = "MinTradeSize", Order = 16, GroupName = "Order Flow+")]
		public int MinTradeSize { get; set; }

		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "TrainEveryNEvents", Order = 17, GroupName = "Eisler Model")]
		public int TrainEveryNEvents { get; set; }

		// --- 1) Regime switch params ---
		[NinjaScriptProperty]
		[Range(10, 300)]
		[Display(Name = "RegimeLookbackBars", Order = 18, GroupName = "Regime")]
		public int RegimeLookbackBars { get; set; }

		[NinjaScriptProperty]
		[Range(0.50, 0.99)]
		[Display(Name = "LargeTickProbThreshold", Order = 19, GroupName = "Regime")]
		public double LargeTickProbThreshold { get; set; }

		// --- 2) ΔRπ baseline params ---
		[NinjaScriptProperty]
		[Range(0.001, 0.50)]
		[Display(Name = "BaselineGapAlpha (EWMA)", Order = 20, GroupName = "Baseline")]
		public double BaselineGapAlpha { get; set; }

		[NinjaScriptProperty]
		[Range(10, 500)]
		[Display(Name = "BaselineLookbackEvents", Order = 21, GroupName = "Baseline")]
		public int BaselineLookbackEvents { get; set; }

		[NinjaScriptProperty]
		[Range(0.80, 0.999)]
		[Display(Name = "BaselineDecayPerEvent", Order = 22, GroupName = "Baseline")]
		public double BaselineDecayPerEvent { get; set; }

		[NinjaScriptProperty]
		[Range(0.0, 3.0)]
		[Display(Name = "BaselineWeight", Order = 23, GroupName = "Baseline")]
		public double BaselineWeight { get; set; }

		// --- 3) Gap-flex states (decay) ---
		[NinjaScriptProperty]
		[Range(0.80, 0.999)]
		[Display(Name = "GapStateDecay", Order = 24, GroupName = "GapFlex")]
		public double GapStateDecay { get; set; }

		// --- 4) Induced-pattern filter params ---
		[NinjaScriptProperty]
		[Range(50, 5000)]
		[Display(Name = "RefillWindowMs", Order = 25, GroupName = "Induced Filters")]
		public int RefillWindowMs { get; set; }

		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "RefillOpposingQuoteThreshold", Order = 26, GroupName = "Induced Filters")]
		public int RefillOpposingQuoteThreshold { get; set; }

		// --- 5) Concave impact sizing params ---
		[NinjaScriptProperty]
		[Range(1, 20)]
		[Display(Name = "BaseQuantity", Order = 27, GroupName = "Sizing")]
		public int BaseQuantity { get; set; }

		[NinjaScriptProperty]
		[Range(0.0, 10.0)]
		[Display(Name = "SizeActivityK", Order = 28, GroupName = "Sizing")]
		public double SizeActivityK { get; set; }

		[NinjaScriptProperty]
		[Range(10, 500)]
		[Display(Name = "ActivityLookbackBars", Order = 29, GroupName = "Sizing")]
		public int ActivityLookbackBars { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "DebugPrint", Order = 30, GroupName = "Debug")]
		public bool DebugPrint { get; set; }

		// -------------------- Reset parameters --------------------
		[NinjaScriptProperty]
		[Display(Name = "UseCustomResetTime", Order = 31, GroupName = "Reset")]
		public bool UseCustomResetTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "DailyResetTime (HH:mm)", Order = 32, GroupName = "Reset")]
		public string DailyResetTime { get; set; }

		// NEW: Periodic reset every N minutes (clock-multiple)
		[NinjaScriptProperty]
		[Display(Name = "UsePeriodicReset", Order = 33, GroupName = "Reset")]
		public bool UsePeriodicReset { get; set; }

		[NinjaScriptProperty]
		[Range(1, 60)]
		[Display(Name = "PeriodicResetMinutes", Order = 34, GroupName = "Reset")]
		public int PeriodicResetMinutes { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "PeriodicResetOnlyWhenFlat", Order = 35, GroupName = "Reset")]
		public bool PeriodicResetOnlyWhenFlat { get; set; }



// -------------------- Latency / Jitter robustness --------------------
[NinjaScriptProperty]
[Display(Name = "UseLatencyJitterProtection", Order = 40, GroupName = "Latency")]
public bool UseLatencyJitterProtection { get; set; }

[NinjaScriptProperty]
[Display(Name = "AutoEstimateLatency", Order = 41, GroupName = "Latency")]
public bool AutoEstimateLatency { get; set; }

[NinjaScriptProperty]
[Range(0, 50)]
[Display(Name = "ManualLatencyMs (CQG ~2ms)", Order = 42, GroupName = "Latency")]
public int ManualLatencyMs { get; set; }

[NinjaScriptProperty]
[Range(10, 500)]
[Display(Name = "FreshnessMaxMs", Order = 43, GroupName = "Latency")]
public int FreshnessMaxMs { get; set; }

[NinjaScriptProperty]
[Range(5, 500)]
[Display(Name = "JitterP95MaxMs", Order = 44, GroupName = "Latency")]
public int JitterP95MaxMs { get; set; }

[NinjaScriptProperty]
[Range(50, 4000)]
[Display(Name = "MaxEntryOrderAgeMs", Order = 45, GroupName = "Latency")]
public int MaxEntryOrderAgeMs { get; set; }

[NinjaScriptProperty]
[Range(0, 2000)]
[Display(Name = "MinOrderWorkingMs", Order = 46, GroupName = "Latency")]
public int MinOrderWorkingMs { get; set; }

[NinjaScriptProperty]
[Range(1, 10)]
[Display(Name = "ConfirmEvents", Order = 47, GroupName = "Latency")]
public int ConfirmEvents { get; set; }

[NinjaScriptProperty]
[Range(0, 2000)]
[Display(Name = "MinSignalHoldMs", Order = 48, GroupName = "Latency")]
public int MinSignalHoldMs { get; set; }

[NinjaScriptProperty]
[Range(0.0, 5.0)]
[Display(Name = "DynamicThresholdK", Order = 49, GroupName = "Latency")]
public double DynamicThresholdK { get; set; }

[NinjaScriptProperty]
[Range(0.0, 5.0)]
[Display(Name = "DynamicOffsetK", Order = 50, GroupName = "Latency")]
public double DynamicOffsetK { get; set; }
[NinjaScriptProperty]
[Display(Name = "UsePlaybackBurstConfirmOverride", Order = 501, GroupName = "Latency")]
public bool UsePlaybackBurstConfirmOverride { get; set; }
[NinjaScriptProperty]
[Display(Name = "UsePlaybackFriendlyFreshness", Order = 500, GroupName = "Latency")]
public bool UsePlaybackFriendlyFreshness { get; set; }

[NinjaScriptProperty]
[Range(0, 10)]
[Display(Name = "PlaybackBurstConfirmExtraEvents", Order = 502, GroupName = "Latency")]
public int PlaybackBurstConfirmExtraEvents { get; set; }
[NinjaScriptProperty]
[Range(0, 250)]
[Display(Name = "PlaybackBurstConfirmMaxHoldBypassMs", Order = 503, GroupName = "Latency")]
public int PlaybackBurstConfirmMaxHoldBypassMs { get; set; }
[NinjaScriptProperty]
[Range(0, 1000)]
[Display(Name = "MaxAbsPredictionTicks", Order = 504, GroupName = "Latency")]
public int MaxAbsPredictionTicks { get; set; }
		// -------------------- L1 quote state --------------------
		private double _bestBid = double.NaN;
		private double _bestAsk = double.NaN;
		private double _prevMid = double.NaN;

		// Pending trade -> decide MO0 vs MO1
		private bool _pendingTrade = false;
		private DateTime _pendingTradeTime = Core.Globals.MinDate;
		private int _pendingSide = 0;
		private double _pendingMid = double.NaN;
		private int _pendingWindowMs = 120;

		private DateTime _lastQuoteEventTime = Core.Globals.MinDate;

		// Induced-pattern tracking (refill trap)
		private DateTime _lastPriceMoveTime = Core.Globals.MinDate;
		private int _lastPriceMoveDir = 0; // +1 up, -1 down
		private int _oppQuoteCount = 0;

		private readonly LinkedList<BookEvent> _events = new LinkedList<BookEvent>();
		private int _eventCounter = 0;

		// -------------------- Risk Exit State Machine --------------------
		private enum RiskExitState
		{
			ARMED,
			SL_TOUCHED,
			EXIT_SUBMITTED,
			RETRY_PENDING,
			EMERGENCY_PENDING,
			FLAT_CONFIRMED,
			FAILED_BUT_STRATEGY_STILL_RUNNING
		}

		private enum TradeState { Flat, Phase1_BreathingRoom, Phase2_RiskFree, Phase3_TrendCapture, Closing }

		private Order _entryOrder = null;
		private Order _catastrophicStopOrder = null;
		private double _entryLimitPx = 0;
		private int _entrySignalSeq = 0;
		private string _activeEntrySignal = string.Empty;
		private string _catastrophicStopSignal = string.Empty;
		private int _activeEntryDir = 0;
		private double _activeEntryAvgPrice = 0.0;
		private double _simulatedSL = 0.0;
		private double _lastCheckPrice = 0.0;
		private bool _slTouched = false;
		private bool _exitSubmitted = false;
		private int _exitRetryStage = 0;
		private DateTime _slTouchedTime = Core.Globals.MinDate;
		private DateTime _lastExitSubmitTime = Core.Globals.MinDate;
		private DateTime _lastForceExitSubmitTime = Core.Globals.MinDate;
		private int _forceExitSeq = 0;
		private int _persistentForceExitAttempts = 0;
		private bool _accountFlattenAttempted = false;
		private DateTime _lastAccountFlattenTime = Core.Globals.MinDate;
		private string _lastExitReason = string.Empty;
		private DateTime _lastRiskOutputTime = Core.Globals.MinDate;
		private string _lastRiskTraceLine = string.Empty;
		private double _previousCheckPrice = 0.0;
		private string _lastTouchSource = string.Empty;
		// v7_4 controlled soft-stop persistence state
		private bool _softStopActive = false;
		private DateTime _softStopFirstTouchCoreTime = Core.Globals.MinDate;
		private int _softStopTouchEvents = 0;
		private double _softStopMaxBreachTicks = 0.0;
		private string _softStopLastSource = string.Empty;
		private DateTime _lastTrailUpdateTime = Core.Globals.MinDate;
		private bool _catastrophicStopSubmitted = false;

		// ---- Post-entry extremum tracking (SL-touch guard) ----
		private int    _activeEntryBar  = -1;
		private DateTime _activeEntryTime = Core.Globals.MinDate;
		private double _postEntryLow    = double.NaN;
		private double _postEntryHigh   = double.NaN;
		private const string EntrySignalPrefix = "EISLER_NQ_ENH_AE72";

		// -------------------- Risk Exit State Machine fields --------------------
		private RiskExitState _riskExitState = RiskExitState.ARMED;
		private DateTime _riskStateEnteredTime = Core.Globals.MinDate;
		private int _unmanagedExitSeq = 0;
		private Order _unmanagedExitOrder = null;
		private DateTime _lastUnmanagedExitTime = Core.Globals.MinDate;
		private int _unmanagedExitAttempts = 0;
		private string _unmanagedExitOrderName = string.Empty;
		private TimeSpan _twStart, _twEnd;

		// --- Daily pre-open reset tracking ---
		private DateTime _lastDailyResetDate = Core.Globals.MinDate;
		private TimeSpan _resetTime;
		private bool _resetTimeParsed = false;

		// --- Periodic reset tracking ---
		private DateTime _lastPeriodicResetKey = Core.Globals.MinDate;
private ATR _atr = null;
private DateTime _lastMarketDataTime = Core.Globals.MinDate;
private DateTime _activeEntryFillTime = Core.Globals.MinDate;
private DateTime _activeEntryFillCoreTime = Core.Globals.MinDate;
private double _currentOneR_Ticks = 0.0;
private double _atrTicksAtEntry = 0.0;
private double _rawOneRTicksAtEntry = 0.0;
private bool _oneRWasClamped = false;
private TradeState _currentTradeState = TradeState.Flat;
private double _tradeHighestHigh = double.NaN;
private double _tradeLowestLow = double.NaN;
private bool _profitTargetSubmitted = false;
private string _profitTargetSignal = string.Empty;
private DateTime _lastOvertradingResetDate = Core.Globals.MinDate;
private bool _lastEntryRejectedBySpread = false;
private bool _lastEntryRejectedByOpeningNoise = false;
private bool _lastEntryRejectedByLowConviction = false;
private bool _lastEntryRejectedByDirectionalFilter = false;
private double _lastSpreadAtReject = 0.0;
private DateTime _lastGateTimeAtReject = Core.Globals.MinDate;
private double _lastEarlyFailureHeldMs = 0.0;
private double _lastEarlyFailureMfeR = 0.0;
private double _lastEarlyFailureMaeR = 0.0;


// --- Latency / jitter tracking (arrival-time based proxies) ---
private DateTime _lastMdArriveTime = Core.Globals.MinDate;
private DateTime _lastBidAskArriveTime = Core.Globals.MinDate;
private double[] _mdInterArrivalMs;
private int _mdIaIdx = 0;
private int _mdIaCount = 0;
private double _jitterP95Ms = 0.0;
private double _jitterMedianMs = 0.0;
private double _effectiveLatencyMs = 0.0;
private DateTime _confirmStartTime = Core.Globals.MinDate;
private int _confirmDir = 0;
private int _confirmCount = 0;
private DateTime _confirmMarketStartTime = Core.Globals.MinDate;
private int _confirmBurstEventCount = 0;
private double _lastConfirmHeldMs = 0.0;
private double _lastConfirmNeedMs = 0.0;
private bool _lastConfirmEventOk = false;
private bool _lastConfirmTimeOk = false;
private bool _lastConfirmBurstOverride = false;
private double _lastPred = 0.0;
private int _lastPredDir = 0;
private DateTime _entrySubmitLocalTime = Core.Globals.MinDate;
private DateTime _entryWorkingLocalTime = Core.Globals.MinDate;
private DateTime _entrySubmitMarketTime = Core.Globals.MinDate;
private int _entrySubmitBar = -1;
private int _entryDirAtSubmit = 0;
private double _entryPredAtSubmit = 0.0;
private double _entryThresholdAtSubmit = 0.0;
private double _entryBidAtSubmit = 0.0;
private double _entryAskAtSubmit = 0.0;
private double _entrySpreadAtSubmit = 0.0;
private DateTime _lastBidChangeLocalTime = Core.Globals.MinDate;
private DateTime _lastAskChangeLocalTime = Core.Globals.MinDate;
private int _lastEntrySubmitBar = -1;
private int _entrySubmitsThisBar = 0;
private int _lastEntrySubmitBarCounter = -1;
private int _lastExitBar = -1000000;
private int _lastSLExitBar = -1000000;
private int _sessionTradeCount = 0;
private int _consecutiveLossCount = 0;
private DateTime _lossWindowFirstMarketTime = Core.Globals.MinDate;
private DateTime _pauseTradingUntilMarketTime = Core.Globals.MinDate;
private string _csvRunId = string.Empty;
		// Volumetric
		private VolumetricBarsType _volBars = null;
		private bool _hasVolumetric = false;
		private int _vfBar = -1;
		private double _vfDeltaNorm = 0.0;
		private double _vfImbNear = 0.0;
		private double _ofiProxy = 0.0;
		private double _vfTotalVol = 0.0;
		private double _vfAbsDeltaFrac = 0.0;

		// 1) Regime detection buffers
		private int[] _spreadOneBuf;
		private int _spreadOneIdx = 0;
		private int _spreadOneCount = 0;
		private bool _isLargeTick = true;

		// 2) Baseline ΔRπ (EWMA realized gaps) in ticks
		private double _dR_MO = 1.0;
		private double _dR_LO = 1.0;
		private double _dR_CA = 1.0;

		// 3) Gap-flex decaying states (small tick focused)
		private double _stateFlow = 0.0;
		private double _stateGap = 0.0;
		private double _stateImb = 0.0;
		private double _avgSpreadEwma = 1.0;

		// 5) Activity buffers (for concave sizing)
		private double[] _barVolBuf;
		private int _barVolIdx = 0;
		private double _barVolSum = 0.0;

		// RLS
		private int _featDim;
		private int _baseDim;
		private double[] _w;
		private double[,] _P;
		private double[] _x;
		private double[] _Px;
		private double[] _k;

		// ============================================================
		// CSV TRADE LIFECYCLE TRACKING
		// ============================================================
		private int _csvTradeSeq = 0;
		private StreamWriter _csvWriter = null;
		private bool _csvHeaderWritten = false;

		// Per-trade lifecycle snapshot
		private int    _csvTradeId           = 0;
		private string _csvEntrySignal        = string.Empty;
		private int    _csvDirection          = 0;     // +1 Long, -1 Short
		private int    _csvQuantity           = 0;
		private DateTime _csvEntryTime        = Core.Globals.MinDate;
		private int    _csvEntryBar           = -1;
		private double _csvEntryPrice         = 0.0;
		private double _csvEntryBid           = 0.0;
		private double _csvEntryAsk           = 0.0;
		private double _csvEntrySpreadTicks   = 0.0;
		private double _csvEntryPred          = 0.0;
		private double _csvEntryThreshold     = 0.0;
		private string _csvEntryRiskState     = string.Empty;
		private double _csvInitialSimSL       = 0.0;
		private double _csvInitialRiskTicks   = 0.0;

		// Volumetric / flow at entry
		private double _csvVfDeltaNormAtEntry = 0.0;
		private double _csvVfImbNearAtEntry   = 0.0;
		private double _csvOfiProxyAtEntry    = 0.0;
		private double _csvDR_MO_Entry        = 0.0;
		private double _csvDR_LO_Entry        = 0.0;
		private double _csvDR_CA_Entry        = 0.0;

		// Live tracking (updated every tick while in position)
		private double _csvMaxFavorableTicks  = 0.0;
		private double _csvMaxAdverseTicks    = 0.0;
		private double _csvMaxOpenProfitTicks = 0.0;
		private double _csvMaxOpenLossTicks   = 0.0;

		private double _csvMaxFavorablePrice  = 0.0;
		private DateTime _csvMaxFavorableTime = Core.Globals.MinDate;
		private int    _csvMaxFavorableBar    = -1;

		private bool   _csvWasInProfit        = false;
		private DateTime _csvProfitTurnedPositiveTime = Core.Globals.MinDate;
		private int    _csvProfitTurnedPositiveBar    = -1;
		private double _csvProfitTurnedPositiveAtTicks = 0.0;

		// SimSL snapshots
		private double _csvSimSLAtEntry             = 0.0;
		private double _csvSimSLAtFirstProfit        = 0.0;
		private double _csvSimSLAtTrailActivation    = 0.0;
		private double _csvSimSLAtMaxFavorable       = 0.0;

		// Trail activation reached
		private bool   _csvTrailActivationReached    = false;
		private DateTime _csvTrailActivationReachedTime = Core.Globals.MinDate;
		private int    _csvTrailActivationReachedBar = -1;
		private double _csvTrailActivationReachedAtTicks = 0.0;

		// Trail move tracking
		private int    _csvTrailMoveCount            = 0;
		private DateTime _csvFirstTrailMoveTime      = Core.Globals.MinDate;
		private DateTime _csvLastTrailMoveTime       = Core.Globals.MinDate;
		private double _csvBestSimSL                 = 0.0;  // highest SL for long / lowest SL for short
		private double _csvMaxDistanceFromSimSLTicks = 0.0;
		private double _csvMinDistanceFromSimSLTicks = double.MaxValue;

		// Exit snapshot
		private string _csvExitReason    = string.Empty;
		private string _csvExitOrderName = string.Empty;
		private string _csvExitOrderState = string.Empty;
		private string _csvExitError     = string.Empty;
		private string _csvExitNativeError = string.Empty;
		private string _csvExitRiskState  = string.Empty;
		private int    _csvExitRetryStage = 0;
		private bool   _csvExitWasSLTouch = false;
		private bool   _csvExitWasRetry   = false;
		private bool   _csvExitWasEmergency = false;
		private bool   _csvExitWasUnmanaged = false;
		private bool   _csvExitWasAccountFlatten = false;
		private bool   _csvExitWasCatastrophic  = false;

		// State snapshot at exit
		private double _csvVfDeltaNormAtExit = 0.0;
		private double _csvVfImbNearAtExit   = 0.0;
		private double _csvOfiProxyAtExit    = 0.0;
		private double _csvDR_MO_Exit        = 0.0;
		private double _csvDR_LO_Exit        = 0.0;
		private double _csvDR_CA_Exit        = 0.0;
		private double _csvRlsPredAtEntry    = 0.0;
		private double _csvRlsPredAtExit     = 0.0;
		private double _csvLastPredDirAtExit = 0.0;

		// Active trade flag
		private bool _csvTradeActive = false;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "eisler950_AdaptiveEdge_v7_4";
				Description = "Enhanced Eisler-style event-impact WITHOUT Level II, tuned for NQ 1-minute Volumetric (Bid/Ask) using L1 Bid/Ask/Last. Adds regime switch, ΔR baseline, gap-flex states, induced filters, concave sizing.";
				Calculate = Calculate.OnEachTick;
				EntriesPerDirection = 1;
				EntryHandling = EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy = true;
				ExitOnSessionCloseSeconds = 30;
				IsOverlay = true;
				RealtimeErrorHandling = RealtimeErrorHandling.IgnoreAllErrors;

				KernelLags = 160;
				RlsLambda = 0.995;
				EntryThresholdTicksLarge = 3;
				EntryThresholdTicksSmall = 4;
				StopTicks = 14;
				TrailUpdateMinMs = 200;
				StopMarketSafetyTicks = 4;
				UseAtrDynamicRisk = true;
				OneRCalibrationMode = OneRMode.Balanced;
				AtrPeriod = 14;
				VolatilityMultiplier = 0.45;
				MinOneRTicks = 8;
				MaxOneRTicks = 20;
				FreeTradeActivation_R = 1.25;
				FreeTradeOffsetTicks = 1;
				TrailingActivation_R = 2.0;
				UseStructuralTrailing = true;
				StructuralLookbackBars = 3;
				StructuralOffsetTicks = 2;
				UseChandelierTrailing = true;
				ChandelierAtrMultiplier = 3.0;
				UseProfitTargetLimit = false;
				ProfitTarget_R = 2.8;
				UseEarlyFailureExit = true;
				EarlyFailureMaxAdverse_R = 0.75;
				EarlyFailureMinMfe_R = 0.15;
				EarlyFailureMinHoldMs = 2500;
				ExitRetryMs = 500;
				EmergencyExitMs = 1500;
				ForceExitRetryMs = 500;
				UseAccountFlattenEmergency = true;
				ForceExitBeforeAccountFlattenAttempts = 3;
				AccountFlattenRetryMs = 1000;
				CatastrophicStopTicks = 60;
				// v7_4 controlled 3-minute soft-stop hold with hard -60 tick cap
				UseControlledSoftStopHold = true;
				MinHoldMsBeforeSoftSLExit = 180000;
				InitialStopMaxBreachTicks = 8;
				BidAskHardBreachTicks = 8;
				IgnorePostEntrySoftStopUntilMinHold = true;
				PostEntrySoftHardBreachTicks = 60;
				SoftStopConfirmMs = 1500;
				SoftStopConfirmEvents = 3;
				DoNotIgnoreBidAskCrossBreach = true;
				IgnoreEntryBarPostExtremumForSL = true;
				ExitIfNotProfitableAfterMinHold = true;
				MinProfitTicksAfterMinHold = 0;
				HardMaxHoldMs = 300000;
				ShowRiskDebugPanel = true;
				DrawSimulatedSLLine = true;
				RiskOutputTrace = true;
				RiskOutputMinMs = 150;
				TargetTicks = 42;
				MaxSpreadTicks = 2;
				TradeWindowStart = "09:50";
				TradeWindowEnd = "11:30";
				UseLimitEntries = true;
				LimitOffsetTicks = 1;
				CancelEntryIfAwayTicks = 3;
				EnableLongTrades = true;
				EnableShortTrades = true;
				DisableLongsWhenShortEdgeDominates = false;
				LongMinAbsPredTicks = 12;
				ShortMinAbsPredTicks = 8;
				AllowHighConvictionWideSpread = false;
				HighConvictionPredTicks = 20;
				UseOpeningNoiseFilter = true;
				NoTradeBefore = "10:20";
				UseAtrStabilizationFilter = true;
				MaxAtrExpansionRatio = 1.50;
				UseMarketEntriesForDiagnostics = false;
				CsvLogSubmitPrediction = true;

				UseQuoteEvents = true;
				QuoteEventMinMs = 5;
				ImbLookbackTicks = 3;
				MinTradeSize = 1;
				TrainEveryNEvents = 1;

				RegimeLookbackBars = 120;
				LargeTickProbThreshold = 0.85;

				BaselineGapAlpha = 0.03;
				BaselineLookbackEvents = 120;
				BaselineDecayPerEvent = 0.985;
				BaselineWeight = 0.6;

				GapStateDecay = 0.97;
				RefillWindowMs = 900;
				RefillOpposingQuoteThreshold = 3;

				BaseQuantity = 1;
				SizeActivityK = 1.2;
				ActivityLookbackBars = 60;

				DebugPrint = false;

				// Reset defaults
				UseCustomResetTime = false;
				DailyResetTime = "09:49";

				// Periodic reset defaults (requested: every 5 minutes)
				UsePeriodicReset = true;
				PeriodicResetMinutes = 5;
				PeriodicResetOnlyWhenFlat = true;

				// CSV Export defaults
				EnableTradeCsvExport = true;
				TradeCsvFileName = "eisler_trade_lifecycle.csv";
				CsvFlushEveryLine = true;
				CsvExportOnlyCompletedTrades = false;
				CsvStartNewFileEachRun = true;
				MinEntryQuoteStabilityMs = 0;
				MaxSpreadWorsenTicks = 0;
				CancelEntryOnSignalFlip = true;
				CancelEntryOnNewBar = true;
				MaxEntryMidDeviationTicks = 4;
				MaxTradesPerBar = 1;
				CooldownAfterExitBars = 1;
				CooldownAfterSLBars = 2;
				MaxTradesPerSession = 30;
				ConsecutiveLossLimit = 2;
				LossWindowMinutes = 5;
				LossPauseMinutes = 5;

				// Latency defaults (CQG ~2ms, but use robust gating)
				UseLatencyJitterProtection = true;
				AutoEstimateLatency = true;
				ManualLatencyMs = 2;
				FreshnessMaxMs = 500;
				JitterP95MaxMs = 120;
				MaxEntryOrderAgeMs = 250;
				MinOrderWorkingMs = 150;
				ConfirmEvents = 3;
				MinSignalHoldMs = 60;
				DynamicThresholdK = 0.7;
				DynamicOffsetK = 0.6;
				UsePlaybackFriendlyFreshness = true;
				UsePlaybackBurstConfirmOverride = true;
				PlaybackBurstConfirmExtraEvents = 1;
				PlaybackBurstConfirmMaxHoldBypassMs = 80;
				MaxAbsPredictionTicks = 100;
			}
			else if (State == State.Configure)
			{
				ParseTradeWindow();
				ParseResetTime();

				_baseDim = 6 * KernelLags;
				// extra features:
				//  0 SpreadTicks
				//  1 vfDeltaNorm
				//  2 vfImbNear
				//  3 ofiProxy
				//  4 isLargeTick (0/1)
				//  5 baselinePred
				//  6 stateFlow
				//  7 stateGap
				//  8 stateImb
				_featDim = _baseDim + 9;

				_w = new double[_featDim];
				_P = new double[_featDim, _featDim];
				_x = new double[_featDim];
				_Px = new double[_featDim];
				_k = new double[_featDim];
				InitRls();

				_spreadOneBuf = new int[Math.Max(10, RegimeLookbackBars)];
				_barVolBuf = new double[Math.Max(10, ActivityLookbackBars)];
				_mdInterArrivalMs = new double[512];
			}
			else if (State == State.DataLoaded)
			{
				try
				{
					_volBars = Bars != null ? (Bars.BarsSeries.BarsType as VolumetricBarsType) : null;
					_hasVolumetric = _volBars != null;
					_atr = ATR(Math.Max(2, AtrPeriod));
				}
				catch
				{
					_volBars = null;
					_hasVolumetric = false;
				}
			}
			
else if (State == State.Terminated)
{
    CsvCloseWriter();
}

		}

		private void ParseTradeWindow()
		{
			if (!TimeSpan.TryParse(TradeWindowStart, out _twStart))
				_twStart = new TimeSpan(9, 30, 0);
			if (!TimeSpan.TryParse(TradeWindowEnd, out _twEnd))
				_twEnd = new TimeSpan(16, 0, 0);
		}

		private void ParseResetTime()
		{
			_resetTimeParsed = TimeSpan.TryParse(DailyResetTime, out _resetTime);
			if (!_resetTimeParsed)
				_resetTime = new TimeSpan(9, 29, 0);
		}

		private bool InTradeWindow(DateTime t)
		{
			var tod = t.TimeOfDay;
			return tod >= _twStart && tod < _twEnd;
		}



// -------------------- Latency / Jitter helpers --------------------
private void RecordMarketDataArrival(DateTime arriveTime, bool isBidAsk)
{
	// inter-arrival (proxy for jitter/buffering)
	if (_lastMdArriveTime != Core.Globals.MinDate)
	{
		double ia = (arriveTime - _lastMdArriveTime).TotalMilliseconds;
		if (ia >= 0 && ia < 10_000)
		{
			if (_mdInterArrivalMs == null || _mdInterArrivalMs.Length == 0)
				_mdInterArrivalMs = new double[512];
			_mdInterArrivalMs[_mdIaIdx] = ia;
			_mdIaIdx = (_mdIaIdx + 1) % _mdInterArrivalMs.Length;
			_mdIaCount = Math.Min(_mdIaCount + 1, _mdInterArrivalMs.Length);
		}
	}
	_lastMdArriveTime = arriveTime;
	if (isBidAsk)
		_lastBidAskArriveTime = arriveTime;
}

private void UpdateLatencyStatsIfNeeded()
{
	if (!UseLatencyJitterProtection) return;
	if (_mdIaCount < 10) return;

	// Copy the most recent samples into a temp array and compute median + p95.
	int n = _mdIaCount;
	double[] tmp = new double[n];
	for (int i = 0; i < n; i++)
	{
		int idx = (_mdIaIdx - 1 - i);
		if (idx < 0) idx += _mdInterArrivalMs.Length;
		tmp[i] = _mdInterArrivalMs[idx];
	}
	Array.Sort(tmp);
	_jitterMedianMs = tmp[n / 2];
	int p95i = (int)Math.Floor(0.95 * (n - 1));
	_jitterP95Ms = tmp[Math.Max(0, Math.Min(n - 1, p95i))];

	// Effective latency: base latency + jitter buffer (p95)
	double baseMs = Math.Max(0, ManualLatencyMs);
	if (AutoEstimateLatency)
	{
		// If feed is smooth, median inter-arrival can be a proxy for minimum practical reaction time.
		baseMs = Math.Max(baseMs, _jitterMedianMs);
	}
	_effectiveLatencyMs = baseMs + _jitterP95Ms;
}

private double CurrentFreshnessMs()
{
	if (_lastBidAskArriveTime == Core.Globals.MinDate) return 999999;
	if (UsePlaybackFriendlyFreshness)
	{
		if (State == State.Historical) return 0;
		if (_mdIaCount >= 20 && _jitterP95Ms <= Math.Max(10, JitterP95MaxMs) && _lastMdArriveTime != Core.Globals.MinDate)
		{
			double mdAge = (Core.Globals.Now - _lastMdArriveTime).TotalMilliseconds;
			if (mdAge <= Math.Max(250, FreshnessMaxMs)) return Math.Min(FreshnessMaxMs, mdAge);
		}
	}
	return (Core.Globals.Now - _lastBidAskArriveTime).TotalMilliseconds;
}

private bool LatencyGateBlocks(out string reason)
{
	reason = null;
	if (!UseLatencyJitterProtection) return false;
	UpdateLatencyStatsIfNeeded();

	double fresh = CurrentFreshnessMs();
	if (fresh > Math.Max(10, FreshnessMaxMs))
	{
		reason = $"Stale quotes (freshness={fresh:F0}ms)";
		return true;
	}
	if (_mdIaCount >= 20 && _jitterP95Ms > Math.Max(5, JitterP95MaxMs))
	{
		reason = $"High jitter (p95={_jitterP95Ms:F1}ms)";
		return true;
	}
	return false;
}

private int EffectiveThreshold(int baseThr)
{
	if (!UseLatencyJitterProtection) return baseThr;
	UpdateLatencyStatsIfNeeded();
	double k = Math.Max(0.0, DynamicThresholdK);
	int add = (int)Math.Ceiling(k * (_effectiveLatencyMs / 10.0));
	return Math.Max(1, baseThr + add);
}

private int EffectiveLimitOffsetTicks(int baseOffset)
{
	if (!UseLatencyJitterProtection) return baseOffset;
	UpdateLatencyStatsIfNeeded();
	double k = Math.Max(0.0, DynamicOffsetK);
	int add = (int)Math.Ceiling(k * (_effectiveLatencyMs / 10.0));
	return Math.Max(0, Math.Min(10, baseOffset + add));
}

private bool ConfirmSignal(int dir)
{
	_lastConfirmHeldMs = 0.0;
	_lastConfirmNeedMs = Math.Max(0, MinSignalHoldMs);
	_lastConfirmEventOk = false;
	_lastConfirmTimeOk = false;
	_lastConfirmBurstOverride = false;

	if (!UseLatencyJitterProtection) return true;

	DateTime now = Core.Globals.Now;
	DateTime marketTime = CurrentBar >= 0 ? Time[0] : Core.Globals.MinDate;

	if (dir == 0)
	{
		_confirmDir = 0;
		_confirmCount = 0;
		_confirmBurstEventCount = 0;
		_confirmStartTime = Core.Globals.MinDate;
		_confirmMarketStartTime = Core.Globals.MinDate;
		return false;
	}

	if (dir != _confirmDir)
	{
		_confirmDir = dir;
		_confirmCount = 1;
		_confirmBurstEventCount = 1;
		_confirmStartTime = now;
		_confirmMarketStartTime = marketTime;
	}
	else
	{
		_confirmCount++;
		if (_confirmMarketStartTime != Core.Globals.MinDate && marketTime == _confirmMarketStartTime)
			_confirmBurstEventCount++;
		else
		{
			_confirmMarketStartTime = marketTime;
			_confirmBurstEventCount = 1;
		}
	}

	int needN = Math.Max(1, ConfirmEvents);
	double needMs = Math.Max(0, MinSignalHoldMs);
	double heldMs = (_confirmStartTime == Core.Globals.MinDate) ? 0 : (now - _confirmStartTime).TotalMilliseconds;
	if (heldMs < 0) heldMs = 0;

	_lastConfirmHeldMs = heldMs;
	_lastConfirmNeedMs = needMs;
	_lastConfirmEventOk = _confirmCount >= needN;
	_lastConfirmTimeOk = heldMs >= needMs;

	if (_lastConfirmEventOk && _lastConfirmTimeOk)
		return true;

	// Playback / accelerated replay protection:
	// In fast playback many market events can arrive in the same wall-clock millisecond.
	// In that case the event-count confirmation is more reliable than waiting for real PC-time ms.
	if (UsePlaybackBurstConfirmOverride && _lastConfirmEventOk && !_lastConfirmTimeOk)
	{
		int extra = Math.Max(0, PlaybackBurstConfirmExtraEvents);
		double maxBypassMs = Math.Max(0, PlaybackBurstConfirmMaxHoldBypassMs);
		bool enoughExtraEvents = _confirmCount >= needN + extra;
		bool withinBypassWindow = maxBypassMs <= 0 || heldMs <= maxBypassMs;
		bool burstLike = _confirmBurstEventCount >= needN + extra;
		if (enoughExtraEvents && withinBypassWindow && burstLike)
		{
			_lastConfirmBurstOverride = true;
			return true;
		}
	}

	return false;
}
private bool HasStableQuotes()
{
	if (MinEntryQuoteStabilityMs <= 0) return true;
	DateTime now = Core.Globals.Now;
	if (_lastBidChangeLocalTime == Core.Globals.MinDate || _lastAskChangeLocalTime == Core.Globals.MinDate)
		return false;
	double bidAge = (now - _lastBidChangeLocalTime).TotalMilliseconds;
	double askAge = (now - _lastAskChangeLocalTime).TotalMilliseconds;
	return bidAge >= MinEntryQuoteStabilityMs && askAge >= MinEntryQuoteStabilityMs;
}
private void ResetEntrySubmitSnapshot()
{
	_entrySubmitLocalTime = Core.Globals.MinDate;
	_entryWorkingLocalTime = Core.Globals.MinDate;
	_entrySubmitMarketTime = Core.Globals.MinDate;
	_entrySubmitBar = -1;
	_entryDirAtSubmit = 0;
	_entryPredAtSubmit = 0.0;
	_entryThresholdAtSubmit = 0.0;
	_entryBidAtSubmit = 0.0;
	_entryAskAtSubmit = 0.0;
	_entrySpreadAtSubmit = 0.0;
}
private void CancelWorkingEntry(string reason)
{
	try
	{
		if (_entryOrder != null && (_entryOrder.OrderState == OrderState.Working || _entryOrder.OrderState == OrderState.Accepted))
			CancelOrder(_entryOrder);
	}
	catch { }
	if (DebugPrint)
		Print(string.Format("[ENTRY_CANCEL] {0} bar={1} sig={2} predSubmit={3:F2} predNow={4:F2} spreadSubmit={5:F1} spreadNow={6:F1}", reason, CurrentBar, _activeEntrySignal, _entryPredAtSubmit, _lastPred, _entrySpreadAtSubmit, SpreadTicks()));
	// Do not clear _entryOrder/_activeEntrySignal here: a cancel request can still fill.
	// OnOrderUpdate clears the entry state only after Cancelled/Rejected is confirmed.
}
private void ValidateWorkingEntryOrder()
{
	if (_entryOrder == null) return;
	if (!(_entryOrder.OrderState == OrderState.Working || _entryOrder.OrderState == OrderState.Accepted)) return;
	DateTime nowLocal = Core.Globals.Now;
	if (_entryWorkingLocalTime == Core.Globals.MinDate)
		_entryWorkingLocalTime = nowLocal;
	if (MaxEntryOrderAgeMs > 0 && _entrySubmitLocalTime != Core.Globals.MinDate && (nowLocal - _entrySubmitLocalTime).TotalMilliseconds > MaxEntryOrderAgeMs)
	{
		CancelWorkingEntry("STALE_ORDER_AGE");
		return;
	}
	if (CancelEntryOnNewBar && _entrySubmitBar >= 0 && CurrentBar > _entrySubmitBar)
	{
		CancelWorkingEntry("NEW_BAR_AFTER_SUBMIT");
		return;
	}
	double sp = SpreadTicks();
	if (sp > MaxSpreadTicks)
	{
		CancelWorkingEntry("SPREAD_ABOVE_MAX");
		return;
	}
	if (_entrySpreadAtSubmit > 0 && sp > _entrySpreadAtSubmit + Math.Max(0, MaxSpreadWorsenTicks))
	{
		CancelWorkingEntry("SPREAD_WORSENED");
		return;
	}
	double mid = Mid();
	if (!double.IsNaN(mid) && _entryLimitPx > 0)
	{
		double awayTicks = Math.Abs(mid - _entryLimitPx) / TickSize;
		if (awayTicks > CancelEntryIfAwayTicks)
		{
			CancelWorkingEntry("MID_AWAY_FROM_LIMIT");
			return;
		}
	}
	if (_events.Count >= KernelLags)
	{
		double predNow = PredictNextTicks();
		_lastPred = predNow;
		int dirNow = predNow >= _entryThresholdAtSubmit ? +1 : (predNow <= -_entryThresholdAtSubmit ? -1 : 0);
		if (Math.Abs(predNow) < _entryThresholdAtSubmit)
		{
			CancelWorkingEntry("PRED_BELOW_THRESHOLD");
			return;
		}
		if (CancelEntryOnSignalFlip && _entryDirAtSubmit != 0 && dirNow != 0 && dirNow != _entryDirAtSubmit)
		{
			CancelWorkingEntry("PRED_SIGNAL_FLIP");
			return;
		}
	}
}
private bool OvertradingGateBlocks(out string reason)
{
	reason = null;
	DateTime marketNow = Time[0];
	if (_pauseTradingUntilMarketTime != Core.Globals.MinDate && marketNow < _pauseTradingUntilMarketTime)
	{
		reason = "LOSS_PAUSE_UNTIL_" + _pauseTradingUntilMarketTime.ToString("HH:mm:ss");
		return true;
	}
	if (MaxTradesPerSession > 0 && _sessionTradeCount >= MaxTradesPerSession)
	{
		reason = "MAX_TRADES_PER_SESSION";
		return true;
	}
	if (_lastExitBar > -999999 && CurrentBar - _lastExitBar <= Math.Max(0, CooldownAfterExitBars))
	{
		reason = "COOLDOWN_AFTER_EXIT";
		return true;
	}
	if (_lastSLExitBar > -999999 && CurrentBar - _lastSLExitBar <= Math.Max(0, CooldownAfterSLBars))
	{
		reason = "COOLDOWN_AFTER_SL";
		return true;
	}
	if (_lastEntrySubmitBarCounter != CurrentBar)
	{
		_lastEntrySubmitBarCounter = CurrentBar;
		_entrySubmitsThisBar = 0;
	}
	if (_entrySubmitsThisBar >= Math.Max(1, MaxTradesPerBar))
	{
		reason = "MAX_TRADES_PER_BAR";
		return true;
	}
	return false;
}
private void RegisterTradeOutcome(double finalPnLTicks, bool wasSLTouch)
{
	_sessionTradeCount++;
	_lastExitBar = CurrentBar;
	if (wasSLTouch)
		_lastSLExitBar = CurrentBar;
	if (finalPnLTicks < 0)
	{
		DateTime now = Time[0];
		if (_lossWindowFirstMarketTime == Core.Globals.MinDate || (now - _lossWindowFirstMarketTime).TotalMinutes > Math.Max(1, LossWindowMinutes))
		{
			_lossWindowFirstMarketTime = now;
			_consecutiveLossCount = 1;
		}
		else
		{
			_consecutiveLossCount++;
		}
		if (_consecutiveLossCount >= Math.Max(1, ConsecutiveLossLimit))
		{
			_pauseTradingUntilMarketTime = now.AddMinutes(Math.Max(1, LossPauseMinutes));
			if (DebugPrint)
				Print("[PAUSE] Consecutive loss guard active until " + _pauseTradingUntilMarketTime.ToString("HH:mm:ss"));
		}
	}
	else
	{
		_consecutiveLossCount = 0;
		_lossWindowFirstMarketTime = Core.Globals.MinDate;
	}
}

		private void ResetOvertradingGuardsForNewSessionIfNeeded()
		{
			DateTime d = Time[0].Date;
			if (_lastOvertradingResetDate.Date == d) return;
			_sessionTradeCount = 0; _consecutiveLossCount = 0;
			_lossWindowFirstMarketTime = Core.Globals.MinDate; _pauseTradingUntilMarketTime = Core.Globals.MinDate;
			_lastExitBar = -1000000; _lastSLExitBar = -1000000;
			_lastEntrySubmitBarCounter = -1; _entrySubmitsThisBar = 0;
			_lastOvertradingResetDate = d;
		}

		private void ResetEntryRejectDiagnostics()
		{
			_lastEntryRejectedBySpread = false;
			_lastEntryRejectedByOpeningNoise = false;
			_lastEntryRejectedByLowConviction = false;
			_lastEntryRejectedByDirectionalFilter = false;
			_lastSpreadAtReject = 0.0;
			_lastGateTimeAtReject = Core.Globals.MinDate;
		}

		private DateTime CurrentEntryGateTime()
		{
			return _lastMarketDataTime != Core.Globals.MinDate ? _lastMarketDataTime : Time[0];
		}

		private bool IsBeforeNoTradeTime()
		{
			if (!UseOpeningNoiseFilter) return false;
			TimeSpan ts;
			if (!TimeSpan.TryParse(NoTradeBefore, out ts)) return false;
			DateTime gateTime = CurrentEntryGateTime();
			bool blocked = gateTime.TimeOfDay < ts;
			if (blocked) { _lastEntryRejectedByOpeningNoise = true; _lastGateTimeAtReject = gateTime; }
			return blocked;
		}

		private double AtrExpansionRatio()
		{
			if (_atr == null || CurrentBar < Math.Max(20, AtrPeriod) || _atr[0] <= 0) return 1.0;
			double sum = 0.0; int n = 0;
			for (int i = 0; i < 20 && i <= CurrentBar; i++) { if (_atr[i] > 0) { sum += _atr[i]; n++; } }
			if (n <= 0 || sum <= 0) return 1.0;
			return _atr[0] / (sum / n);
		}

		private bool AtrStabilizationBlocks()
		{
			return UseAtrStabilizationFilter && AtrExpansionRatio() > Math.Max(0.5, MaxAtrExpansionRatio);
		}

		private bool SpreadConvictionBlocks(double spread, double pred)
		{
			if (spread > MaxSpreadTicks)
			{
				if (AllowHighConvictionWideSpread && spread <= 4.0 && Math.Abs(pred) >= HighConvictionPredTicks) return false;
				_lastEntryRejectedBySpread = true; _lastSpreadAtReject = spread;
				return true;
			}
			return false;
		}

		// -------------------- Periodic reset (every N minutes) --------------------
		private void HandlePeriodicReset()
		{
			if (!UsePeriodicReset) return;

			int nMin = Math.Max(1, Math.Min(60, PeriodicResetMinutes));
			DateTime t = Time[0];

			// Only trigger on clock multiples: minute % N == 0
			if ((t.Minute % nMin) != 0) return;

			// Optional safety: do not reset while in position
			if (PeriodicResetOnlyWhenFlat && Position != null && Position.MarketPosition != MarketPosition.Flat)
				return;

			// Ensure once per qualifying minute
			DateTime key = new DateTime(t.Year, t.Month, t.Day, t.Hour, t.Minute, 0);
			if (_lastPeriodicResetKey == key) return;

			ResetAllStrategyState();
			_lastPeriodicResetKey = key;

			if (DebugPrint)
				Print($"[RESET] Periodic reset executed at {t:yyyy-MM-dd HH:mm:ss} (interval={nMin}m, minute={t.Minute:00}).");
		}

		// -------------------- Daily reset (custom time or TradeWindowStart - 1 minute) --------------------
		private void HandleDailyPreOpenReset()
		{
			DateTime today = Time[0].Date;

			// safety: ensure time spans are initialized
			if (_twStart == default(TimeSpan))
				ParseTradeWindow();
			if (!_resetTimeParsed)
				ParseResetTime();

			DateTime resetAt;

			// If user provided a custom reset time, use it; otherwise default to TradeWindowStart - 1 minute
			if (UseCustomResetTime)
				resetAt = today.Add(_resetTime);
			else
				resetAt = today.Add(_twStart).AddMinutes(-1);

			// guard if resetAt rolled into previous day
			if (resetAt.Date < today)
				resetAt = today;

			// daily once
			if (Time[0] >= resetAt && _lastDailyResetDate.Date != today)
			{
				ResetAllStrategyState();
				_lastDailyResetDate = today;

			
			}
		}

		private void ResetAllStrategyState()
		{
			// 1) Cancel working entry (if any)
			try
			{
				if (_entryOrder != null && (_entryOrder.OrderState == OrderState.Working || _entryOrder.OrderState == OrderState.Accepted))
					CancelOrder(_entryOrder);
			}
			catch { }

			_entryOrder = null;
			_catastrophicStopOrder = null;
			_entryLimitPx = 0;
			_activeEntrySignal = string.Empty;
			_catastrophicStopSignal = string.Empty;
			_activeEntryDir = 0;
			_activeEntryAvgPrice = 0.0;
			_simulatedSL = 0.0;
			_lastCheckPrice = 0.0;
			_slTouched = false;
			_exitSubmitted = false;
			_exitRetryStage = 0;
			_slTouchedTime = Core.Globals.MinDate;
			_lastExitSubmitTime = Core.Globals.MinDate;
			_lastTrailUpdateTime = Core.Globals.MinDate;
			_catastrophicStopSubmitted = false;
			_lastForceExitSubmitTime = Core.Globals.MinDate;
			_forceExitSeq = 0;
			_lastExitReason = string.Empty;

			// Reset risk state machine
			_riskExitState = RiskExitState.ARMED;
			_riskStateEnteredTime = Core.Globals.MinDate;
			_unmanagedExitSeq = 0;
			_unmanagedExitOrder = null;
			_lastUnmanagedExitTime = Core.Globals.MinDate;
			_unmanagedExitAttempts = 0;
			_unmanagedExitOrderName = string.Empty;

			// 2) Event stream + counters
			_events.Clear();
			_eventCounter = 0;
			_confirmDir = 0;
			_confirmCount = 0;
			_confirmBurstEventCount = 0;
			_confirmStartTime = Core.Globals.MinDate;
			_confirmMarketStartTime = Core.Globals.MinDate;
			_softStopActive = false;
			_softStopFirstTouchCoreTime = Core.Globals.MinDate;
			_softStopTouchEvents = 0;
			_softStopMaxBreachTicks = 0.0;
			_softStopLastSource = string.Empty;

			// 3) L1 / mid state
			_bestBid = double.NaN;
			_bestAsk = double.NaN;
			_prevMid = double.NaN;

			// 4) Pending trade resolver
			_pendingTrade = false;
			_pendingTradeTime = Core.Globals.MinDate;
			_pendingSide = 0;
			_pendingMid = double.NaN;

			_lastQuoteEventTime = Core.Globals.MinDate;

			// 5) Induced-pattern tracking
			_lastPriceMoveTime = Core.Globals.MinDate;
			_lastPriceMoveDir = 0;
			_oppQuoteCount = 0;

			// 6) Volumetric feature cache
			_vfBar = -1;
			_vfDeltaNorm = 0.0;
			_vfImbNear = 0.0;
			_vfTotalVol = 0.0;
			_vfAbsDeltaFrac = 0.0;
			_ofiProxy = 0.0;

			// 7) Regime buffers
			_isLargeTick = true;
			_spreadOneIdx = 0;
			_spreadOneCount = 0;
			if (_spreadOneBuf != null) Array.Clear(_spreadOneBuf, 0, _spreadOneBuf.Length);

			// 8) Baseline ΔRπ
			_dR_MO = 1.0;
			_dR_LO = 1.0;
			_dR_CA = 1.0;

			// 9) Gap-flex states
			_stateFlow = 0.0;
			_stateGap = 0.0;
			_stateImb = 0.0;
			_avgSpreadEwma = 1.0;

			// 10) Activity buffers
			_barVolIdx = 0;
			_barVolSum = 0.0;
			if (_barVolBuf != null) Array.Clear(_barVolBuf, 0, _barVolBuf.Length);

			// 11) RLS reset
			if (_w != null) Array.Clear(_w, 0, _w.Length);

			if (_P != null)
			{
				Array.Clear(_P, 0, _P.Length);
				InitRls();
			}

			if (_x != null) Array.Clear(_x, 0, _x.Length);
			if (_Px != null) Array.Clear(_Px, 0, _Px.Length);
			if (_k != null) Array.Clear(_k, 0, _k.Length);
		}

		private void InitRls()
		{
			for (int i = 0; i < _featDim; i++)
				_P[i, i] = 1000.0;
		}

		private double Mid()
		{
			if (double.IsNaN(_bestBid) || double.IsNaN(_bestAsk) || _bestBid <= 0 || _bestAsk <= 0)
				return double.NaN;
			return 0.5 * (_bestBid + _bestAsk);
		}

		private double SpreadTicks()
		{
			if (double.IsNaN(_bestBid) || double.IsNaN(_bestAsk) || _bestBid <= 0 || _bestAsk <= 0)
				return 999;
			return (_bestAsk - _bestBid) / TickSize;
		}

		private void UpdateVolumetricFeaturesIfNeeded()
		{
			if (_vfBar == CurrentBar) return;
			_vfBar = CurrentBar;
			_vfDeltaNorm = 0.0;
			_vfImbNear = 0.0;
			_vfTotalVol = 0.0;
			_vfAbsDeltaFrac = 0.0;

			if (!_hasVolumetric || _volBars == null) return;

			try
			{
				var v = _volBars.Volumes[CurrentBar];
				double total = Math.Max(1.0, (double)v.TotalVolume);
				_vfTotalVol = total;
				_vfDeltaNorm = Math.Max(-1.0, Math.Min(1.0, (double)v.BarDelta / total));
				_vfAbsDeltaFrac = Math.Min(1.0, Math.Abs((double)v.BarDelta) / total);

				int ticks = Math.Max(1, Math.Min(20, ImbLookbackTicks));
				double center = Close[0];
				double sumDelta = 0.0;
				double sumVol = 0.0;
				for (int k = -ticks; k <= ticks; k++)
				{
					double px = Math.Round((center + k * TickSize) / TickSize) * TickSize;
					long a = v.GetAskVolumeForPrice(px);
					long b = v.GetBidVolumeForPrice(px);
					sumDelta += (double)(a - b);
					sumVol += (double)(a + b);
				}
				_vfImbNear = (sumVol > 1.0) ? Math.Max(-1.0, Math.Min(1.0, sumDelta / sumVol)) : 0.0;
			}
			catch
			{
				_vfDeltaNorm = 0.0;
				_vfImbNear = 0.0;
				_vfTotalVol = 0.0;
				_vfAbsDeltaFrac = 0.0;
			}
		}

		// ---------- Regime detection (large-tick proxy) ----------
		private void UpdateRegimeOnBar()
		{
			if (_spreadOneBuf == null || _spreadOneBuf.Length == 0) return;
			double sp = SpreadTicks();
			int isOne = (sp <= 1.01) ? 1 : 0;

			// circular buffer update
			int prev = _spreadOneBuf[_spreadOneIdx];
			_spreadOneBuf[_spreadOneIdx] = isOne;
			_spreadOneIdx = (_spreadOneIdx + 1) % _spreadOneBuf.Length;
			_spreadOneCount += (isOne - prev);

			double prob = (double)_spreadOneCount / (double)_spreadOneBuf.Length;
			_isLargeTick = prob >= LargeTickProbThreshold;
		}

		// ---------- Activity proxy (for concave sizing) ----------
		private void UpdateActivityOnBar()
		{
			if (_barVolBuf == null || _barVolBuf.Length == 0) return;
			UpdateVolumetricFeaturesIfNeeded();
			double v = _vfTotalVol;
			if (v <= 0) v = Volume[0];

			double prev = _barVolBuf[_barVolIdx];
			_barVolBuf[_barVolIdx] = v;
			_barVolIdx = (_barVolIdx + 1) % _barVolBuf.Length;
			_barVolSum += (v - prev);
		}

		private double AvgBarVol()
		{
			if (_barVolBuf == null || _barVolBuf.Length == 0) return Math.Max(1.0, Volume[0]);
			return Math.Max(1.0, _barVolSum / _barVolBuf.Length);
		}

		private int ComputeDynamicQuantity()
		{
			UpdateVolumetricFeaturesIfNeeded();
			double avgV = AvgBarVol();
			double curV = _vfTotalVol > 0 ? _vfTotalVol : Math.Max(1.0, Volume[0]);

			double volRatio = curV / Math.Max(1.0, avgV);
			double act = 0.5 * volRatio + 0.5 * _vfAbsDeltaFrac; // simple activity index
			double denom = Math.Sqrt(1.0 + Math.Max(0.0, SizeActivityK) * act);
			int q = (int)Math.Round(Math.Max(1.0, BaseQuantity / denom));
			return Math.Max(1, q);
		}

		// ---------- Baseline ΔRπ EWMA update ----------
		private void UpdateBaselineGaps(EventType type, double absMidChTicks)
		{
			double a = Math.Max(0.001, Math.Min(0.50, BaselineGapAlpha));
			absMidChTicks = Math.Max(0.0, absMidChTicks);
			// Clamp to avoid pathological spikes during halts/data gaps.
			absMidChTicks = Math.Min(50.0, absMidChTicks);

			switch (type)
			{
				case EventType.MO1:
					_dR_MO = (1.0 - a) * _dR_MO + a * Math.Max(0.25, absMidChTicks);
					break;
				case EventType.LO1:
					_dR_LO = (1.0 - a) * _dR_LO + a * Math.Max(0.25, absMidChTicks);
					break;
				case EventType.CA1:
					_dR_CA = (1.0 - a) * _dR_CA + a * Math.Max(0.25, absMidChTicks);
					break;
				default:
					break;
			}
		}

		private double GapForEvent(EventType type)
		{
			switch (type)
			{
				case EventType.MO1: return _dR_MO;
				case EventType.LO1: return _dR_LO;
				case EventType.CA1: return _dR_CA;
				default: return 0.0;
			}
		}

		private double ComputeBaselinePred()
		{
			if (_events.Count == 0) return 0.0;
			int L = Math.Max(10, BaselineLookbackEvents);
			double decay = Math.Max(0.80, Math.Min(0.999, BaselineDecayPerEvent));
			double w = 1.0;
			double sum = 0.0;
			int k = 0;

			var node = _events.First;
			// include from most recent backward
			while (node != null && k < L)
			{
				var ev = node.Value;
				if (ev.PriceChanged)
				{
					double g = GapForEvent(ev.Type);
					sum += w * g * ev.Eps;
					w *= decay;
					k++;
				}
				node = node.Next;
			}
			return sum;
		}

		// ---------- Gap-flex states update (small tick focused) ----------
		private void UpdateGapFlexStates(BookEvent ev)
		{
			double d = Math.Max(0.80, Math.Min(0.999, GapStateDecay));

			// Flow state: weight MO higher than quote events
			double wt = (ev.Type == EventType.MO0 || ev.Type == EventType.MO1) ? 1.0 : 0.7;
			_stateFlow = d * _stateFlow + (1.0 - d) * (wt * ev.Eps);

			// Gap state: EWMA of spread deviations
			double sp = ev.SpreadTicks;
			_avgSpreadEwma = 0.995 * _avgSpreadEwma + 0.005 * Math.Max(0.5, Math.Min(10.0, sp));
			double spDev = sp - _avgSpreadEwma;
			_stateGap = d * _stateGap + (1.0 - d) * spDev;

			// Imb state: use near imbalance
			_stateImb = d * _stateImb + (1.0 - d) * ev.ImbNear;
		}

		// ---------- Event emitter ----------
		private void EmitEvent(EventType type, int eps)
		{
			double mid = Mid();
			if (double.IsNaN(mid)) return;
			UpdateVolumetricFeaturesIfNeeded();
			_ofiProxy = 0.85 * _ofiProxy + 0.15 * _vfImbNear;

			double midChTicks = double.IsNaN(_prevMid) ? 0.0 : (mid - _prevMid) / TickSize;
			bool priceChanged = Math.Abs(midChTicks) >= 0.5; // half-tick threshold in ticks

			var ev = new BookEvent
			{
				Time = Time[0],
				Type = type,
				Eps = Math.Sign(eps),
				Mid = mid,
				MidChangeTicks = midChTicks,
				SpreadTicks = SpreadTicks(),
				DeltaNorm = _vfDeltaNorm,
				ImbNear = _vfImbNear,
				OfiProxy = _ofiProxy,
				PriceChanged = priceChanged
			};

			_events.AddFirst(ev);
			while (_events.Count > KernelLags + 5)
				_events.RemoveLast();

			// Induced-pattern bookkeeping
			if (priceChanged)
			{
				_lastPriceMoveTime = ev.Time;
				_lastPriceMoveDir = (midChTicks > 0) ? +1 : (midChTicks < 0 ? -1 : 0);
				_oppQuoteCount = 0;
			}
			else
			{
				// count opposing quote events shortly after a price move
				if (_lastPriceMoveDir != 0 && (ev.Time - _lastPriceMoveTime).TotalMilliseconds <= RefillWindowMs)
				{
					if (type == EventType.LO1 || type == EventType.CA1)
					{
						// if quote event pushes against last move direction, count it
						if (ev.Eps * _lastPriceMoveDir < 0)
							_oppQuoteCount++;
					}
				}
			}

			// Baseline gap EWMA update on price-changing proxies
			if (ev.PriceChanged)
				UpdateBaselineGaps(type, Math.Abs(midChTicks));

			// Gap-flex states update always
			UpdateGapFlexStates(ev);

			_eventCounter++;
			int n = Math.Max(1, TrainEveryNEvents);
			if (_events.Count >= KernelLags + 1 && (_eventCounter % n) == 0)
			{
				double y = ev.MidChangeTicks;
				BuildFeatureVector_Train(_x);
				RlsUpdate(_x, y);
			}

			_prevMid = mid;
			if (DebugPrint)
				Print($"[EV] {ev.Time:HH:mm:ss.fff} {type} eps={ev.Eps} midCh={ev.MidChangeTicks:F2} sp={ev.SpreadTicks:F1} dn={ev.DeltaNorm:F3} imb={ev.ImbNear:F3} ofi={ev.OfiProxy:F3} pc={ev.PriceChanged} dR(MO/LO/CA)={_dR_MO:F2}/{_dR_LO:F2}/{_dR_CA:F2} oppQ={_oppQuoteCount} large={_isLargeTick}");
		}

		private void BuildFeatureVector_Train(double[] x)
		{
			Array.Clear(x, 0, x.Length);
			var node = _events.First;
			if (node == null) return;
			node = node.Next; // skip current event
			int lag = 1;
			while (node != null && lag <= KernelLags)
			{
				int et = (int)node.Value.Type;
				int s = node.Value.Eps;
				int idx = (lag - 1) * 6 + et;
				x[idx] = s;
				lag++;
				node = node.Next;
			}

			UpdateVolumetricFeaturesIfNeeded();
			int o = _baseDim;
			x[o + 0] = SpreadTicks();
			x[o + 1] = _vfDeltaNorm;
			x[o + 2] = _vfImbNear;
			x[o + 3] = _ofiProxy;
			x[o + 4] = _isLargeTick ? 1.0 : 0.0;
			x[o + 5] = BaselineWeight * ComputeBaselinePred();
			x[o + 6] = _stateFlow;
			x[o + 7] = _stateGap;
			x[o + 8] = _stateImb;
		}

		private void BuildFeatureVector_Predict(double[] x)
		{
			Array.Clear(x, 0, x.Length);
			var node = _events.First;
			int lag = 1;
			while (node != null && lag <= KernelLags)
			{
				int et = (int)node.Value.Type;
				int s = node.Value.Eps;
				int idx = (lag - 1) * 6 + et;
				x[idx] = s;
				lag++;
				node = node.Next;
			}

			UpdateVolumetricFeaturesIfNeeded();
			int o = _baseDim;
			x[o + 0] = SpreadTicks();
			x[o + 1] = _vfDeltaNorm;
			x[o + 2] = _vfImbNear;
			x[o + 3] = _ofiProxy;
			x[o + 4] = _isLargeTick ? 1.0 : 0.0;
			x[o + 5] = BaselineWeight * ComputeBaselinePred();
			x[o + 6] = _stateFlow;
			x[o + 7] = _stateGap;
			x[o + 8] = _stateImb;
		}

		private void RlsUpdate(double[] x, double y)
		{
			double lambda = Math.Max(0.90, Math.Min(0.9999, RlsLambda));
			for (int i = 0; i < _featDim; i++)
			{
				double s = 0.0;
				for (int j = 0; j < _featDim; j++)
					s += _P[i, j] * x[j];
				_Px[i] = s;
			}

			double xTPx = 0.0;
			for (int i = 0; i < _featDim; i++)
				xTPx += x[i] * _Px[i];

			double denom = lambda + xTPx;
			if (Math.Abs(denom) < 1e-12) return;

			for (int i = 0; i < _featDim; i++)
				_k[i] = _Px[i] / denom;

			double yhat = 0.0;
			for (int i = 0; i < _featDim; i++)
				yhat += _w[i] * x[i];

			double err = y - yhat;
			for (int i = 0; i < _featDim; i++)
				_w[i] += _k[i] * err;

			for (int i = 0; i < _featDim; i++)
				for (int j = 0; j < _featDim; j++)
					_P[i, j] = (_P[i, j] - _k[i] * _Px[j]) / lambda;
		}

		private double PredictNextTicks()
		{
			if (_events.Count < KernelLags) return 0.0;
			BuildFeatureVector_Predict(_x);
			double yhat = 0.0;
			for (int i = 0; i < _featDim; i++)
				yhat += _w[i] * _x[i];
			return yhat;
		}

		// ---------- Market data (L1) ----------
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e == null) return;

			// arrival-time proxy (PC clock) to estimate jitter/buffering
			DateTime arrive = Core.Globals.Now;
			bool isBA = (e.MarketDataType == MarketDataType.Bid || e.MarketDataType == MarketDataType.Ask);
			RecordMarketDataArrival(arrive, isBA);

			if (e.MarketDataType == MarketDataType.Bid)
			{
				double prevBid = _bestBid;
				_bestBid = e.Price;
				if (double.IsNaN(prevBid) || Math.Abs(prevBid - _bestBid) >= TickSize * 0.0001)
					_lastBidChangeLocalTime = arrive;
				if (UseQuoteEvents && !double.IsNaN(prevBid) && _bestBid > 0)
				{
					if (QuoteEventMinMs <= 0 || (Time[0] - _lastQuoteEventTime).TotalMilliseconds >= QuoteEventMinMs)
					{
						if (_bestBid > prevBid) EmitEvent(EventType.LO1, +1);
						else if (_bestBid < prevBid) EmitEvent(EventType.CA1, -1);
						_lastQuoteEventTime = Time[0];
					}
				}
				TryResolvePendingTrade();
				ValidateWorkingEntryOrder();
				ManageRiskState(false);
				return;
			}

			if (e.MarketDataType == MarketDataType.Ask)
			{
				double prevAsk = _bestAsk;
				_bestAsk = e.Price;
				if (double.IsNaN(prevAsk) || Math.Abs(prevAsk - _bestAsk) >= TickSize * 0.0001)
					_lastAskChangeLocalTime = arrive;
				if (UseQuoteEvents && !double.IsNaN(prevAsk) && _bestAsk > 0)
				{
					if (QuoteEventMinMs <= 0 || (Time[0] - _lastQuoteEventTime).TotalMilliseconds >= QuoteEventMinMs)
					{
						if (_bestAsk < prevAsk) EmitEvent(EventType.LO1, +1);
						else if (_bestAsk > prevAsk) EmitEvent(EventType.CA1, -1);
						_lastQuoteEventTime = Time[0];
					}
				}
				TryResolvePendingTrade();
				ManageRiskState(false);
				return;
			}

			if (e.MarketDataType != MarketDataType.Last)
				return;

			if (MinTradeSize > 1 && e.Volume < MinTradeSize)
				return;

			if (double.IsNaN(_bestBid) || double.IsNaN(_bestAsk) || _bestBid <= 0 || _bestAsk <= 0)
				return;

			double p = e.Price;
			int side;
			if (p >= _bestAsk) side = +1;
			else if (p <= _bestBid) side = -1;
			else
			{
				double db = Math.Abs(p - _bestBid);
				double da = Math.Abs(p - _bestAsk);
				side = (da <= db) ? +1 : -1;
			}

			_pendingTrade = true;
			_pendingTradeTime = Time[0];
			_pendingSide = side;
			_pendingMid = Mid();
			ValidateWorkingEntryOrder();
			ManageRiskState(false);
		}

		private void TryResolvePendingTrade()
		{
			if (!_pendingTrade) return;
			double dtms = (Time[0] - _pendingTradeTime).TotalMilliseconds;
			if (dtms < 0) return;

			if (dtms <= _pendingWindowMs)
			{
				double m = Mid();
				if (double.IsNaN(m) || double.IsNaN(_pendingMid)) return;
				bool moved = (_pendingSide == +1) ? (m > _pendingMid) : (m < _pendingMid);
				EmitEvent(moved ? EventType.MO1 : EventType.MO0, _pendingSide);
				_pendingTrade = false;
			}
			else if (dtms > _pendingWindowMs * 2)
			{
				EmitEvent(EventType.MO0, _pendingSide);
				_pendingTrade = false;
			}
		}

		// ---------- Entry gating: induced refill trap ----------
		private bool IsRefillTrap(int dir)
		{
			if (_lastPriceMoveDir == 0) return false;
			if ((Time[0] - _lastPriceMoveTime).TotalMilliseconds > RefillWindowMs) return false;

			if (dir == _lastPriceMoveDir && _oppQuoteCount >= RefillOpposingQuoteThreshold)
				return true;

			return false;
		}

		protected override void OnBarUpdate()
		{
			// Reset checks (run once per bar in OnEachTick mode)
			if (IsFirstTickOfBar)
			{
				// NEW: periodic reset has priority when enabled
				if (UsePeriodicReset)
					HandlePeriodicReset();
				else
					HandleDailyPreOpenReset();
			}

			if (CurrentBar < 5) return;
			ResetOvertradingGuardsForNewSessionIfNeeded();
			TryResolvePendingTrade();
			ManageRiskState(true);

			UpdateRegimeOnBar();
			UpdateActivityOnBar();

			if (!InTradeWindow(Time[0])) return;

			ValidateWorkingEntryOrder();

			if (Position.MarketPosition != MarketPosition.Flat)
			{
				ManageRiskState(true);
				return;
			}

			// Block new entries until risk exit state machine is fully cleared
			if (_riskExitState != RiskExitState.ARMED)
			{
				if (DebugPrint)
					Print(string.Format("[GATE] Entry blocked: RiskExitState={0}", _riskExitState));
				ManageRiskState(true);
				return;
			}

			ResetEntryRejectDiagnostics();
			if (IsBeforeNoTradeTime()) return;
			if (AtrStabilizationBlocks()) return;
			if (_events.Count < KernelLags) return;

			
double pred = PredictNextTicks();
_lastPred = pred;

int thrBase = _isLargeTick ? EntryThresholdTicksLarge : EntryThresholdTicksSmall;
int thr = Math.Max(EffectiveThreshold(thrBase), Math.Min(LongMinAbsPredTicks, ShortMinAbsPredTicks));
if (SpreadConvictionBlocks(SpreadTicks(), pred)) return;

if (MaxAbsPredictionTicks > 0 && Math.Abs(pred) > MaxAbsPredictionTicks)
{
	_confirmDir = 0;
	_confirmCount = 0;
	_confirmBurstEventCount = 0;
	_confirmStartTime = Core.Globals.MinDate;
	_confirmMarketStartTime = Core.Globals.MinDate;
	if (DebugPrint)
		Print($"[GATE] PredSanity blocked | pred={pred:F2} maxAbs={MaxAbsPredictionTicks} thr={thr} sp={SpreadTicks():F1}");
	return;
}

// Latency/jitter gate: block trading when feed is stale or jittery
if (LatencyGateBlocks(out string lr))
{
	if (DebugPrint)
		Print($"[GATE] Latency/Jitter blocked | {lr} | p95={_jitterP95Ms:F1}ms med={_jitterMedianMs:F1}ms effLat={_effectiveLatencyMs:F1}ms");
	return;
}

int dir = 0;
if (pred >= Math.Max(thr, LongMinAbsPredTicks)) dir = +1;
else if (pred <= -Math.Max(thr, ShortMinAbsPredTicks)) dir = -1;
else { _lastPredDir = 0; _lastEntryRejectedByLowConviction = true; return; }
if (dir == +1 && !EnableLongTrades) { _lastEntryRejectedByDirectionalFilter = true; return; }
if (dir == -1 && !EnableShortTrades) { _lastEntryRejectedByDirectionalFilter = true; return; }
_lastPredDir = dir;

// Require signal stability under jitter (multi-tick confirmation)
if (!ConfirmSignal(dir))
{
	if (DebugPrint)
		Print($"[GATE] ConfirmSignal waiting | dir={dir} pred={pred:F2} thr={thr} cnt={_confirmCount}/{ConfirmEvents} heldMs={_lastConfirmHeldMs:F0}/{_lastConfirmNeedMs:F0} eventOk={_lastConfirmEventOk} timeOk={_lastConfirmTimeOk} burstEvents={_confirmBurstEventCount} burstOverride={_lastConfirmBurstOverride}");
	return;
}
			if (IsRefillTrap(dir))
			{
				if (DebugPrint)
					Print($"[GATE] RefillTrap blocked dir={dir} pred={pred:F2} oppQ={_oppQuoteCount}");
				return;
			}
			if (!HasStableQuotes())
			{
				if (DebugPrint)
					Print("[GATE] Quote stability waiting");
				return;
			}
			if (OvertradingGateBlocks(out string ogReason))
			{
				if (DebugPrint)
					Print("[GATE] Overtrading blocked | " + ogReason);
				return;
			}

			EnterWithBracket(dir);
		}

		private void EnterWithBracket(int dir)
		{
			_entrySubmitLocalTime = Core.Globals.Now;
			_entryWorkingLocalTime = Core.Globals.MinDate;

			double bid = _bestBid;
			double ask = _bestAsk;
			if (double.IsNaN(bid) || double.IsNaN(ask) || bid <= 0 || ask <= 0)
				return;

			int qty = ComputeDynamicQuantity();
			_entrySignalSeq++;
			string signal = string.Format("{0}_{1}_{2}_{3}", EntrySignalPrefix, dir == +1 ? "LONG" : "SHORT", CurrentBar, _entrySignalSeq);
			_activeEntrySignal = signal;
			_catastrophicStopSignal = signal + "_CAT";
			_activeEntryDir = dir;
			_activeEntryAvgPrice = 0.0;
			_simulatedSL = 0.0;
			_lastCheckPrice = 0.0;
			_slTouched = false;
			_exitSubmitted = false;
			_exitRetryStage = 0;
			_slTouchedTime = Core.Globals.MinDate;
			_lastExitSubmitTime = Core.Globals.MinDate;
			_lastTrailUpdateTime = Core.Globals.MinDate;
			_catastrophicStopSubmitted = false;
			_catastrophicStopOrder = null;

			double midAtSubmit = 0.5 * (bid + ask);
			_entrySubmitLocalTime = Core.Globals.Now;
			_entrySubmitMarketTime = Time[0];
			_entrySubmitBar = CurrentBar;
			_entryDirAtSubmit = dir;
			_entryPredAtSubmit = _lastPred;
			_entryThresholdAtSubmit = EffectiveThreshold(_isLargeTick ? EntryThresholdTicksLarge : EntryThresholdTicksSmall);
			_entryBidAtSubmit = bid;
			_entryAskAtSubmit = ask;
			_entrySpreadAtSubmit = SpreadTicks();
			_lastEntrySubmitBar = CurrentBar;
			if (_lastEntrySubmitBarCounter != CurrentBar)
			{
				_lastEntrySubmitBarCounter = CurrentBar;
				_entrySubmitsThisBar = 0;
			}
			_entrySubmitsThisBar++;
			if (UseLimitEntries && !UseMarketEntriesForDiagnostics)
			{
				double px = (dir == +1) ? (bid - EffectiveLimitOffsetTicks(LimitOffsetTicks) * TickSize) : (ask + EffectiveLimitOffsetTicks(LimitOffsetTicks) * TickSize);
				px = Math.Round(px / TickSize) * TickSize;
				double midDevTicks = Math.Abs(px - midAtSubmit) / TickSize;
				if (midDevTicks > Math.Max(1, MaxEntryMidDeviationTicks))
				{
					if (DebugPrint) Print("[GATE] Entry limit too far from current mid | devTicks=" + midDevTicks.ToString("F1"));
					ResetEntrySubmitSnapshot();
					return;
				}
				_entryLimitPx = px;
				if (dir == +1)
					EnterLongLimit(qty, px, signal);
				else
					EnterShortLimit(qty, px, signal);
			}
			else
			{
				_entryLimitPx = 0;
				if (dir == +1) EnterLong(qty, signal);
				else EnterShort(qty, signal);
			}
		}

		private double CalculateOneRTicksAtEntry()
		{
			double atrTicks = StopTicks;
			if (UseAtrDynamicRisk && _atr != null && TickSize > 0 && CurrentBar >= Math.Max(2, AtrPeriod) && _atr[0] > 0)
				atrTicks = _atr[0] / TickSize;
			double mult = VolatilityMultiplier; int minR = MinOneRTicks; int maxR = MaxOneRTicks;
			if (OneRCalibrationMode == OneRMode.Conservative) { mult = 0.60; minR = 10; maxR = 28; }
			else if (OneRCalibrationMode == OneRMode.Balanced) { mult = 0.45; minR = 8; maxR = 20; }
			else if (OneRCalibrationMode == OneRMode.Aggressive) { mult = 0.35; minR = 6; maxR = 18; }
			_atrTicksAtEntry = atrTicks;
			_rawOneRTicksAtEntry = Math.Round(atrTicks * mult);
			double clamped = Math.Max(Math.Max(1, minR), Math.Min(Math.Max(minR, maxR), _rawOneRTicksAtEntry));
			_oneRWasClamped = Math.Abs(clamped - _rawOneRTicksAtEntry) > 0.0001;
			return Math.Max(1.0, clamped);
		}

		private double CurrentOneRTicks()
		{
			return _currentOneR_Ticks > 0 ? _currentOneR_Ticks : Math.Max(1, StopTicks);
		}

		private void InitializeTradeRiskAtEntry(double fillPrice, DateTime fillTime)
		{
			_currentOneR_Ticks = CalculateOneRTicksAtEntry();
			_currentTradeState = TradeState.Phase1_BreathingRoom;
			_activeEntryFillTime = fillTime;
			_activeEntryFillCoreTime = Core.Globals.Now;
			_lastEarlyFailureHeldMs = 0.0; _lastEarlyFailureMfeR = 0.0; _lastEarlyFailureMaeR = 0.0;
			_softStopActive = false;
			_softStopFirstTouchCoreTime = Core.Globals.MinDate;
			_softStopTouchEvents = 0;
			_softStopMaxBreachTicks = 0.0;
			_softStopLastSource = string.Empty;
			_tradeHighestHigh = fillPrice; _tradeLowestLow = fillPrice;
			_profitTargetSubmitted = false; _profitTargetSignal = string.Empty;
			if (_activeEntryDir >= 0) _simulatedSL = Math.Round((fillPrice - _currentOneR_Ticks * TickSize) / TickSize) * TickSize;
			else _simulatedSL = Math.Round((fillPrice + _currentOneR_Ticks * TickSize) / TickSize) * TickSize;
			SubmitProfitTargetLimitIfNeeded(fillPrice);
		}

		private void SubmitProfitTargetLimitIfNeeded(double avg)
		{
			if (!UseProfitTargetLimit || _profitTargetSubmitted || Position == null || Position.MarketPosition == MarketPosition.Flat || TickSize <= 0) return;
			int qty = Math.Abs(Position.Quantity); if (qty <= 0 || string.IsNullOrEmpty(_activeEntrySignal)) return;
			double ticks = CurrentOneRTicks() * Math.Max(1.0, ProfitTarget_R);
			_profitTargetSignal = string.Format("{0}_TARGET_{1}", EntrySignalPrefix, CurrentBar);
			if (Position.MarketPosition == MarketPosition.Long) ExitLongLimit(qty, Math.Round((avg + ticks * TickSize) / TickSize) * TickSize, _profitTargetSignal, _activeEntrySignal);
			else if (Position.MarketPosition == MarketPosition.Short) ExitShortLimit(qty, Math.Round((avg - ticks * TickSize) / TickSize) * TickSize, _profitTargetSignal, _activeEntrySignal);
			_profitTargetSubmitted = true;
		}

		private void EnsureSimulatedSL()
		{
			if (Position == null || Position.MarketPosition == MarketPosition.Flat || TickSize <= 0) return;
			double avg = Position.AveragePrice > 0 ? Position.AveragePrice : _activeEntryAvgPrice;
			if (avg <= 0) return;
			if (_activeEntryAvgPrice <= 0) _activeEntryAvgPrice = avg;
			if (_currentOneR_Ticks <= 0) _currentOneR_Ticks = CalculateOneRTicksAtEntry();
			if (_currentTradeState == TradeState.Flat) _currentTradeState = TradeState.Phase1_BreathingRoom;
			if (_simulatedSL <= 0)
			{
				double r = CurrentOneRTicks();
				if (Position.MarketPosition == MarketPosition.Long) _simulatedSL = Math.Round((avg - r * TickSize) / TickSize) * TickSize;
				else if (Position.MarketPosition == MarketPosition.Short) _simulatedSL = Math.Round((avg + r * TickSize) / TickSize) * TickSize;
			}
		}

		private void UpdateSimulatedTrailingSL()
		{
			if (Position == null || Position.MarketPosition == MarketPosition.Flat || TickSize <= 0) return;
			EnsureSimulatedSL(); if (_simulatedSL <= 0) return;
			DateTime now = Core.Globals.Now;
			if (_lastTrailUpdateTime != Core.Globals.MinDate && (now - _lastTrailUpdateTime).TotalMilliseconds < Math.Max(0, TrailUpdateMinMs)) return;
			double bid = _bestBid, ask = _bestAsk;
			if (double.IsNaN(bid) || double.IsNaN(ask) || bid <= 0 || ask <= 0) return;
			double avg = Position.AveragePrice > 0 ? Position.AveragePrice : _activeEntryAvgPrice;
			if (avg <= 0) return;
			double oneR = CurrentOneRTicks();
			// v7_4: after the controlled soft-hold window, do not keep a non-profitable trade alive blindly.
			if (UseControlledSoftStopHold && ExitIfNotProfitableAfterMinHold && _activeEntryFillCoreTime != Core.Globals.MinDate)
			{
				double heldMsReview = CurrentHeldMsCore();
				double openPnLTicks = CurrentOpenPnLTicks();
				if (heldMsReview >= Math.Max(0, MinHoldMsBeforeSoftSLExit) && openPnLTicks <= MinProfitTicksAfterMinHold)
				{
					_lastTouchSource = "TIME_REVIEW_NOT_PROFIT";
					TransitionRiskState(RiskExitState.SL_TOUCHED, "TIME_REVIEW_NOT_PROFIT");
					return;
				}
				if (HardMaxHoldMs > 0 && heldMsReview >= HardMaxHoldMs && openPnLTicks <= MinProfitTicksAfterMinHold)
				{
					_lastTouchSource = "HARD_MAX_HOLD_NOT_PROFIT";
					TransitionRiskState(RiskExitState.SL_TOUCHED, "HARD_MAX_HOLD_NOT_PROFIT");
					return;
				}
			}

			int safety = Math.Max(1, StopMarketSafetyTicks);
			int lookback = Math.Max(1, Math.Min(StructuralLookbackBars, CurrentBar));

			if (UseEarlyFailureExit && _csvTradeActive && _activeEntryFillCoreTime != Core.Globals.MinDate && !IsWithinControlledSoftHoldWindow())
			{
				double heldMs = (Core.Globals.Now - _activeEntryFillCoreTime).TotalMilliseconds;
				double mfeR = _csvMaxFavorableTicks / Math.Max(1.0, oneR);
				double maeR = _csvMaxAdverseTicks / Math.Max(1.0, oneR);
				_lastEarlyFailureHeldMs = heldMs; _lastEarlyFailureMfeR = mfeR; _lastEarlyFailureMaeR = maeR;
				if (heldMs >= Math.Max(0, EarlyFailureMinHoldMs) && mfeR < EarlyFailureMinMfe_R && mfeR < 0.50 && maeR <= -Math.Abs(EarlyFailureMaxAdverse_R))
				{
					_lastTouchSource = "EARLY_FAILURE";
					TransitionRiskState(RiskExitState.SL_TOUCHED, "EARLY_FAILURE");
					return;
				}
			}

			if (Position.MarketPosition == MarketPosition.Long)
			{
				_tradeHighestHigh = double.IsNaN(_tradeHighestHigh) ? High[0] : Math.Max(_tradeHighestHigh, Math.Max(High[0], bid));
				double currentR = ((bid - avg) / TickSize) / Math.Max(1.0, oneR);
				double desired = _simulatedSL;
				switch (_currentTradeState)
				{
					case TradeState.Phase1_BreathingRoom:
						if (currentR >= FreeTradeActivation_R) { _currentTradeState = TradeState.Phase2_RiskFree; desired = Math.Max(desired, avg + FreeTradeOffsetTicks * TickSize); }
						break;
					case TradeState.Phase2_RiskFree:
						desired = Math.Max(desired, avg + FreeTradeOffsetTicks * TickSize);
						if (currentR >= TrailingActivation_R) _currentTradeState = TradeState.Phase3_TrendCapture;
						break;
					case TradeState.Phase3_TrendCapture:
						desired = Math.Max(desired, avg + FreeTradeOffsetTicks * TickSize);
						double minLow = Low[0]; for (int i=0;i<lookback;i++) minLow = Math.Min(minLow, Low[i]);
						double structural = minLow - StructuralOffsetTicks * TickSize;
						double chandelier = (_atr != null && UseChandelierTrailing) ? _tradeHighestHigh - ChandelierAtrMultiplier * _atr[0] : structural;
						desired = Math.Max(desired, UseStructuralTrailing ? Math.Min(structural, chandelier) : chandelier);
						break;
				}
				desired = Math.Round(Math.Min(desired, bid - safety * TickSize) / TickSize) * TickSize;
				if (desired > _simulatedSL && desired < bid) { _simulatedSL = desired; _lastTrailUpdateTime = now; CsvOnTrailMoved(_simulatedSL); }
			}
			else if (Position.MarketPosition == MarketPosition.Short)
			{
				_tradeLowestLow = double.IsNaN(_tradeLowestLow) ? Low[0] : Math.Min(_tradeLowestLow, Math.Min(Low[0], ask));
				double currentR = ((avg - ask) / TickSize) / Math.Max(1.0, oneR);
				double desired = _simulatedSL;
				switch (_currentTradeState)
				{
					case TradeState.Phase1_BreathingRoom:
						if (currentR >= FreeTradeActivation_R) { _currentTradeState = TradeState.Phase2_RiskFree; desired = Math.Min(desired, avg - FreeTradeOffsetTicks * TickSize); }
						break;
					case TradeState.Phase2_RiskFree:
						desired = Math.Min(desired, avg - FreeTradeOffsetTicks * TickSize);
						if (currentR >= TrailingActivation_R) _currentTradeState = TradeState.Phase3_TrendCapture;
						break;
					case TradeState.Phase3_TrendCapture:
						desired = Math.Min(desired, avg - FreeTradeOffsetTicks * TickSize);
						double maxHigh = High[0]; for (int i=0;i<lookback;i++) maxHigh = Math.Max(maxHigh, High[i]);
						double structural = maxHigh + StructuralOffsetTicks * TickSize;
						double chandelier = (_atr != null && UseChandelierTrailing) ? _tradeLowestLow + ChandelierAtrMultiplier * _atr[0] : structural;
						desired = Math.Min(desired, UseStructuralTrailing ? Math.Max(structural, chandelier) : chandelier);
						break;
				}
				desired = Math.Round(Math.Max(desired, ask + safety * TickSize) / TickSize) * TickSize;
				if (desired < _simulatedSL && desired > ask) { _simulatedSL = desired; _lastTrailUpdateTime = now; CsvOnTrailMoved(_simulatedSL); }
			}
		}

		private void SubmitCatastrophicHardStopIfNeeded()
		{
			if (_catastrophicStopSubmitted || CatastrophicStopTicks <= 0 || Position == null || Position.MarketPosition == MarketPosition.Flat || TickSize <= 0)
				return;
			if (string.IsNullOrEmpty(_activeEntrySignal))
				return;

			int qty = Math.Abs(Position.Quantity);
			if (qty <= 0)
				return;

			double avg = Position.AveragePrice > 0 ? Position.AveragePrice : _activeEntryAvgPrice;
			if (avg <= 0)
				return;

			double stopPx;
			if (Position.MarketPosition == MarketPosition.Long)
			{
				stopPx = Math.Round((avg - CatastrophicStopTicks * TickSize) / TickSize) * TickSize;
				ExitLongStopMarket(qty, stopPx, _catastrophicStopSignal, _activeEntrySignal);
			}
			else if (Position.MarketPosition == MarketPosition.Short)
			{
				stopPx = Math.Round((avg + CatastrophicStopTicks * TickSize) / TickSize) * TickSize;
				ExitShortStopMarket(qty, stopPx, _catastrophicStopSignal, _activeEntrySignal);
			}
			_catastrophicStopSubmitted = true;
		}

		
		private double CurrentOpenPnLTicks()
		{
			if (Position == null || Position.MarketPosition == MarketPosition.Flat || TickSize <= 0)
				return 0.0;
			double avg = Position.AveragePrice > 0 ? Position.AveragePrice : _activeEntryAvgPrice;
			if (avg <= 0) return 0.0;
			double mark = Position.MarketPosition == MarketPosition.Long
				? ((!double.IsNaN(_bestBid) && _bestBid > 0) ? _bestBid : Close[0])
				: ((!double.IsNaN(_bestAsk) && _bestAsk > 0) ? _bestAsk : Close[0]);
			return Position.MarketPosition == MarketPosition.Long ? (mark - avg) / TickSize : (avg - mark) / TickSize;
		}

		private double CurrentHeldMsCore()
		{
			if (_activeEntryFillCoreTime == Core.Globals.MinDate)
				return 0.0;
			double heldMs = (Core.Globals.Now - _activeEntryFillCoreTime).TotalMilliseconds;
			return Math.Max(0.0, heldMs);
		}

		private bool IsWithinControlledSoftHoldWindow()
		{
			return UseControlledSoftStopHold
				&& MinHoldMsBeforeSoftSLExit > 0
				&& _activeEntryFillCoreTime != Core.Globals.MinDate
				&& CurrentHeldMsCore() < Math.Max(0, MinHoldMsBeforeSoftSLExit);
		}

		private bool ConfirmControlledSoftStopTouch(double breachTicks, string touchSource, bool isBidAskCross)
		{
			if (!IsWithinControlledSoftHoldWindow())
				return true;

			breachTicks = Math.Max(0.0, breachTicks);
			bool isPostEntry = touchSource == "POST_ENTRY_LOW" || touchSource == "POST_ENTRY_HIGH";

			if (isPostEntry && IgnorePostEntrySoftStopUntilMinHold)
			{
				int postHard = Math.Max(0, PostEntrySoftHardBreachTicks);
				if (postHard > 0 && breachTicks >= postHard)
				{
					_lastTouchSource = touchSource + "_POST_HARD_CONFIRMED";
					return true;
				}

				DateTime nowPost = Core.Globals.Now;
				if (!_softStopActive || _softStopLastSource != touchSource)
				{
					_softStopActive = true;
					_softStopFirstTouchCoreTime = nowPost;
					_softStopTouchEvents = 0;
					_softStopMaxBreachTicks = 0.0;
					_softStopLastSource = touchSource;
				}
				_softStopTouchEvents++;
				_softStopMaxBreachTicks = Math.Max(_softStopMaxBreachTicks, breachTicks);
				_lastTouchSource = touchSource + "_DELAYED_UNTIL_MIN_HOLD";
				if (DebugPrint)
					Print(string.Format("[V7_4_POST_ENTRY_DELAY] source={0} breach={1:F1}/{2} events={3} heldMs={4:F0}/{5}",
						touchSource, breachTicks, postHard, _softStopTouchEvents, CurrentHeldMsCore(), MinHoldMsBeforeSoftSLExit));
				return false;
			}

			int bidAskHard = Math.Max(0, BidAskHardBreachTicks > 0 ? BidAskHardBreachTicks : InitialStopMaxBreachTicks);
			if (isBidAskCross && DoNotIgnoreBidAskCrossBreach && bidAskHard > 0 && breachTicks >= bidAskHard)
			{
				_lastTouchSource = touchSource + "_BREACH_CONFIRMED";
				return true;
			}

			DateTime now = Core.Globals.Now;
			if (!_softStopActive || _softStopLastSource != touchSource)
			{
				_softStopActive = true;
				_softStopFirstTouchCoreTime = now;
				_softStopTouchEvents = 0;
				_softStopMaxBreachTicks = 0.0;
				_softStopLastSource = touchSource;
			}

			_softStopTouchEvents++;
			_softStopMaxBreachTicks = Math.Max(_softStopMaxBreachTicks, breachTicks);
			double confirmMs = (_softStopFirstTouchCoreTime == Core.Globals.MinDate) ? 0.0 : (now - _softStopFirstTouchCoreTime).TotalMilliseconds;
			bool timeOk = confirmMs >= Math.Max(0, SoftStopConfirmMs);
			bool eventsOk = _softStopTouchEvents >= Math.Max(1, SoftStopConfirmEvents);
			if (timeOk && eventsOk)
			{
				_lastTouchSource = touchSource + "_SOFT_CONFIRMED";
				return true;
			}

			if (DebugPrint)
				Print(string.Format("[V7_4_SOFT_HOLD] delay source={0} bidAsk={1} breach={2:F1} bidAskHard={3} events={4}/{5} confirmMs={6:F0}/{7} heldMs={8:F0}/{9}",
					touchSource, isBidAskCross, breachTicks, bidAskHard, _softStopTouchEvents, SoftStopConfirmEvents, confirmMs, SoftStopConfirmMs, CurrentHeldMsCore(), MinHoldMsBeforeSoftSLExit));
			return false;
		}

private bool IsSimulatedSLTouched(bool useOhlc)
		{
			if (_simulatedSL <= 0 || Position == null || Position.MarketPosition == MarketPosition.Flat)
				return false;

			bool hasBid = !double.IsNaN(_bestBid) && _bestBid > 0;
			bool hasAsk = !double.IsNaN(_bestAsk) && _bestAsk > 0;
			bool ohlcAllowed = useOhlc && (_activeEntryBar < 0 || CurrentBar > _activeEntryBar);
			bool skipEntryBarPostExtremum = IgnoreEntryBarPostExtremumForSL && _activeEntryBar >= 0 && CurrentBar == _activeEntryBar;

			bool touched = false;
			double breachTicks = 0.0;
			string source = string.Empty;
			bool isBidAskCross = false;

			if (Position.MarketPosition == MarketPosition.Long)
			{
				if (!skipEntryBarPostExtremum && !double.IsNaN(_postEntryLow) && _postEntryLow <= _simulatedSL)
				{
					touched = true;
					source = "POST_ENTRY_LOW";
					breachTicks = (_simulatedSL - _postEntryLow) / TickSize;
				}
				else if (hasBid && _bestBid <= _simulatedSL)
				{
					touched = true;
					source = "BID_CROSS";
					isBidAskCross = true;
					breachTicks = (_simulatedSL - _bestBid) / TickSize;
				}
				else if (!hasBid && ohlcAllowed && Low[0] <= _simulatedSL)
				{
					touched = true;
					source = "OHLC_LOW_NO_BID";
					breachTicks = (_simulatedSL - Low[0]) / TickSize;
				}
				else if (!hasBid && Close[0] <= _simulatedSL)
				{
					touched = true;
					source = "CLOSE_CROSS_NO_BID";
					breachTicks = (_simulatedSL - Close[0]) / TickSize;
				}
			}
			else if (Position.MarketPosition == MarketPosition.Short)
			{
				if (!skipEntryBarPostExtremum && !double.IsNaN(_postEntryHigh) && _postEntryHigh >= _simulatedSL)
				{
					touched = true;
					source = "POST_ENTRY_HIGH";
					breachTicks = (_postEntryHigh - _simulatedSL) / TickSize;
				}
				else if (hasAsk && _bestAsk >= _simulatedSL)
				{
					touched = true;
					source = "ASK_CROSS";
					isBidAskCross = true;
					breachTicks = (_bestAsk - _simulatedSL) / TickSize;
				}
				else if (!hasAsk && ohlcAllowed && High[0] >= _simulatedSL)
				{
					touched = true;
					source = "OHLC_HIGH_NO_ASK";
					breachTicks = (High[0] - _simulatedSL) / TickSize;
				}
				else if (!hasAsk && Close[0] >= _simulatedSL)
				{
					touched = true;
					source = "CLOSE_CROSS_NO_ASK";
					breachTicks = (Close[0] - _simulatedSL) / TickSize;
				}
			}

			if (!touched)
			{
				_softStopActive = false;
				_softStopFirstTouchCoreTime = Core.Globals.MinDate;
				_softStopTouchEvents = 0;
				_softStopMaxBreachTicks = 0.0;
				_softStopLastSource = string.Empty;
				return false;
			}

			_lastTouchSource = source;
			return ConfirmControlledSoftStopTouch(breachTicks, source, isBidAskCross);
		}

		// ============================================================
		// RISK EXIT STATE MACHINE - replaces old managed-only exit
		// ============================================================

		private void TransitionRiskState(RiskExitState newState, string reason)
		{
			if (_riskExitState == newState) return;
			RiskTrace(string.Format("STATE_TRANSITION_{0}_TO_{1}_{2}", _riskExitState, newState, reason), true);
			_riskExitState = newState;
			_riskStateEnteredTime = Core.Globals.Now;
		}

		/// <summary>
		/// Submits an unmanaged market order to exit all current position.
		/// Unmanaged orders bypass managed signal binding completely.
		/// Returns true if submit was attempted.
		/// </summary>
		private bool SubmitUnmanagedExitMarket(string reason)
		{
			if (Position == null || Position.MarketPosition == MarketPosition.Flat)
				return false;

			DateTime now = Core.Globals.Now;
			// Rate-limit: no spamming within ForceExitRetryMs
			if (_lastUnmanagedExitTime != Core.Globals.MinDate &&
				(now - _lastUnmanagedExitTime).TotalMilliseconds < Math.Max(100, ForceExitRetryMs))
				return false;

			int qty = Math.Abs(Position.Quantity);
			if (qty <= 0) return false;

			_unmanagedExitSeq++;
			_unmanagedExitAttempts++;
			_lastUnmanagedExitTime = now;
			_lastExitReason = reason;

			string orderName = string.Format("{0}_UMX_{1}_{2}", EntrySignalPrefix, reason, _unmanagedExitSeq);
			_unmanagedExitOrderName = orderName;

			RiskTrace("UNMANAGED_EXIT_SUBMIT_BEGIN_" + reason + "_seq=" + _unmanagedExitSeq, true);

			try
			{
				// SubmitOrderUnmanaged: not tied to managed position tracking.
				// This is the most reliable way to flatten without strategy-disable risk.
				Order o;
				if (Position.MarketPosition == MarketPosition.Long)
					o = SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, qty, 0, 0, string.Empty, orderName);
				else
					o = SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Market, qty, 0, 0, string.Empty, orderName);

				_unmanagedExitOrder = o;
				RiskTrace("UNMANAGED_EXIT_SUBMIT_OK_" + reason + "_seq=" + _unmanagedExitSeq, true);
				return true;
			}
			catch (Exception ex)
			{
				RiskTrace("UNMANAGED_EXIT_EXCEPTION_" + ex.GetType().Name + "_" + reason, true);
				// Fallback: try managed exit without fromEntrySignal binding
				try
				{
					string fbSig = string.Format("{0}_UMX_FB_{1}_{2}", EntrySignalPrefix, reason, _unmanagedExitSeq);
					if (Position.MarketPosition == MarketPosition.Long)
						ExitLong(qty, fbSig, string.Empty);
					else
						ExitShort(qty, fbSig, string.Empty);
					RiskTrace("UNMANAGED_EXIT_FALLBACK_MANAGED_OK_" + reason, true);
					return true;
				}
				catch (Exception ex2)
				{
					RiskTrace("UNMANAGED_EXIT_FALLBACK_EXCEPTION_" + ex2.GetType().Name, true);
					return false;
				}
			}
		}

		/// <summary>
		/// Submits managed exit — used as first attempt (may fail due to signal binding).
		/// </summary>
		private void SubmitExitMarketFallback(string reason)
		{
			if (Position == null || Position.MarketPosition == MarketPosition.Flat)
				return;

			int qty = Math.Abs(Position.Quantity);
			if (qty <= 0) return;

			_lastExitReason = reason;
			string sig = string.Format("{0}_EXIT_{1}_{2}_{3}", EntrySignalPrefix, reason, CurrentBar, _exitRetryStage);
			RiskTrace("MANAGED_EXIT_SUBMIT_BEGIN_" + reason, true);

			try
			{
				if (Position.MarketPosition == MarketPosition.Long)
				{
					if (_exitRetryStage == 0 && !string.IsNullOrEmpty(_activeEntrySignal))
						ExitLong(qty, sig, _activeEntrySignal);
					else
						ExitLong(qty, sig, string.Empty);
				}
				else if (Position.MarketPosition == MarketPosition.Short)
				{
					if (_exitRetryStage == 0 && !string.IsNullOrEmpty(_activeEntrySignal))
						ExitShort(qty, sig, _activeEntrySignal);
					else
						ExitShort(qty, sig, string.Empty);
				}
				_exitSubmitted = true;
				_lastExitSubmitTime = Core.Globals.Now;
				RiskTrace("MANAGED_EXIT_SUBMIT_OK_" + reason, true);
			}
			catch (Exception ex)
			{
				RiskTrace("MANAGED_EXIT_EXCEPTION_" + ex.GetType().Name + "_" + reason, true);
				// Even if managed fails, flag so watchdog escalates
				_exitSubmitted = true;
				_lastExitSubmitTime = Core.Globals.Now;
			}
		}

		private void SubmitAccountFlattenEmergency(string reason)
		{
			if (!UseAccountFlattenEmergency)
				return;
			if (Position == null || Position.MarketPosition == MarketPosition.Flat)
				return;
			if (Account == null || Instrument == null)
				return;

			DateTime now = Core.Globals.Now;
			if (_lastAccountFlattenTime != Core.Globals.MinDate &&
				(now - _lastAccountFlattenTime).TotalMilliseconds < Math.Max(250, AccountFlattenRetryMs))
				return;

			_lastExitReason = reason;
			_lastAccountFlattenTime = now;
			_accountFlattenAttempted = true;
			RiskTrace("ACCOUNT_FLATTEN_BEGIN_" + reason, true);

			try
			{
				Account.Flatten(new[] { Instrument });
				RiskTrace("ACCOUNT_FLATTEN_OK_" + reason, true);
			}
			catch (Exception ex)
			{
				RiskTrace("ACCOUNT_FLATTEN_EXCEPTION_" + ex.GetType().Name, true);
			}
		}

		// Legacy — kept for compatibility but no longer primary path
		private void SubmitPersistentForceExit(string reason)
		{
			// Delegate to unmanaged exit which is more reliable
			SubmitUnmanagedExitMarket(reason);
		}

		private void RunExitWatchdog()
		{
			// Now driven by state machine — this method is no longer the primary driver
			// but kept for backward compat with call sites in ManageRiskState
		}

		private void ManageRiskState(bool useOhlcFallback)
		{
			// ----------------------------------------------------------
			// FLAT: confirm or reset state
			// ----------------------------------------------------------
			if (Position == null || Position.MarketPosition == MarketPosition.Flat)
			{
				if (_riskExitState != RiskExitState.ARMED && _riskExitState != RiskExitState.FLAT_CONFIRMED)
				{
					RiskTrace("POSITION_NOW_FLAT_CONFIRMING", true);
					TransitionRiskState(RiskExitState.FLAT_CONFIRMED, "POSITION_FLAT");
				}

				if (_exitSubmitted || _slTouched || _simulatedSL > 0 ||
					_riskExitState == RiskExitState.FLAT_CONFIRMED)
				{
					_simulatedSL = 0.0;
					_lastCheckPrice = 0.0;
					_slTouched = false;
					_exitSubmitted = false;
					_exitRetryStage = 0;
					_slTouchedTime = Core.Globals.MinDate;
					_lastExitSubmitTime = Core.Globals.MinDate;
					_lastTrailUpdateTime = Core.Globals.MinDate;
					_activeEntryAvgPrice = 0.0;
					_catastrophicStopSubmitted = false;
					_persistentForceExitAttempts = 0;
					_unmanagedExitAttempts = 0;
					_unmanagedExitOrder = null;
					_unmanagedExitOrderName = string.Empty;
					_accountFlattenAttempted = false;
					_lastAccountFlattenTime = Core.Globals.MinDate;
					// Post-entry extremum reset
					_activeEntryBar  = -1;
					_activeEntryTime = Core.Globals.MinDate;
					_postEntryLow    = double.NaN;
					_postEntryHigh   = double.NaN;
					_lastTouchSource = string.Empty;
					_softStopActive = false;
					_softStopFirstTouchCoreTime = Core.Globals.MinDate;
					_softStopTouchEvents = 0;
					_softStopMaxBreachTicks = 0.0;
					_softStopLastSource = string.Empty;
					_currentTradeState = TradeState.Flat; _currentOneR_Ticks = 0.0;
					_activeEntryFillTime = Core.Globals.MinDate; _activeEntryFillCoreTime = Core.Globals.MinDate;
					_tradeHighestHigh = double.NaN; _tradeLowestLow = double.NaN;
					_profitTargetSubmitted = false; _profitTargetSignal = string.Empty;
					// Transition back to ARMED only after confirmed flat
					_riskExitState = RiskExitState.ARMED;
					_riskStateEnteredTime = Core.Globals.MinDate;
				}
				return;
			}

			// ----------------------------------------------------------
			// IN POSITION: standard risk management
			// ----------------------------------------------------------
			EnsureSimulatedSL();
			SubmitCatastrophicHardStopIfNeeded();
			UpdateSimulatedTrailingSL();

			_lastCheckPrice = Position.MarketPosition == MarketPosition.Long
				? (!double.IsNaN(_bestBid) && _bestBid > 0 ? _bestBid : Close[0])
				: (!double.IsNaN(_bestAsk) && _bestAsk > 0 ? _bestAsk : Close[0]);
			CsvUpdateLiveTracking();

			// ----------------------------------------------------------
			// Update post-entry price extrema (tick-by-tick)
			// ----------------------------------------------------------
			if (_activeEntryBar >= 0)
			{
				if (Position.MarketPosition == MarketPosition.Long)
				{
					// Track how low the bid (check price) has gone since entry
					double chkLow = (!double.IsNaN(_bestBid) && _bestBid > 0) ? _bestBid : Close[0];
					if (double.IsNaN(_postEntryLow) || chkLow < _postEntryLow)
						_postEntryLow = chkLow;
				}
				else if (Position.MarketPosition == MarketPosition.Short)
				{
					// Track how high the ask (check price) has gone since entry
					double chkHigh = (!double.IsNaN(_bestAsk) && _bestAsk > 0) ? _bestAsk : Close[0];
					if (double.IsNaN(_postEntryHigh) || chkHigh > _postEntryHigh)
						_postEntryHigh = chkHigh;
				}
			}

			// ----------------------------------------------------------
			// STATE MACHINE
			// ----------------------------------------------------------
			DateTime now = Core.Globals.Now;

			switch (_riskExitState)
			{
				case RiskExitState.ARMED:
					if (!_slTouched && IsSimulatedSLTouched(useOhlcFallback))
					{
						_slTouched = true;
						_slTouchedTime = now;
						_exitRetryStage = 0;
						TransitionRiskState(RiskExitState.SL_TOUCHED, "SL_HIT");
						RiskTrace("SL_TOUCHED_FIRST_DETECTION", true);
					}
					break;

				case RiskExitState.SL_TOUCHED:
					// Immediately submit managed exit as first attempt
					SubmitExitMarketFallback("SLTOUCH");
					_exitSubmitted = true;
					_lastExitSubmitTime = now;
					TransitionRiskState(RiskExitState.EXIT_SUBMITTED, "MANAGED_EXIT_SENT");
					break;

				case RiskExitState.EXIT_SUBMITTED:
				{
					double elapsedMs = _riskStateEnteredTime == Core.Globals.MinDate ? 0.0
						: (now - _riskStateEnteredTime).TotalMilliseconds;

					if (elapsedMs >= Math.Max(100, ExitRetryMs))
					{
						RiskTrace("EXIT_NOT_FILLED_ESCALATING_TO_RETRY", true);
						_exitRetryStage = 1;
						SubmitExitMarketFallback("RETRY");
						TransitionRiskState(RiskExitState.RETRY_PENDING, "RETRY_AFTER_MS_" + elapsedMs.ToString("F0"));
					}
					break;
				}

				case RiskExitState.RETRY_PENDING:
				{
					double elapsedMs = _slTouchedTime == Core.Globals.MinDate ? 0.0
						: (now - _slTouchedTime).TotalMilliseconds;

					if (elapsedMs >= Math.Max(500, EmergencyExitMs))
					{
						RiskTrace("RETRY_NOT_FILLED_ESCALATING_TO_UNMANAGED_EMERGENCY", true);
						_exitRetryStage = 2;
						// First try: unmanaged market order — bypasses signal binding
						bool sent = SubmitUnmanagedExitMarket("EMERGENCY");
						if (!sent)
							SubmitExitMarketFallback("EMERGENCY_MANAGED");
						TransitionRiskState(RiskExitState.EMERGENCY_PENDING, "UNMANAGED_EMERGENCY_SENT_MS_" + elapsedMs.ToString("F0"));
					}
					break;
				}

				case RiskExitState.EMERGENCY_PENDING:
				{
					double elapsedMs = _riskStateEnteredTime == Core.Globals.MinDate ? 0.0
						: (now - _riskStateEnteredTime).TotalMilliseconds;

					// Keep retrying unmanaged exit with rate-limiting
					bool sent = SubmitUnmanagedExitMarket("PERSISTENT_FORCE");
					_persistentForceExitAttempts++;

					if (_unmanagedExitAttempts > Math.Max(1, ForceExitBeforeAccountFlattenAttempts))
					{
						// Last resort: Account.Flatten (optional, disabled by default)
						SubmitAccountFlattenEmergency("LAST_RESORT_AFTER_UNMANAGED_FAILED");
						// Mark as failed-but-running so we don't block forever
						if (_unmanagedExitAttempts > ForceExitBeforeAccountFlattenAttempts + 3)
						{
							RiskTrace("EMERGENCY_MAX_ATTEMPTS_STRATEGY_CONTINUES", true);
							TransitionRiskState(RiskExitState.FAILED_BUT_STRATEGY_STILL_RUNNING,
								"MAX_EXIT_ATTEMPTS_" + _unmanagedExitAttempts);
						}
					}
					break;
				}

				case RiskExitState.FAILED_BUT_STRATEGY_STILL_RUNNING:
				{
					// Strategy is NOT disabled. Keep trying unmanaged exit slowly.
					double elapsedMs = _riskStateEnteredTime == Core.Globals.MinDate ? 0.0
						: (now - _riskStateEnteredTime).TotalMilliseconds;

					if (elapsedMs > 3000) // retry every 3 seconds max
					{
						RiskTrace("FAILED_STATE_RETRY_UNMANAGED", true);
						SubmitUnmanagedExitMarket("FAILED_STATE_RETRY");
						_riskStateEnteredTime = now; // reset timer
					}
					break;
				}

				case RiskExitState.FLAT_CONFIRMED:
					// Should not reach here with open position, but handle gracefully
					_riskExitState = RiskExitState.ARMED;
					break;
			}

			DrawRiskState();
		}

		private void RiskTrace(string reason, bool force)
		{
			if (!RiskOutputTrace)
				return;

			DateTime now = Core.Globals.Now;
			if (!force && _lastRiskOutputTime != Core.Globals.MinDate &&
				(now - _lastRiskOutputTime).TotalMilliseconds < Math.Max(0, RiskOutputMinMs))
				return;

			double distTicks = (_simulatedSL > 0 && _lastCheckPrice > 0 && TickSize > 0)
				? (Position != null && Position.MarketPosition == MarketPosition.Long
					? (_lastCheckPrice - _simulatedSL) / TickSize
					: (_simulatedSL - _lastCheckPrice) / TickSize)
				: 0.0;

			string line = string.Format(
				"[RISKTRACE] {0:HH:mm:ss.fff} reason={1} state={2} pos={3} qty={4} avg={5:F2} simSL={6:F2} prevPx={7:F2} checkPx={8:F2} distTicks={9:F1} Low={10:F2} High={11:F2} Bid={12:F2} Ask={13:F2} touched={14} touchSource={15} exitSubmitted={16} retryStage={17} lastExit={18} lastExitTime={19} unmanagedAttempts={20} entryBar={21} currentBar={22} postEntryLow={23:F2} postEntryHigh={24:F2}",
				now,
				reason,
				_riskExitState,
				Position != null ? Position.MarketPosition.ToString() : "NULL",
				Position != null ? Position.Quantity : 0,
				Position != null ? Position.AveragePrice : 0.0,
				_simulatedSL,
				_previousCheckPrice,
				_lastCheckPrice,
				distTicks,
				CurrentBar >= 0 ? Low[0] : 0.0,
				CurrentBar >= 0 ? High[0] : 0.0,
				!double.IsNaN(_bestBid) ? _bestBid : 0.0,
				!double.IsNaN(_bestAsk) ? _bestAsk : 0.0,
				_slTouched,
				string.IsNullOrEmpty(_lastTouchSource) ? "-" : _lastTouchSource,
				_exitSubmitted,
				_exitRetryStage,
				string.IsNullOrEmpty(_lastExitReason) ? "-" : _lastExitReason,
				_lastExitSubmitTime == Core.Globals.MinDate ? "-" : _lastExitSubmitTime.ToString("HH:mm:ss.fff"),
				_unmanagedExitAttempts,
				_activeEntryBar,
				CurrentBar,
				double.IsNaN(_postEntryLow)  ? 0.0 : _postEntryLow,
				double.IsNaN(_postEntryHigh) ? 0.0 : _postEntryHigh);

			if (force || line != _lastRiskTraceLine)
			{
				Print(line);
				_lastRiskTraceLine = line;
				_lastRiskOutputTime = now;
			}
		}

		private void DrawRiskState()
		{
			if (DrawSimulatedSLLine && _simulatedSL > 0)
				Draw.HorizontalLine(this, "EISLER_SIMULATED_SL", _simulatedSL, Brushes.Gold);

			if (!ShowRiskDebugPanel)
				return;

			string txt = string.Format(
				"EISLER RISK STATE\n" +
				"Position: {0} Qty:{1}\n" +
				"PositionAvgPrice: {2:F2}\n" +
				"SimSL: {3:F2}\n" +
				"LastCheckPrice: {4:F2}\n" +
				"SLTouched: {5}\n" +
				"ExitSubmitted: {6}\n" +
				"ExitSignal: {7}\n" +
				"SLTouchedTime: {8}\n" +
				"LastExitSubmitTime: {9}\n" +
				"RetryStage: {10}\n" +
				"CatStopSubmitted: {11}\n" +
				"UnmanagedExitAttempts: {12}\n" +
				"AccountFlattenAttempted: {13}\n" +
				"RiskExitState: {14}",
				Position.MarketPosition,
				Position.Quantity,
				Position.AveragePrice,
				_simulatedSL,
				_lastCheckPrice,
				_slTouched,
				_exitSubmitted,
				_activeEntrySignal,
				_slTouchedTime == Core.Globals.MinDate ? "-" : _slTouchedTime.ToString("HH:mm:ss.fff"),
				_lastExitSubmitTime == Core.Globals.MinDate ? "-" : _lastExitSubmitTime.ToString("HH:mm:ss.fff"),
				_exitRetryStage,
				_catastrophicStopSubmitted,
				_unmanagedExitAttempts,
				_accountFlattenAttempted,
				_riskExitState);

			Draw.TextFixed(this, "EISLER_RISK_DEBUG", txt, TextPosition.BottomLeft);
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity,
			MarketPosition marketPosition, string orderId, DateTime time)
		{
			if (execution == null || execution.Order == null || execution.Order.Name == null)
				return;

			if (execution.Order.Name == _activeEntrySignal && execution.Order.OrderState == OrderState.Filled)
			{
				_activeEntryAvgPrice = execution.Order.AverageFillPrice;
				_simulatedSL = 0.0;
				_slTouched = false;
				_exitSubmitted = false;
				_exitRetryStage = 0;
				_slTouchedTime = Core.Globals.MinDate;
				_lastExitSubmitTime = Core.Globals.MinDate;
				_lastTrailUpdateTime = Core.Globals.MinDate;

				// Initialise post-entry extremum tracking
				_activeEntryBar  = CurrentBar;
				_activeEntryTime = time;
				double fillPx = execution.Order.AverageFillPrice;
				_postEntryLow  = fillPx;
				_postEntryHigh = fillPx;

				InitializeTradeRiskAtEntry(fillPx, time);
				CsvOnEntryFill(fillPx, Math.Abs(quantity), time);
				ManageRiskState(true);
			}
			else if (execution.Order.OrderState == OrderState.Filled && _csvTradeActive)
			{
				string on = execution.Order.Name;
				bool isExitOrder = on.StartsWith(EntrySignalPrefix + "_EXIT_")
					|| on.StartsWith(EntrySignalPrefix + "_UMX_")
					|| on.StartsWith(EntrySignalPrefix + "_UMX_FB_")
					|| on.StartsWith(EntrySignalPrefix + "_FORCE_")
					|| on == _catastrophicStopSignal;

				if (isExitOrder)
				{
					double exitPx = execution.Price > 0 ? execution.Price : execution.Order.AverageFillPrice;
					bool wasCat = on == _catastrophicStopSignal;
					bool wasUmx = on.StartsWith(EntrySignalPrefix + "_UMX_") || on.StartsWith(EntrySignalPrefix + "_UMX_FB_");
					CsvSnapshotExitState(wasCat ? "CAT_STOP_FILLED" : (wasUmx ? "UNMANAGED_EXIT_FILLED" : "EXIT_FILLED"),
						on, execution.Order.OrderState.ToString(), string.Empty, string.Empty,
						wasCatastrophic: wasCat, wasUnmanaged: wasUmx);
					CsvWriteCompletedTrade(exitPx, time);
				}
			}
		}
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled,
			double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
			if (order == null || order.Name == null)
				return;

			if (order.Name.StartsWith(EntrySignalPrefix + "_EXIT_") || order.Name.StartsWith(EntrySignalPrefix + "_FORCE_"))
			{
				RiskTrace("EXIT_ORDER_UPDATE_" + orderState.ToString() + "_" + order.Name, true);
				if (orderState == OrderState.Filled)
				{
					_slTouched = false;
					_exitSubmitted = false;
					_exitRetryStage = 0;
					_lastExitReason = "FILLED_" + order.Name;
				}
				return;
			}

			if (order.Name == _catastrophicStopSignal)
			{
				_catastrophicStopOrder = order;
				if (orderState == OrderState.Filled)
				{
					// Snapshot exit info before clearing
					CsvSnapshotExitState("CAT_STOP_FILLED", order.Name, orderState.ToString(),
						error.ToString(), nativeError, wasCatastrophic: true);
					CsvWriteCompletedTrade(averageFillPrice, time);

					_entryOrder = null;
					_catastrophicStopOrder = null;
					_entryLimitPx = 0;
					_activeEntrySignal = string.Empty;
					_catastrophicStopSignal = string.Empty;
					_activeEntryDir = 0;
					_activeEntryAvgPrice = 0.0;
					_simulatedSL = 0.0;
					_slTouched = false;
					_exitSubmitted = false;
				}
				return;
			}

			if (order.Name.StartsWith(EntrySignalPrefix))
			{
				if (orderState == OrderState.Working || orderState == OrderState.Accepted)
				{
					_entryOrder = order;
					if (_entryWorkingLocalTime == Core.Globals.MinDate)
						_entryWorkingLocalTime = Core.Globals.Now;
				}
				else if (orderState == OrderState.Filled)
				{
					if (order.Name == _activeEntrySignal)
						_entryOrder = order;
					_entryLimitPx = 0;
				}
				else if (orderState == OrderState.Cancelled || orderState == OrderState.Rejected)
				{
					if (_entryOrder == order)
						_entryOrder = null;
					_entryLimitPx = 0;
					if (order.Name == _activeEntrySignal && order.Filled <= 0)
					{
						_activeEntrySignal = string.Empty;
						_catastrophicStopSignal = string.Empty;
						_activeEntryDir = 0;
						_activeEntryAvgPrice = 0.0;
						_simulatedSL = 0.0;
					}
					ResetEntrySubmitSnapshot();
				}
			}
		}

		// ============================================================
		// CSV EXPORT - HELPER METHODS
		// ============================================================

		private void CsvEnsureWriter()
		{
			if (!EnableTradeCsvExport) return;
			if (_csvWriter != null) return;

			try
			{
				if (string.IsNullOrEmpty(_csvRunId))
					_csvRunId = DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture);
				string csvName = TradeCsvFileName;
				if (CsvStartNewFileEachRun)
				{
					string ext = System.IO.Path.GetExtension(csvName);
					string stem = string.IsNullOrEmpty(ext) ? csvName : csvName.Substring(0, csvName.Length - ext.Length);
					csvName = stem + "_" + _csvRunId + (string.IsNullOrEmpty(ext) ? ".csv" : ext);
				}
				string path = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, csvName);
				bool fileExists = File.Exists(path) && new FileInfo(path).Length > 0;
				_csvWriter = new StreamWriter(path, append: !CsvStartNewFileEachRun, encoding: System.Text.Encoding.UTF8);
				if (!fileExists)
				{
					_csvWriter.WriteLine(CsvHeader());
					if (CsvFlushEveryLine) _csvWriter.Flush();
					_csvHeaderWritten = true;
				}
				else
				{
					_csvHeaderWritten = true;
				}
			}
			catch (Exception ex)
			{
				Print("[CSV_ERROR] Cannot open CSV writer: " + ex.Message);
				_csvWriter = null;
			}
		}

		private static string CsvHeader()
		{
			return string.Join(";", new[]
			{
				"RunId","TradeId","Instrument","AccountName","StrategyName",
				"EntrySignal","ExitSignal","Direction","Quantity",
				"EntryTime","EntryBar","EntryPrice","EntryBid","EntryAsk","EntrySpreadTicks",
				"EntryPred","EntryThreshold","EntryRiskState",
				"InitialSimSL","InitialRiskTicks","StopTicks","OneRTicks","AtrPeriod","VolatilityMultiplier",
				"FreeTradeActivation_R","TrailingActivation_R","StructuralLookbackBars","ChandelierAtrMultiplier",
				"TrailUpdateMinMs","StopMarketSafetyTicks","CatastrophicStopTicks",
				"ExitTime","ExitBar","ExitPrice","ExitReason","ExitOrderName","ExitOrderState",
				"ExitError","ExitNativeError","ExitRiskState","ExitRetryStage",
				"UnmanagedExitAttempts","AccountFlattenAttempted",
				"TouchSource","HoldingMs","HoldingBars",
				"MaxFavorableTicks","MaxAdverseTicks","MaxOpenProfitTicks","MaxOpenLossTicks",
				"FinalPnLTicks","FinalPnLPoints",
				"TicksGivenBackFromBest","GivebackPercentOfMFE",
				"ProfitTurnedPositiveTime","ProfitTurnedPositiveBar","ProfitTurnedPositiveAtTicks",
				"WasInProfit","WasProfitThenLoss",
				"SimSLAtEntry","SimSLAtFirstProfit","SimSLAtTrailActivation","SimSLAtMaxFavorable","SimSLAtExit",
				"LastCheckPriceAtExit","DistToSimSLTicksAtExit",
				"PostEntryLow","PostEntryHigh",
				"BestBidAtExit","BestAskAtExit","LowAtExitBar","HighAtExitBar","CloseAtExitBar",
				"ExitWasSLTouch","ExitWasRetry","ExitWasEmergency","ExitWasUnmanaged",
				"ExitWasAccountFlatten","ExitWasCatastrophic",
				"RlsPredAtEntry","RlsPredAtExit","LastPredDir","RegimeIsLargeTick","SpreadTicksAtExit",
				"VfDeltaNormAtEntry","VfDeltaNormAtExit","VfImbNearAtEntry","VfImbNearAtExit",
				"OfiProxyAtEntry","OfiProxyAtExit",
				"DR_MO_Entry","DR_LO_Entry","DR_CA_Entry","DR_MO_Exit","DR_LO_Exit","DR_CA_Exit",
				// Trail analysis columns
				"TrailMoveCount","FirstTrailMoveTime","LastTrailMoveTime",
				"BestSimSL","MaxDistanceFromSimSLTicks","MinDistanceFromSimSLTicks",
				"TrailShouldHaveActivated","TrailActivationReachedTime","TrailActivationReachedBar",
				"TrailActivationReachedAtTicks","FirstTrailMoveDelayMs","FirstTrailMoveDelayTicksFromActivation",
				"MaxFavorablePrice","MaxFavorableTime","MaxFavorableBar",
				"DistancePriceToSimSLTicksAtMaxFavorable","DistancePriceToSimSLTicksAtExit",
				"SimSLAtExit_dup_check",
				"ReachedTrailActivationButNoTrailMove",
				"ClosedAfterGivingBackMoreThan50PctMFE","ClosedAfterGivingBackMoreThan75PctMFE",
				"ATRTicksAtEntry","RawOneRTicks","ClampedOneRTicks","OneRWasClamped","OneRCalibrationMode",
				"FinalR","MFE_R","MAE_R","ETD_R","AtrExpansionRatioAtEntry",
				"EntryRejectedBySpread","EntryRejectedByOpeningNoise","EntryRejectedByLowConviction","EntryRejectedByDirectionalFilter",
				"SpreadAtReject","GateTimeAtReject","EarlyFailureHeldMs","EarlyFailureMfeR","EarlyFailureMaeR",
				"EventType"
			});
		}

		/// <summary>Called on entry fill to start a new trade record.</summary>
		private void CsvOnEntryFill(double fillPrice, int qty, DateTime entryTime)
		{
			if (!EnableTradeCsvExport) return;
			CsvEnsureWriter();

			_csvTradeSeq++;
			_csvTradeId = _csvTradeSeq;
			_csvTradeActive = true;

			_csvEntrySignal = _activeEntrySignal;
			_csvDirection   = _activeEntryDir;
			_csvQuantity    = qty;
			_csvEntryTime   = entryTime;
			_csvEntryBar    = CurrentBar;
			_csvEntryPrice  = fillPrice;
			_csvEntryBid    = !double.IsNaN(_bestBid) ? _bestBid : 0.0;
			_csvEntryAsk    = !double.IsNaN(_bestAsk) ? _bestAsk : 0.0;
			_csvEntrySpreadTicks = SpreadTicks() > 900 ? 0.0 : SpreadTicks();
			_csvEntryPred   = (CsvLogSubmitPrediction && _entryPredAtSubmit != 0.0) ? _entryPredAtSubmit : _lastPred;
			_csvEntryThreshold = _entryThresholdAtSubmit > 0 ? _entryThresholdAtSubmit : (double)(_isLargeTick ? EntryThresholdTicksLarge : EntryThresholdTicksSmall);
			_csvEntryRiskState = _riskExitState.ToString();
			_csvInitialSimSL = 0.0; // will be set after EnsureSimulatedSL fires
			_csvInitialRiskTicks = _currentOneR_Ticks > 0 ? _currentOneR_Ticks : StopTicks;

			// Volumetric snapshot
			_csvVfDeltaNormAtEntry = _vfDeltaNorm;
			_csvVfImbNearAtEntry   = _vfImbNear;
			_csvOfiProxyAtEntry    = _ofiProxy;
			_csvDR_MO_Entry        = _dR_MO;
			_csvDR_LO_Entry        = _dR_LO;
			_csvDR_CA_Entry        = _dR_CA;
			_csvRlsPredAtEntry     = _lastPred;

			// Reset live tracking
			_csvMaxFavorableTicks  = 0.0;
			_csvMaxAdverseTicks    = 0.0;
			_csvMaxOpenProfitTicks = 0.0;
			_csvMaxOpenLossTicks   = 0.0;
			_csvMaxFavorablePrice  = fillPrice;
			_csvMaxFavorableTime   = _csvEntryTime;
			_csvMaxFavorableBar    = CurrentBar;
			_csvWasInProfit        = false;
			_csvProfitTurnedPositiveTime = Core.Globals.MinDate;
			_csvProfitTurnedPositiveBar  = -1;
			_csvProfitTurnedPositiveAtTicks = 0.0;

			_csvSimSLAtEntry          = 0.0;
			_csvSimSLAtFirstProfit    = 0.0;
			_csvSimSLAtTrailActivation= 0.0;
			_csvSimSLAtMaxFavorable   = 0.0;

			_csvTrailActivationReached    = false;
			_csvTrailActivationReachedTime = Core.Globals.MinDate;
			_csvTrailActivationReachedBar = -1;
			_csvTrailActivationReachedAtTicks = 0.0;

			_csvTrailMoveCount   = 0;
			_csvFirstTrailMoveTime = Core.Globals.MinDate;
			_csvLastTrailMoveTime  = Core.Globals.MinDate;
			_csvBestSimSL        = 0.0;
			_csvMaxDistanceFromSimSLTicks = 0.0;
			_csvMinDistanceFromSimSLTicks = double.MaxValue;

			_csvExitReason    = string.Empty;
			_csvExitOrderName = string.Empty;
			_csvExitOrderState = string.Empty;
			_csvExitError     = string.Empty;
			_csvExitNativeError = string.Empty;
			_csvExitRiskState  = string.Empty;
			_csvExitRetryStage = 0;
			_csvExitWasSLTouch = false;
			_csvExitWasRetry   = false;
			_csvExitWasEmergency = false;
			_csvExitWasUnmanaged = false;
			_csvExitWasAccountFlatten = false;
			_csvExitWasCatastrophic  = false;

			if (!CsvExportOnlyCompletedTrades)
				CsvWriteLifecycleEvent("ENTRY_FILLED", fillPrice, 0.0);
		}

		/// <summary>Called every tick when in position to update live P&L tracking.</summary>
		private void CsvUpdateLiveTracking()
		{
			if (!EnableTradeCsvExport || !_csvTradeActive) return;
			if (Position == null || Position.MarketPosition == MarketPosition.Flat) return;
			if (TickSize <= 0) return;

			double checkPx = _lastCheckPrice > 0 ? _lastCheckPrice : Close[0];
			double entryPx = _csvEntryPrice > 0 ? _csvEntryPrice : (Position.AveragePrice > 0 ? Position.AveragePrice : 0);
			if (entryPx <= 0 || checkPx <= 0) return;

			double openProfitTicks = _csvDirection == 1
				? (checkPx - entryPx) / TickSize
				: (entryPx - checkPx) / TickSize;

			// Max favorable / adverse
			if (openProfitTicks > _csvMaxFavorableTicks)
			{
				_csvMaxFavorableTicks  = openProfitTicks;
				_csvMaxOpenProfitTicks = openProfitTicks;
				_csvMaxFavorablePrice  = checkPx;
				_csvMaxFavorableTime   = Time[0];
				_csvMaxFavorableBar    = CurrentBar;
				_csvSimSLAtMaxFavorable = _simulatedSL;
			}
			if (openProfitTicks < _csvMaxAdverseTicks)
			{
				_csvMaxAdverseTicks   = openProfitTicks;
				_csvMaxOpenLossTicks  = openProfitTicks;
			}

			// Profit turned positive tracking
			if (!_csvWasInProfit && openProfitTicks > 0)
			{
				_csvWasInProfit = true;
				_csvProfitTurnedPositiveTime   = Time[0];
				_csvProfitTurnedPositiveBar    = CurrentBar;
				_csvProfitTurnedPositiveAtTicks = openProfitTicks;
				_csvSimSLAtFirstProfit = _simulatedSL;
			}

			// Trail activation reached tracking
			if (!_csvTrailActivationReached && openProfitTicks >= (CurrentOneRTicks() * TrailingActivation_R))
			{
				_csvTrailActivationReached       = true;
				_csvTrailActivationReachedTime   = Time[0];
				_csvTrailActivationReachedBar    = CurrentBar;
				_csvTrailActivationReachedAtTicks = openProfitTicks;
				_csvSimSLAtTrailActivation       = _simulatedSL;
			}

			// SimSL at entry (capture once)
			if (_csvSimSLAtEntry <= 0.0 && _simulatedSL > 0)
				_csvSimSLAtEntry = _simulatedSL;

			// Distance from price to simSL
			if (_simulatedSL > 0 && checkPx > 0 && TickSize > 0)
			{
				double dist = _csvDirection == 1
					? (checkPx - _simulatedSL) / TickSize
					: (_simulatedSL - checkPx) / TickSize;

				if (dist > _csvMaxDistanceFromSimSLTicks)
					_csvMaxDistanceFromSimSLTicks = dist;
				if (dist < _csvMinDistanceFromSimSLTicks)
					_csvMinDistanceFromSimSLTicks = dist;
			}
		}

		/// <summary>
		/// Called from UpdateSimulatedTrailingSL AFTER the SL has been updated.
		/// Records trail movement for analysis.
		/// </summary>
		private void CsvOnTrailMoved(double newSimSL)
		{
			if (!EnableTradeCsvExport || !_csvTradeActive) return;

			DateTime now = Time[0];
			_csvTrailMoveCount++;
			if (_csvFirstTrailMoveTime == Core.Globals.MinDate)
				_csvFirstTrailMoveTime = now;
			_csvLastTrailMoveTime = now;

			// Best SL: for Long = highest SL value; for Short = lowest SL value
			if (_csvDirection == 1)
			{
				if (_csvBestSimSL <= 0 || newSimSL > _csvBestSimSL)
					_csvBestSimSL = newSimSL;
			}
			else
			{
				if (_csvBestSimSL <= 0 || newSimSL < _csvBestSimSL)
					_csvBestSimSL = newSimSL;
			}

			if (!CsvExportOnlyCompletedTrades)
				CsvWriteLifecycleEvent("TRAIL_SL_MOVED", newSimSL, _lastCheckPrice);
		}

		/// <summary>Snapshot exit state fields just before writing the completed trade row.</summary>
		private void CsvSnapshotExitState(string reason, string orderName, string orderState,
			string exitError, string nativeError,
			bool wasCatastrophic = false, bool wasUnmanaged = false, bool wasAccountFlatten = false)
		{
			if (!EnableTradeCsvExport || !_csvTradeActive) return;

			_csvExitReason     = reason;
			_csvExitOrderName  = orderName;
			_csvExitOrderState = orderState;
			_csvExitError      = exitError ?? string.Empty;
			_csvExitNativeError = nativeError ?? string.Empty;
			_csvExitRiskState  = _riskExitState.ToString();
			_csvExitRetryStage = _exitRetryStage;

			_csvExitWasSLTouch      = _slTouched || reason.IndexOf("SL", StringComparison.OrdinalIgnoreCase) >= 0 || !string.IsNullOrEmpty(_lastTouchSource);
			_csvExitWasRetry        = _exitRetryStage >= 1;
			_csvExitWasEmergency    = _exitRetryStage >= 2;
			_csvExitWasUnmanaged    = wasUnmanaged || _unmanagedExitAttempts > 0;
			_csvExitWasAccountFlatten = wasAccountFlatten || _accountFlattenAttempted;
			_csvExitWasCatastrophic = wasCatastrophic;

			// Current state snapshots
			_csvVfDeltaNormAtExit = _vfDeltaNorm;
			_csvVfImbNearAtExit   = _vfImbNear;
			_csvOfiProxyAtExit    = _ofiProxy;
			_csvDR_MO_Exit        = _dR_MO;
			_csvDR_LO_Exit        = _dR_LO;
			_csvDR_CA_Exit        = _dR_CA;
			_csvRlsPredAtExit     = _lastPred;
			_csvLastPredDirAtExit = _lastPredDir;
		}

		/// <summary>Called when position is flat and exit fill is confirmed. Writes the completed trade row.</summary>
		private void CsvWriteCompletedTrade(double exitPrice, DateTime exitTime)
		{
			if (!EnableTradeCsvExport || !_csvTradeActive) return;
			if (_csvWriter == null) CsvEnsureWriter();
			if (_csvWriter == null) return;

			double finalPnLTicks = 0.0;
			try
			{
				double entryPx = _csvEntryPrice > 0 ? _csvEntryPrice : 0;
				if (entryPx > 0 && exitPrice > 0 && TickSize > 0)
				{
					finalPnLTicks = _csvDirection == 1
						? (exitPrice - entryPx) / TickSize
						: (entryPx - exitPrice) / TickSize;
				}
				double finalPnLPoints = finalPnLTicks * TickSize;

				double ticksGivenBack = _csvMaxFavorableTicks - finalPnLTicks;
				double givebackPct = (_csvMaxFavorableTicks > 0)
					? (ticksGivenBack / _csvMaxFavorableTicks * 100.0)
					: 0.0;

				bool wasProfitThenLoss = _csvMaxFavorableTicks > 0 && finalPnLTicks < 0;
				bool reachedTrailButNoMove = _csvTrailActivationReached && _csvTrailMoveCount == 0;
				bool giveback50 = givebackPct >= 50.0;
				bool giveback75 = givebackPct >= 75.0;
				bool trailShouldHaveActivated = _csvMaxFavorableTicks >= (CurrentOneRTicks() * TrailingActivation_R);

				double firstTrailDelayMs = 0.0;
				if (_csvTrailActivationReached && _csvFirstTrailMoveTime != Core.Globals.MinDate
					&& _csvTrailActivationReachedTime != Core.Globals.MinDate)
				{
					firstTrailDelayMs = (_csvFirstTrailMoveTime - _csvTrailActivationReachedTime).TotalMilliseconds;
				}
				double firstTrailDelayTicksFromActivation = 0.0;
				if (_csvTrailActivationReached && _csvFirstTrailMoveTime != Core.Globals.MinDate)
				{
					// Approximate: delay in ms / TrailUpdateMinMs * movement observable
					firstTrailDelayTicksFromActivation = firstTrailDelayMs > 0 ? firstTrailDelayMs / Math.Max(1, TrailUpdateMinMs) : 0.0;
				}

				// Distance from price to simSL at max favorable
				double distToSimSLAtMaxFav = 0.0;
				if (_csvSimSLAtMaxFavorable > 0 && _csvMaxFavorablePrice > 0 && TickSize > 0)
				{
					distToSimSLAtMaxFav = _csvDirection == 1
						? (_csvMaxFavorablePrice - _csvSimSLAtMaxFavorable) / TickSize
						: (_csvSimSLAtMaxFavorable - _csvMaxFavorablePrice) / TickSize;
				}

				double distToSimSLAtExit = 0.0;
				if (_simulatedSL > 0 && exitPrice > 0 && TickSize > 0)
				{
					distToSimSLAtExit = _csvDirection == 1
						? (exitPrice - _simulatedSL) / TickSize
						: (_simulatedSL - exitPrice) / TickSize;
				}

				double minDistFinal = _csvMinDistanceFromSimSLTicks == double.MaxValue ? 0.0 : _csvMinDistanceFromSimSLTicks;

				int exitBar = CurrentBar;
				double lowAtExit  = exitBar >= 0 ? Low[0] : 0.0;
				double highAtExit = exitBar >= 0 ? High[0] : 0.0;
				double closeAtExit = exitBar >= 0 ? Close[0] : 0.0;

				double holdingMs = (_csvEntryTime != Core.Globals.MinDate)
					? (exitTime - _csvEntryTime).TotalMilliseconds
					: 0.0;
				int holdingBars = (_csvEntryBar >= 0) ? (exitBar - _csvEntryBar) : 0;

				string instrName = Instrument != null ? Instrument.FullName : string.Empty;
				string acctName  = Account != null ? Account.Name : string.Empty;

				var ic = CultureInfo.InvariantCulture;
				string DT(DateTime dt) => dt == Core.Globals.MinDate ? string.Empty : dt.ToString("yyyy-MM-dd HH:mm:ss.fff", ic);
				string F(double v) => v.ToString("F4", ic);
				string B(bool v) => v ? "1" : "0";
				string I(int v) => v.ToString(ic);

				var cols = new[]
				{
					_csvRunId, I(_csvTradeId), instrName, acctName, Name,
					_csvEntrySignal, _csvExitOrderName,
					_csvDirection == 1 ? "Long" : "Short", I(_csvQuantity),
					DT(_csvEntryTime), I(_csvEntryBar), F(_csvEntryPrice), F(_csvEntryBid), F(_csvEntryAsk), F(_csvEntrySpreadTicks),
					F(_csvEntryPred), F(_csvEntryThreshold), _csvEntryRiskState,
					F(_csvInitialSimSL), F(_csvInitialRiskTicks),
					I(StopTicks), F(CurrentOneRTicks()), I(AtrPeriod), F(VolatilityMultiplier),
					F(FreeTradeActivation_R), F(TrailingActivation_R), I(StructuralLookbackBars), F(ChandelierAtrMultiplier),
					I(TrailUpdateMinMs), I(StopMarketSafetyTicks), I(CatastrophicStopTicks),
					DT(exitTime), I(exitBar), F(exitPrice),
					_csvExitReason, _csvExitOrderName, _csvExitOrderState,
					_csvExitError, _csvExitNativeError, _csvExitRiskState, I(_csvExitRetryStage),
					I(_unmanagedExitAttempts), B(_accountFlattenAttempted),
					_lastTouchSource, F(holdingMs), I(holdingBars),
					F(_csvMaxFavorableTicks), F(_csvMaxAdverseTicks), F(_csvMaxOpenProfitTicks), F(_csvMaxOpenLossTicks),
					F(finalPnLTicks), F(finalPnLPoints),
					F(ticksGivenBack), F(givebackPct),
					DT(_csvProfitTurnedPositiveTime), I(_csvProfitTurnedPositiveBar), F(_csvProfitTurnedPositiveAtTicks),
					B(_csvWasInProfit), B(wasProfitThenLoss),
					F(_csvSimSLAtEntry), F(_csvSimSLAtFirstProfit), F(_csvSimSLAtTrailActivation),
					F(_csvSimSLAtMaxFavorable), F(_simulatedSL),
					F(_lastCheckPrice), F(distToSimSLAtExit),
					F(double.IsNaN(_postEntryLow)  ? 0.0 : _postEntryLow),
					F(double.IsNaN(_postEntryHigh) ? 0.0 : _postEntryHigh),
					F(!double.IsNaN(_bestBid) ? _bestBid : 0.0),
					F(!double.IsNaN(_bestAsk) ? _bestAsk : 0.0),
					F(lowAtExit), F(highAtExit), F(closeAtExit),
					B(_csvExitWasSLTouch), B(_csvExitWasRetry), B(_csvExitWasEmergency),
					B(_csvExitWasUnmanaged), B(_csvExitWasAccountFlatten), B(_csvExitWasCatastrophic),
					F(_csvRlsPredAtEntry), F(_csvRlsPredAtExit), F(_csvLastPredDirAtExit),
					B(_isLargeTick), F(SpreadTicks() > 900 ? 0.0 : SpreadTicks()),
					F(_csvVfDeltaNormAtEntry), F(_csvVfDeltaNormAtExit),
					F(_csvVfImbNearAtEntry),   F(_csvVfImbNearAtExit),
					F(_csvOfiProxyAtEntry),    F(_csvOfiProxyAtExit),
					F(_csvDR_MO_Entry), F(_csvDR_LO_Entry), F(_csvDR_CA_Entry),
					F(_csvDR_MO_Exit),  F(_csvDR_LO_Exit),  F(_csvDR_CA_Exit),
					// Trail analysis
					I(_csvTrailMoveCount),
					DT(_csvFirstTrailMoveTime), DT(_csvLastTrailMoveTime),
					F(_csvBestSimSL), F(_csvMaxDistanceFromSimSLTicks), F(minDistFinal),
					B(trailShouldHaveActivated),
					DT(_csvTrailActivationReachedTime), I(_csvTrailActivationReachedBar),
					F(_csvTrailActivationReachedAtTicks),
					F(firstTrailDelayMs), F(firstTrailDelayTicksFromActivation),
					F(_csvMaxFavorablePrice), DT(_csvMaxFavorableTime), I(_csvMaxFavorableBar),
					F(distToSimSLAtMaxFav), F(distToSimSLAtExit),
					F(_simulatedSL), // SimSLAtExit_dup_check
					B(reachedTrailButNoMove),
					B(giveback50), B(giveback75),
					F(_atrTicksAtEntry), F(_rawOneRTicksAtEntry), F(CurrentOneRTicks()), B(_oneRWasClamped), OneRCalibrationMode.ToString(),
					F(finalPnLTicks / Math.Max(1.0, CurrentOneRTicks())), F(_csvMaxFavorableTicks / Math.Max(1.0, CurrentOneRTicks())), F(_csvMaxAdverseTicks / Math.Max(1.0, CurrentOneRTicks())), F(ticksGivenBack / Math.Max(1.0, CurrentOneRTicks())), F(AtrExpansionRatio()),
					B(_lastEntryRejectedBySpread), B(_lastEntryRejectedByOpeningNoise), B(_lastEntryRejectedByLowConviction), B(_lastEntryRejectedByDirectionalFilter),
					F(_lastSpreadAtReject), DT(_lastGateTimeAtReject), F(_lastEarlyFailureHeldMs), F(_lastEarlyFailureMfeR), F(_lastEarlyFailureMaeR),
					"TRADE_COMPLETED"
				};

				_csvWriter.WriteLine(string.Join(";", cols));
				if (CsvFlushEveryLine) _csvWriter.Flush();
			}
			catch (Exception ex)
			{
				Print("[CSV_ERROR] Write failed: " + ex.Message);
			}

			RegisterTradeOutcome(finalPnLTicks, _csvExitWasSLTouch || _lastExitReason.IndexOf("SL", StringComparison.OrdinalIgnoreCase) >= 0 || !string.IsNullOrEmpty(_lastTouchSource));
			_csvTradeActive = false;
		}

		/// <summary>Writes an optional lifecycle event row (non-completed trade rows).</summary>
		private void CsvWriteLifecycleEvent(string eventType, double price1, double price2)
		{
			if (!EnableTradeCsvExport || CsvExportOnlyCompletedTrades) return;
			if (_csvWriter == null) CsvEnsureWriter();
			if (_csvWriter == null) return;

			try
			{
				var ic = CultureInfo.InvariantCulture;
				string DT(DateTime dt) => dt == Core.Globals.MinDate ? string.Empty : dt.ToString("yyyy-MM-dd HH:mm:ss.fff", ic);
				string F(double v) => v.ToString("F4", ic);

				// Minimal lifecycle row — pad remaining columns with empty
				var cols = new[]
				{
					_csvRunId,
					_csvTradeId.ToString(ic),
					Instrument != null ? Instrument.FullName : string.Empty,
					Account != null ? Account.Name : string.Empty,
					Name,
					_csvEntrySignal, string.Empty,
					_csvDirection == 1 ? "Long" : "Short",
					_csvQuantity.ToString(ic),
					DT(_csvEntryTime), _csvEntryBar.ToString(ic), F(_csvEntryPrice),
					F(_csvEntryBid), F(_csvEntryAsk), F(_csvEntrySpreadTicks),
					F(_csvEntryPred), F(_csvEntryThreshold), _csvEntryRiskState,
					F(_csvInitialSimSL), F(_csvInitialRiskTicks),
					StopTicks.ToString(ic), F(CurrentOneRTicks()), AtrPeriod.ToString(ic), F(VolatilityMultiplier),
					F(FreeTradeActivation_R), F(TrailingActivation_R), StructuralLookbackBars.ToString(ic), F(ChandelierAtrMultiplier),
					TrailUpdateMinMs.ToString(ic), StopMarketSafetyTicks.ToString(ic), CatastrophicStopTicks.ToString(ic),
					DT(Time[0]), CurrentBar.ToString(ic), F(price1),
					eventType, string.Empty, string.Empty,
					string.Empty, string.Empty, _riskExitState.ToString(), _exitRetryStage.ToString(ic),
					_unmanagedExitAttempts.ToString(ic), (_accountFlattenAttempted ? "1" : "0"),
					_lastTouchSource,
					"0","0",
					F(_csvMaxFavorableTicks), F(_csvMaxAdverseTicks), F(_csvMaxOpenProfitTicks), F(_csvMaxOpenLossTicks),
					"0","0","0","0",
					string.Empty,"0","0",
					"0","0",
					F(_csvSimSLAtEntry), F(_csvSimSLAtFirstProfit), F(_csvSimSLAtTrailActivation),
					F(_csvSimSLAtMaxFavorable), F(_simulatedSL),
					F(_lastCheckPrice), "0",
					F(double.IsNaN(_postEntryLow)  ? 0.0 : _postEntryLow),
					F(double.IsNaN(_postEntryHigh) ? 0.0 : _postEntryHigh),
					F(!double.IsNaN(_bestBid) ? _bestBid : 0.0),
					F(!double.IsNaN(_bestAsk) ? _bestAsk : 0.0),
					CurrentBar >= 0 ? F(Low[0]) : "0",
					CurrentBar >= 0 ? F(High[0]) : "0",
					CurrentBar >= 0 ? F(Close[0]) : "0",
					"0","0","0","0","0","0",
					F(_lastPred), F(_lastPred), _lastPredDir.ToString(ic),
					(_isLargeTick ? "1" : "0"),
					F(SpreadTicks() > 900 ? 0.0 : SpreadTicks()),
					F(_csvVfDeltaNormAtEntry), F(_vfDeltaNorm),
					F(_csvVfImbNearAtEntry),   F(_vfImbNear),
					F(_csvOfiProxyAtEntry),    F(_ofiProxy),
					F(_csvDR_MO_Entry), F(_csvDR_LO_Entry), F(_csvDR_CA_Entry),
					F(_dR_MO), F(_dR_LO), F(_dR_CA),
					_csvTrailMoveCount.ToString(ic),
					DT(_csvFirstTrailMoveTime), DT(_csvLastTrailMoveTime),
					F(_csvBestSimSL), F(_csvMaxDistanceFromSimSLTicks),
					(_csvMinDistanceFromSimSLTicks == double.MaxValue ? "0" : F(_csvMinDistanceFromSimSLTicks)),
					"0",
					DT(_csvTrailActivationReachedTime), _csvTrailActivationReachedBar.ToString(ic),
					F(_csvTrailActivationReachedAtTicks),
					"0","0",
					F(_csvMaxFavorablePrice), DT(_csvMaxFavorableTime), _csvMaxFavorableBar.ToString(ic),
					"0","0",
					F(_simulatedSL),
					"0","0","0",
					F(_atrTicksAtEntry), F(_rawOneRTicksAtEntry), F(CurrentOneRTicks()), (_oneRWasClamped ? "1" : "0"), OneRCalibrationMode.ToString(),
					"0","0","0","0", F(AtrExpansionRatio()),
					(_lastEntryRejectedBySpread ? "1" : "0"), (_lastEntryRejectedByOpeningNoise ? "1" : "0"), (_lastEntryRejectedByLowConviction ? "1" : "0"), (_lastEntryRejectedByDirectionalFilter ? "1" : "0"),
					F(_lastSpreadAtReject), DT(_lastGateTimeAtReject), F(_lastEarlyFailureHeldMs), F(_lastEarlyFailureMfeR), F(_lastEarlyFailureMaeR),
					eventType
				};

				_csvWriter.WriteLine(string.Join(";", cols));
				if (CsvFlushEveryLine) _csvWriter.Flush();
			}
			catch (Exception ex)
			{
				Print("[CSV_ERROR] Lifecycle event write failed: " + ex.Message);
			}
		}

		private void CsvCloseWriter()
		{
			try
			{
				if (_csvWriter != null)
				{
					_csvWriter.Flush();
					_csvWriter.Close();
					_csvWriter.Dispose();
					_csvWriter = null;
				}
			}
			catch { }
		}

	}
}