#region Using declarations
using System;
using System.Collections.Generic;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.BarsTypes
{
    public class EislerPriceLevelData
    {
        public double Price;
        public long BuyVolume;
        public long SellVolume;
        public long AggressiveBuyVolume;
        public long AggressiveSellVolume;
        public int TouchCount;
        public int SweepCount;
        public int RefillCount;
        public int AbsorptionCount;
        public int TrapCount;
        public double AbsorptionScore;
        public double RefillScore;
        public double LiquidityPersistence;
        public double Elasticity;
        public double TrappedTraderScore;
        public double SweepProbability;
        public double MeanReversionProbability;
        public double ContinuationProbability;
        public double RevisitProbability;
        public double QueueResiliency;
        public double ImpactMemory;
        public double LocalVolatility;
        public double LocalImbalanceTensor;
        public double InducedResponseState;
        public DateTime LastTouch = Core.Globals.MinDate;
        public DateTime LastSweep = Core.Globals.MinDate;
        public DateTime LastAbsorption = Core.Globals.MinDate;
        public DateTime LastTrap = Core.Globals.MinDate;
        public int LastSide;
        public double LastDelta;
        public long Delta { get { return BuyVolume - SellVolume; } }
        public double BuySellRatio { get { return SellVolume == 0 ? (BuyVolume > 0 ? double.PositiveInfinity : 0) : (double)BuyVolume / SellVolume; } }
        public double SellBuyRatio { get { return BuyVolume == 0 ? (SellVolume > 0 ? double.PositiveInfinity : 0) : (double)SellVolume / BuyVolume; } }
    }

    public class EislerOrderFlowData
    {
        public long BuyVolume;
        public long SellVolume;
        public long Delta { get { return BuyVolume - SellVolume; } }
        public double NetLiquidityPressure;
        public double GapCompression;
        public double GapExpansion;
        public double RefillIntensity;
        public double SweepIntensity;
        public double LiquidityElasticity;
        public double AggressionVelocity;
        public double ImpactSlope;
        public double Toxicity;
        public double Resiliency;
        public double EventEntropy;
        public double RegimeProbability;
        public Dictionary<double, EislerPriceLevelData> Footprint = new Dictionary<double, EislerPriceLevelData>();
    }

    public class EislerBarType : BarsType
    {
        public Dictionary<int, EislerOrderFlowData> FlowDataByBar = new Dictionary<int, EislerOrderFlowData>();
        public Dictionary<double, EislerPriceLevelData> PriceLevelMemory = new Dictionary<double, EislerPriceLevelData>();

        private double lastPrice;
        private double lastPriceLevel;
        private DateTime lastInputTime;
        private int lastBarsCountSeen;
        private int lastTradeSide;
        private DateTime lastSweepTime = Core.Globals.MinDate;
        private double lastSweepPrice;
        private int lastSweepSide;
        private SessionIterator sessionIterator;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "EislerBarType 1 minute stateful price-level order-flow bars.";
                Name = "EislerBarType";
                BarsPeriod = new BarsPeriod { BarsPeriodType = (BarsPeriodType)8260, BarsPeriodTypeName = "EislerBarType", Value = 1 };
                BuiltFrom = BarsPeriodType.Tick;
                DaysToLoad = 1;
                IsIntraday = true;
                IsTimeBased = true;
            }
            else if (State == State.Configure)
            {
                if (BarsPeriod == null)
                    BarsPeriod = new BarsPeriod { BarsPeriodType = (BarsPeriodType)8260, BarsPeriodTypeName = "EislerBarType", Value = 1 };
                if (BarsPeriod.Value <= 0)
                    BarsPeriod.Value = 1;
            }
            else if (State == State.DataLoaded || State == State.Terminated)
                ResetAllLocalState(true);
        }

        protected override void OnDataPoint(Bars bars, double open, double high, double low, double close, DateTime time, long volume, bool isBar, double bid, double ask)
        {
            if (bars == null)
                return;

            if (lastInputTime != DateTime.MinValue && time < lastInputTime)
                ResetPerInputStreamState();

            if (lastBarsCountSeen > 0 && bars.Count < lastBarsCountSeen)
            {
                FlowDataByBar.Clear();
                PriceLevelMemory.Clear();
                ResetPerInputStreamState();
            }

            if (sessionIterator == null)
                sessionIterator = new SessionIterator(bars);

            bool isNewSession = sessionIterator.IsNewSession(time, isBar);
            if (isNewSession)
            {
                sessionIterator.GetNextSession(time, isBar);
                lastPrice = close;
                lastPriceLevel = NormalizePrice(bars, close);
                PriceLevelMemory.Clear();
            }

            DateTime barTime = GetBarTime(time, bars.BarsPeriod.Value);
            long safeVolume = volume > 0 ? volume : 0;
            if (bars.Count == 0)
                AddBar(bars, open, high, low, close, barTime, safeVolume);
            else if (barTime > bars.LastBarTime)
                AddBar(bars, open, high, low, close, barTime, safeVolume);
            else
                UpdateBar(bars, high, low, close, bars.LastBarTime, safeVolume);

            int currentBarIndex = bars.Count - 1;
            if (currentBarIndex >= 0)
                UpdateOrderFlowData(bars, currentBarIndex, close, volume, time, bid, ask);

            if (close > 0)
            {
                lastPrice = close;
                lastPriceLevel = NormalizePrice(bars, close);
            }
            lastInputTime = time;
            lastBarsCountSeen = bars.Count;
        }

        private void UpdateOrderFlowData(Bars bars, int currentBarIndex, double close, long volume, DateTime time, double bid, double ask)
        {
            EislerOrderFlowData flow;
            if (!FlowDataByBar.TryGetValue(currentBarIndex, out flow))
            {
                flow = new EislerOrderFlowData();
                FlowDataByBar[currentBarIndex] = flow;
            }

            long buyVolume = 0, sellVolume = 0;
            ClassifyVolumeTickRuleOnly(close, volume, ref buyVolume, ref sellVolume);
            flow.BuyVolume += buyVolume;
            flow.SellVolume += sellVolume;

            double priceLevel = NormalizePrice(bars, close);
            EislerPriceLevelData barLevel = GetOrCreate(flow.Footprint, priceLevel);
            EislerPriceLevelData memoryLevel = GetOrCreate(PriceLevelMemory, priceLevel);
            int side = buyVolume > sellVolume ? 1 : (sellVolume > buyVolume ? -1 : 0);
            double tickSize = GetTickSize(bars);
            double prevLevel = lastPriceLevel > 0 ? lastPriceLevel : priceLevel;
            double moveTicks = tickSize > 0 ? (priceLevel - prevLevel) / tickSize : 0.0;
            UpdateLevel(barLevel, side, buyVolume, sellVolume, volume, moveTicks, time, tickSize);
            UpdateLevel(memoryLevel, side, buyVolume, sellVolume, volume, moveTicks, time, tickSize);
            UpdateAggregates(flow);
        }

        private EislerPriceLevelData GetOrCreate(Dictionary<double, EislerPriceLevelData> map, double price)
        {
            EislerPriceLevelData state;
            if (!map.TryGetValue(price, out state))
            {
                state = new EislerPriceLevelData { Price = price };
                map[price] = state;
            }
            return state;
        }

        private void UpdateLevel(EislerPriceLevelData level, int side, long buyVolume, long sellVolume, long volume, double moveTicks, DateTime time, double tickSize)
        {
            if (level == null)
                return;

            level.LastTouch = time;
            level.TouchCount++;
            level.BuyVolume += buyVolume;
            level.SellVolume += sellVolume;

            if (side > 0)
                level.AggressiveBuyVolume += Math.Max(0, volume);
            else if (side < 0)
                level.AggressiveSellVolume += Math.Max(0, volume);

            double vol = Math.Max(1.0, level.BuyVolume + level.SellVolume);
            double imb = Math.Max(-1.0, Math.Min(1.0, level.Delta / vol));
            double absMove = Math.Abs(moveTicks);
            double tSize = tickSize > 0 ? tickSize : 0.25;
            const double d = 0.985;

            level.AbsorptionScore *= d;
            level.RefillScore *= d;
            level.SweepProbability *= d;
            level.TrappedTraderScore *= d;

            bool sweep = side != 0 && side * moveTicks > 0.25 && absMove >= 1.0;
            bool sameOrStalledPrice = side != 0 && absMove < 0.50 && volume > 0;
            bool absorption = sameOrStalledPrice && (Math.Abs(imb) >= 0.12 || level.TouchCount >= 2 || Math.Abs(level.Delta - level.LastDelta) >= Math.Max(1, volume));

            bool refill = false;
            bool failedSweepResponse = false;
            if (lastSweepTime != Core.Globals.MinDate && side != 0)
            {
                double ms = (time - lastSweepTime).TotalMilliseconds;
                bool nearSweep = Math.Abs(level.Price - lastSweepPrice) <= 6.0 * tSize;
                bool oppositeSweepSide = side * lastSweepSide < 0;
                if (ms >= 0 && ms <= 5000 && nearSweep && oppositeSweepSide)
                {
                    refill = true;
                    if (absMove < 0.75 || absorption)
                        failedSweepResponse = true;
                }
            }

            if (sweep)
            {
                level.SweepCount++;
                level.SweepProbability += 0.30 + 0.15 * Math.Min(1.0, absMove / 4.0);
                level.LastSweep = time;
                lastSweepTime = time;
                lastSweepPrice = level.Price;
                lastSweepSide = side;
            }

            if (absorption)
            {
                level.AbsorptionCount++;
                level.AbsorptionScore += 0.18 + 0.16 * Math.Min(1.0, Math.Abs(imb));
                level.LastAbsorption = time;
            }

            if (refill)
            {
                level.RefillCount++;
                level.RefillScore += 0.22 + 0.14 * Math.Min(1.0, Math.Abs(imb));
            }

            // Trap proxy deliberately less strict than before:
            // 1) sweep után ellenoldali refill/stalled response,
            // 2) absorption olyan szinten, ahol már van sweep pressure,
            // 3) failed sweep + no continuation.
            bool trap = failedSweepResponse
                        || (refill && (absorption || level.AbsorptionScore > 0.04 || level.SweepProbability > 0.08))
                        || (absorption && level.SweepProbability > 0.10);

            if (trap)
            {
                level.TrapCount++;
                level.TrappedTraderScore += 0.22 + 0.18 * Math.Min(1.0, Math.Abs(imb)) + 0.10 * Math.Min(1.0, level.SweepProbability);
                level.LastTrap = time;
            }

            level.ImpactMemory = 0.90 * level.ImpactMemory + 0.10 * moveTicks;
            level.LocalVolatility = 0.94 * level.LocalVolatility + 0.06 * absMove;
            level.LocalImbalanceTensor = 0.90 * level.LocalImbalanceTensor + 0.10 * imb;
            level.InducedResponseState = Math.Max(-1.0, Math.Min(1.0, 0.90 * level.InducedResponseState + 0.10 * side * (level.RefillScore + level.TrappedTraderScore - level.SweepProbability)));
            level.LiquidityPersistence = Clamp01(0.92 * level.LiquidityPersistence + 0.08 * Math.Min(1.0, level.TouchCount / 20.0));
            level.QueueResiliency = Clamp01(0.60 * level.QueueResiliency + 0.25 * level.RefillScore + 0.15 * level.LiquidityPersistence);
            level.Elasticity = Clamp01(0.70 * level.Elasticity + 0.30 * Math.Abs(level.RefillScore - level.SweepProbability));
            level.ContinuationProbability = Sigmoid(1.20 * level.SweepProbability + 0.60 * Math.Abs(level.LocalImbalanceTensor) - 1.00 * level.AbsorptionScore - 0.70 * level.TrappedTraderScore);
            level.MeanReversionProbability = Sigmoid(1.15 * level.AbsorptionScore + 0.80 * level.RefillScore + 0.75 * level.TrappedTraderScore - 0.80 * level.SweepProbability);
            level.RevisitProbability = Sigmoid(0.10 * level.TouchCount + 1.00 * level.LiquidityPersistence + 0.25 * level.RefillScore);

            level.LastSide = side;
            level.LastDelta = level.Delta;
        }

        private void UpdateAggregates(EislerOrderFlowData flow)
        {
            if (flow == null || flow.Footprint == null || flow.Footprint.Count == 0)
                return;
            double pressure = 0, refill = 0, sweep = 0, elasticity = 0, resil = 0, impact = 0, tox = 0;
            int n = 0;
            foreach (var kv in flow.Footprint)
            {
                var l = kv.Value;
                if (l == null) continue;
                double vol = Math.Max(1.0, l.BuyVolume + l.SellVolume);
                double imb = l.Delta / vol;
                pressure += imb * (1.0 + l.ContinuationProbability - l.MeanReversionProbability);
                refill += l.RefillScore;
                sweep += l.SweepProbability;
                elasticity += l.Elasticity;
                resil += l.QueueResiliency;
                impact += l.ImpactMemory;
                tox += Math.Abs(imb) * (1.0 - l.QueueResiliency + l.SweepProbability + l.TrappedTraderScore);
                n++;
            }
            if (n <= 0) return;
            flow.NetLiquidityPressure = pressure / n;
            flow.RefillIntensity = refill / n;
            flow.SweepIntensity = sweep / n;
            flow.LiquidityElasticity = elasticity / n;
            flow.Resiliency = resil / n;
            flow.ImpactSlope = impact / n;
            flow.Toxicity = tox / n;
            flow.GapCompression = Math.Max(0.0, flow.RefillIntensity - flow.SweepIntensity);
            flow.GapExpansion = Math.Max(0.0, flow.SweepIntensity - flow.RefillIntensity);
            flow.AggressionVelocity = Math.Abs(flow.Delta) / Math.Max(1.0, (double)(flow.BuyVolume + flow.SellVolume));
            flow.RegimeProbability = Sigmoid(1.25 * flow.NetLiquidityPressure + 0.75 * flow.ImpactSlope - 0.50 * flow.Toxicity);
        }

        private double Clamp01(double x) { return Math.Max(0.0, Math.Min(1.0, x)); }
        private double Sigmoid(double x) { x = Math.Max(-20.0, Math.Min(20.0, x)); return 1.0 / (1.0 + Math.Exp(-x)); }
        private void ClassifyVolumeTickRuleOnly(double close, long volume, ref long buyVolume, ref long sellVolume)
        {
            if (volume <= 0)
                return;

            if (lastPrice > 0)
            {
                if (close > lastPrice)
                {
                    buyVolume = volume;
                    lastTradeSide = 1;
                }
                else if (close < lastPrice)
                {
                    sellVolume = volume;
                    lastTradeSide = -1;
                }
                else if (lastTradeSide > 0)
                {
                    buyVolume = volume;
                }
                else if (lastTradeSide < 0)
                {
                    sellVolume = volume;
                }
            }
        }

        private void ResetAllLocalState(bool clearFlowData)
        {
            if (clearFlowData)
            {
                FlowDataByBar.Clear();
                PriceLevelMemory.Clear();
            }
            sessionIterator = null;
            lastPrice = 0;
            lastPriceLevel = 0;
            lastInputTime = DateTime.MinValue;
            lastBarsCountSeen = 0;
            lastTradeSide = 0;
            lastSweepTime = Core.Globals.MinDate;
            lastSweepPrice = 0;
            lastSweepSide = 0;
        }
        private void ResetPerInputStreamState()
        {
            sessionIterator = null;
            lastPrice = 0;
            lastPriceLevel = 0;
            lastInputTime = DateTime.MinValue;
            lastTradeSide = 0;
        }
        private DateTime GetBarTime(DateTime time, int minutes)
        {
            if (minutes <= 0) minutes = 1;
            DateTime date = time.Date;
            int totalMinutes = (int)time.TimeOfDay.TotalMinutes;
            int roundedMinutes = ((totalMinutes / minutes) + 1) * minutes;
            return date.AddMinutes(roundedMinutes);
        }
        private double GetTickSize(Bars bars)
        {
            if (bars == null || bars.Instrument == null || bars.Instrument.MasterInstrument == null) return 0.0;
            return bars.Instrument.MasterInstrument.TickSize;
        }
        private double NormalizePrice(Bars bars, double price)
        {
            double tickSize = GetTickSize(bars);
            if (tickSize <= 0) return price;
            return Math.Round(price / tickSize, 0, MidpointRounding.AwayFromZero) * tickSize;
        }
        public override void ApplyDefaultValue(BarsPeriod period) { if (period != null) period.Value = 1; }
        public override void ApplyDefaultBasePeriodValue(BarsPeriod period) { }
        public override int GetInitialLookBackDays(BarsPeriod barsPeriod, TradingHours tradingHours, int barsBack) { return 1; }
        public override double GetPercentComplete(Bars bars, DateTime now)
        {
            if (bars == null || bars.Count == 0 || bars.BarsPeriod == null || bars.BarsPeriod.Value <= 0) return 0;
            DateTime lastBarTime = bars.LastBarTime;
            DateTime previousBarTime = lastBarTime.AddMinutes(-bars.BarsPeriod.Value);
            double elapsed = (now - previousBarTime).TotalSeconds;
            double total = bars.BarsPeriod.Value * 60.0;
            if (total <= 0) return 0;
            return Math.Max(0, Math.Min(1, elapsed / total));
        }
        public override string ChartLabel(DateTime dateTime) { return dateTime.ToString("HH:mm"); }
        public override string ToString() { return "EislerBarType"; }
    }
}
